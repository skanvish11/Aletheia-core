"""Isolated fixed-evidence decision experiment; no application modifications."""

import argparse
import asyncio
import json
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "evidence-first-comparison-20261110"
sys.path.insert(0, str(PREVIOUS))
# Avoid importing this runner as the earlier runner named experiment.
import importlib.util

spec = importlib.util.spec_from_file_location(
    "experiment", PREVIOUS.parent / "assessment-comparison-20261110/experiment.py"
)
base = importlib.util.module_from_spec(spec)
sys.modules["experiment"] = base
spec.loader.exec_module(base)
import evidence_first as prior

base.CAP = 64
COMPARISON_PROMPT = """Assess the original claim using only the supplied source quotations.
Identify the factual value or relationship asserted by the claim. Identify the value
or relationship established by the quotations for that same subject and event. Compare
these facts, preserving negation, quantities, units, dates and event distinctions.
Choose the relation to the claim, not whether the source repeats the claim:
- contradicts: quoted evidence establishes at least one incompatible material fact
  for the same subject and event. Evidence against a claim settles that claim against
  it; do not label such evidence not_established merely because it does not support it.
- supports: quoted evidence establishes all material facts and no incompatible fact.
- not_established: the evidence leaves a material fact unresolved, and establishes
  no incompatible fact. Irrelevant text or missing evidence does not settle the claim.
For supports or contradicts, explain the comparison in one short sentence stating
the claim's factual assertion and the cited evidence's factual assertion. Cite the
quotation IDs that justify it. Every source-attributed fact must follow from those
quotations. Do not infer a replacement fact beyond what they establish. Do not add
names, dates, numbers or technical references from memory. The claim is being tested;
its content is not evidence. Source URL/title identify provenance, not proof.
For not_established return explanation=null and evidence_ids=[].
Return only the requested JSON structure.
"""
PROMPTS = {
    "previous_explanation": prior.EXPLAIN_PROMPT,
    "explicit_comparison": COMPARISON_PROMPT,
}
SELECTED = {"b0012": [3], "b0002": [285], "b0011": [21], "b0026": [5, 6]}


def prepare():
    fixtures = base.load_cases()
    prior.offline_checks(fixtures)
    inputs, provenance = {}, {}
    for f in fixtures:
        key = f["case_id"] + "/" + f["condition"]
        spans = [
            s
            for s in f["selected"]
            if f["condition"] == "withheld" or s.id in SELECTED[f["case_id"]]
        ]
        evidence = []
        for i, span in enumerate(spans, 1):
            assert f["source"].normalized_text[span.start : span.end] == span.text
            evidence.append(
                {
                    "id": f"E{i}",
                    "span_id": span.id,
                    "start": span.start,
                    "end": span.end,
                    "quote": span.text,
                    "snapshot_id": f["source"].id,
                    "quote_sha256": base.sha(span.text.encode()),
                }
            )
        inputs[key] = {
            "claim": f["assertion"].text,
            "source": {"url": f["source"].url, "title": f["source"].title},
            "evidence": [{"id": e["id"], "quote": e["quote"]} for e in evidence],
        }
        provenance[key] = {
            "evidence": evidence,
            "database_path": f["database_path"],
            "database_sha256": f["database_sha256"],
            "saved_case_sha256": f["saved_case_sha256"],
        }
    protocol = {
        "purpose": "Isolate decision quality with manually fixed, context-complete saved quotations; compare prompts with identical schema and inputs.",
        "arms": list(PROMPTS),
        "cases": list(SELECTED),
        "relevant_repetitions": 3,
        "withheld_repetitions": 1,
        "planned_trials": 32,
        "network_attempt_cap": 64,
        "model_settings": "Same frozen settings as prior experiment; no temperature or seed override.",
        "task_repairs": 1,
        "transport_retries": 0,
        "tavily_calls": 0,
        "selection": "Python full bounded history span; Venus second-planet sentence; SHA full subject-containing paragraph; Paris adoption plus UNFCCC context paragraph. Controls retain the same irrelevant saved spans. Selection is manual, not a tested extractor.",
        "control_policy": "Both prompts assess irrelevant supplied quotations; no automatic abstention shortcut.",
        "schedule": "Alternate arm order across cases and repetitions; sequential requests.",
        "expected": {
            f["case_id"] + "/" + f["condition"]: f["expected_relation"]
            for f in fixtures
        },
        "metrics": [
            "Correct accepted relation, first attempt and final after repair separately",
            "Fully quotation-grounded factual explanations",
            "Unsupported factual additions in accepted and rejected outputs separately",
            "Correct withheld-evidence abstentions; invalid output is a failure",
            "Calls, tokens and latency",
        ],
        "review": "Assistant semantic review; no independent human ground truth. No semantic expected-answer validation or repair.",
        "limitations": [
            "Four familiar development claims with few repetitions; no statistical superiority claim.",
            "Changes quotation selection versus prior experiment; compare the two contemporaneous arms, not historical totals.",
            "Does not evaluate search, extraction, source truth/authority or production verdicts.",
            "Prompt and schema frozen before live calls; no post-result tuning.",
        ],
        "previous_requests_sha256": base.sha((PREVIOUS / "requests.json").read_bytes()),
        "source_code_revision": (prior.PREVIOUS / "baseline-revision.txt")
        .read_text()
        .strip(),
    }
    requests = {
        "prompts": PROMPTS,
        "schema": prior.Explanation.model_json_schema(),
        "inputs": inputs,
        "repair_guidance": prior.REPAIRS["explanation_reference"],
    }
    return fixtures, protocol, requests, provenance


async def execute(args):
    if (ROOT / "results.json").exists():
        raise SystemExit("Results exist; refusing overwrite or automatic rerun.")
    fixtures, protocol, requests, provenance = prepare()
    for name, value in [
        ("protocol.json", protocol),
        ("requests.json", requests),
        ("provenance.json", provenance),
    ]:
        base.dump(ROOT / name, value)
    if not args.live:
        print(
            json.dumps(
                {
                    "prepared": True,
                    "offline_checks_passed": True,
                    "trials": 32,
                    "call_cap": 64,
                }
            )
        )
        return
    loaded = prior.ProviderSettings.from_environment(dotenv_path=args.dotenv)
    old_settings = json.loads((PREVIOUS / "manifest.json").read_text())["settings"]
    settings = prior.ProviderSettings.model_validate(
        {**loaded.model_dump(), **old_settings}
    )
    if not settings.nebius_api_key:
        raise SystemExit("Credential unavailable; no model call made.")
    settings.validate_model_controls()
    manifest = {
        "started_at": datetime.now(UTC).isoformat(),
        "settings": settings.model_dump(exclude={"nebius_api_key", "tavily_api_key"}),
        "temperature": "provider default",
        "seed": "not set",
        "python": sys.version,
        "hashes": {
            name: base.sha((ROOT / name).read_bytes())
            for name in [
                "experiment.py",
                "protocol.json",
                "requests.json",
                "provenance.json",
            ]
        },
        "imported_hashes": {
            str(p): base.sha(p.read_bytes())
            for p in [PREVIOUS / "evidence_first.py", prior.PREVIOUS / "experiment.py"]
        },
    }
    base.dump(ROOT / "manifest.json", manifest)
    transport, rows = base.AuditTransport(), []
    schedule = []
    for rep in range(3):
        for f in fixtures:
            if f["condition"] == "withheld" and rep:
                continue
            arms = list(PROMPTS)
            if (rep + list(SELECTED).index(f["case_id"])) % 2:
                arms.reverse()
            schedule.extend((f, rep + 1, arm) for arm in arms)
    async with prior.NebiusProvider(settings, transport=transport) as model:
        for f, rep, arm in schedule:
            key = f["case_id"] + "/" + f["condition"]
            trial = f"{key}/{rep}/{arm}"
            row = {
                "trial": trial,
                "case_id": f["case_id"],
                "condition": f["condition"],
                "repetition": rep,
                "arm": arm,
                "events": [],
            }
            started, before = time.monotonic(), len(transport.records)

            async def emit(event, payload, row=row):
                row["events"].append({"type": event, "payload": payload})

            tasks = prior.Tasks(
                model, prior.CallBudget(2, 0, 0, time.monotonic() + 95), emit
            )
            transport.context = trial
            try:
                result = await tasks.call(
                    "explain_evidence",
                    PROMPTS[arm],
                    requests["inputs"][key],
                    prior.Explanation,
                    lambda result, key=key: prior.validate_explanation(
                        result, provenance[key]["evidence"]
                    ),
                )
                row.update(status="accepted", output=result.model_dump())
            except prior.InvalidTask:
                row["status"] = "invalid_task_output"
            except prior.ProviderError as exc:
                row.update(status=exc.code.value, validation_code=exc.validation_code)
            row.update(
                usage=tasks.tokens,
                elapsed_seconds=time.monotonic() - started,
                network_calls=len(transport.records) - before,
            )
            row["validation_failures"] = [
                e["payload"]["validation_code"]
                for e in row["events"]
                if e["type"] == "task_finished" and e["payload"]["outcome"] != "success"
            ]
            rows.append(row)
            base.dump(ROOT / "results.json", rows)
            base.dump(ROOT / "provider-records.json", transport.records)
            print(
                json.dumps(
                    {
                        k: row[k]
                        for k in [
                            "trial",
                            "status",
                            "network_calls",
                            "validation_failures",
                        ]
                    }
                ),
                flush=True,
            )
            if row["status"] not in {"accepted", "invalid_task_output"}:
                manifest["stopped_early"] = row["status"]
                break
    manifest.update(
        finished_at=datetime.now(UTC).isoformat(),
        trials_recorded=len(rows),
        network_attempts=len(transport.records),
        historical_databases_unchanged=all(
            base.sha(Path(f["database_path"]).read_bytes()) == f["database_sha256"]
            for f in fixtures
        ),
    )
    base.dump(ROOT / "manifest.json", manifest)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv", type=Path)
    asyncio.run(execute(parser.parse_args()))
