"""Offline integrity checks and recorded assistant review of decision experiment."""

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "decision_experiment", ROOT / "experiment.py"
)
run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


def main():
    def read(name):
        return json.loads((ROOT / name).read_text())

    rows, records, manifest = (
        read("results.json"),
        read("provider-records.json"),
        read("manifest.json"),
    )
    protocol = read("protocol.json")
    for name, digest in manifest["hashes"].items():
        assert run.base.sha((ROOT / name).read_bytes()) == digest
    for name, digest in manifest["imported_hashes"].items():
        assert run.base.sha(Path(name).read_bytes()) == digest
    _fixtures, rebuilt_protocol, requests, provenance = run.prepare()
    assert rebuilt_protocol == protocol
    assert requests == read("requests.json")
    assert provenance == read("provenance.json")
    old_fixtures = json.loads((run.prior.PREVIOUS / "protocol.json").read_text())[
        "fixtures"
    ]
    for f in old_fixtures:
        assert (
            run.base.sha(Path(f["database_path"]).read_bytes()) == f["database_sha256"]
        )
    assert len(rows) == len({r["trial"] for r in rows}) == 32
    assert len(records) == sum(r["network_calls"] for r in rows) == 37
    assert all(r["http_status"] == 200 for r in records)
    unsupported = {
        "b0002/relevant/1/previous_explanation": "Adds Mercury and an orbital-distance generalization absent from the sole supplied quotation. The relation is correct but the explanation is not fully grounded. Output also ends mid-phrase at 300 characters; this observation does not establish where shortening occurred.",
        "b0026/withheld/1/previous_explanation": "Asserts adoption date/conference from source title/context, although quotations contain only design, printing and recycling metadata. Accepted citation IDs do not establish semantic support.",
    }
    scores = []
    for row in rows:
        trial = row["trial"]
        expected = protocol["expected"][row["case_id"] + "/" + row["condition"]]
        calls = [r for r in records if r["trial"] == trial]
        assert len(calls) == row["network_calls"]
        output = row.get("output") or {}
        first = calls[0].get("output") or {}
        finished = [e for e in row["events"] if e["type"] == "task_finished"]
        first_valid = finished[0]["payload"]["outcome"] == "success"
        correct = row["status"] == "accepted" and output.get("relation") == expected
        notes = [unsupported[trial]] if trial in unsupported else []
        if row["case_id"] == "b0002" and row["condition"] == "relevant" and not correct:
            notes.append(
                "Abstains despite a complete quotation establishing second planet from the Sun. Retrieval and extraction are bypassed."
            )
        if trial == "b0002/relevant/2/previous_explanation":
            notes.append(
                "Rejected first proposal explicitly says the quotation contradicts the claim but chooses not_established. Structural repair retains abstention."
            )
        if trial == "b0012/relevant/2/previous_explanation":
            notes.append(
                "First proposal calls a conflicting release date not_established; structural repair happens to change the relation to contradicts. No expected label was supplied to repair."
            )
        scores.append(
            {
                "trial": trial,
                "arm": row["arm"],
                "case_id": row["case_id"],
                "condition": row["condition"],
                "first_label_correct": first.get("relation") == expected,
                "first_valid_and_correct": first_valid
                and first.get("relation") == expected,
                "final_correct": correct,
                "fully_grounded_relevant_success": row["condition"] == "relevant"
                and correct
                and trial not in unsupported,
                "accepted_unsupported_addition": trial in unsupported,
                "notes": notes,
            }
        )
    summary = {}
    for arm in protocol["arms"]:
        ss = [s for s in scores if s["arm"] == arm]
        rr = [r for r in rows if r["arm"] == arm]
        relevant = [s for s in ss if s["condition"] == "relevant"]
        withheld = [s for s in ss if s["condition"] == "withheld"]
        summary[arm] = {
            "relevant_trials": len(relevant),
            "first_attempt_correct_labels": sum(
                s["first_label_correct"] for s in relevant
            ),
            "first_attempt_valid_correct": sum(
                s["first_valid_and_correct"] for s in relevant
            ),
            "final_correct_relations": sum(s["final_correct"] for s in relevant),
            "fully_grounded_relevant_explanations": sum(
                s["fully_grounded_relevant_success"] for s in relevant
            ),
            "correct_by_case": {
                case: sum(s["final_correct"] for s in relevant if s["case_id"] == case)
                for case in protocol["cases"]
            },
            "withheld_trials": len(withheld),
            "first_attempt_valid_abstentions": sum(
                s["first_valid_and_correct"] for s in withheld
            ),
            "final_correct_abstentions": sum(s["final_correct"] for s in withheld),
            "accepted_unsupported_additions": sum(
                s["accepted_unsupported_addition"] for s in ss
            ),
            "rejected_unsupported_additions": 0,
            "repair_calls": sum(r["network_calls"] - 1 for r in rr),
            "network_calls": sum(r["network_calls"] for r in rr),
            "total_tokens": sum(r["usage"]["total_tokens"] for r in rr),
            "mean_trial_seconds": sum(r["elapsed_seconds"] for r in rr) / len(rr),
        }
    report = {
        "review": "Assistant reviewed every accepted output and all five rejected proposals against supplied quotations. Not independent human review or a statistical claim.",
        "grounding_rubric": "Correct relation plus explanation whose factual assertions follow from cited quotes. Restating the claim as the claim is allowed. Relevant Paris adoption/date and Conference of Parties are explicit in E1, with institutional UNFCCC context in supplied E2/provenance; this is a passage-decision diagnostic, not a full production component/authority audit.",
        "summary": summary,
        "integrity": {
            "trials": len(rows),
            "http_200_requests": len(records),
            "exact_saved_quotes_checked": sum(
                len(v["evidence"]) for v in provenance.values()
            ),
            "frozen_artifact_hashes_match": True,
            "inputs_reconstructed_identically": True,
            "historical_databases_unchanged": True,
            "offline_validator_checks_pass": True,
        },
        "interpretation": "Explicit comparison eliminated observed unsupported additions and repairs in this sample, but both prompts still missed one of three Venus decisions with complete fixed evidence. Search/truncation cannot explain that remaining isolated failure. This does not establish that prompt changes solve the problem or that the model lacks the capability; more diverse held-out comparisons are required.",
        "limitations": protocol["limitations"],
        "trials": scores,
    }
    run.base.dump(ROOT / "review.json", report)
    print(json.dumps({"summary": summary, "integrity": report["integrity"]}, indent=2))


if __name__ == "__main__":
    main()
