"""Offline audit and explicit assistant scoring of the frozen experiment outputs."""

import json
from collections import Counter

import evidence_first as run


def main():
    root = run.ROOT
    read = lambda name: json.loads((root / name).read_text())
    rows = read("results.json")
    records = read("provider-records.json")
    manifest = read("manifest.json")
    protocol = read("protocol.json")
    fixtures = {(f["case_id"], f["condition"]): f for f in run.base.load_cases()}
    run.offline_checks(list(fixtures.values()))
    for field, path in {
        "script_sha256": root / "evidence_first.py",
        "base_script_sha256": run.PREVIOUS / "experiment.py",
        "protocol_sha256": root / "protocol.json",
        "requests_sha256": root / "requests.json",
    }.items():
        assert run.base.sha(path.read_bytes()) == manifest[field], field
    old_protocol = json.loads((run.PREVIOUS / "protocol.json").read_text())
    assert run.base.sha((run.PREVIOUS / "protocol.json").read_bytes()) == protocol["fixture_protocol_sha256"]
    for f in old_protocol["fixtures"]:
        assert run.base.sha(run.Path(f["database_path"]).read_bytes()) == f["database_sha256"]
    assert len(rows) == len({r["trial"] for r in rows}) == 32
    assert len(records) == sum(r["network_calls"] for r in rows) == 46
    assert all(r["http_status"] == 200 for r in records)
    scores = []
    quotes_checked = 0
    for row in rows:
        f = fixtures[row["case_id"], row["condition"]]
        evidence = row.get("evidence", [])
        if evidence:
            reconstructed = run.quote_records(
                run.Extraction(quotes=[run.ExactQuote(span_id=e["span_id"], quote=e["quote"]) for e in evidence]), f
            )
            assert reconstructed == evidence
            quotes_checked += len(evidence)
        output = row.get("output") or {}
        accepted = row["status"] == "accepted"
        expected = protocol["expected"][row["case_id"] + "/" + row["condition"]]
        correct = accepted and output.get("relation") == expected
        context_gap = row["trial"] == "b0011/relevant/3/evidence_first"
        unsupported = row["condition"] == "withheld" and accepted and output.get("relation") != "not_established"
        notes = []
        if context_gap:
            notes.append("Exact quote starts with 'It' and omits the antecedent SHA-256. The saved source supports the answer, but the quotation alone does not identify the subject. Source title cannot substitute for evidence under the prompt. Conservatively excluded from fully quotation-grounded successes; not counted as an invented external fact.")
        if unsupported:
            notes.append("Accepted factual answer cites only irrelevant formatting/printing spans; absent evidence was supplied from outside those spans.")
        if not accepted:
            notes.append("Both SHA-256 control proposals add FIPS PUB 180-4 absent from supplied text. Invalid citations block publication, but this is not a successful abstention.")
        if row["trial"] == "b0002/relevant/1/evidence_first":
            notes.append("Extractor returned no quotes despite the supplied second-planet sentence; deterministic abstention followed.")
        if row["trial"] == "b0002/relevant/3/evidence_first":
            notes.append("Correct second-planet sentence extracted. First explanation recognizes incompatibility but labels it not_established; repair clears explanation/citations and retains abstention.")
        scores.append({
            "trial": row["trial"], "case_id": row["case_id"], "arm": row["arm"], "condition": row["condition"],
            "accepted": accepted, "correct_relation": correct,
            "fully_grounded_relevant_success": row["condition"] == "relevant" and correct and not context_gap,
            "quote_context_gap": context_gap, "accepted_unsupported_factual_answer": unsupported,
            "notes": notes,
        })
    summary = {}
    for arm in protocol["arms"]:
        ss = [s for s in scores if s["arm"] == arm]
        rr = [r for r in rows if r["arm"] == arm]
        summary[arm] = {
            "relevant_trials": 12,
            "correct_relevant_relations": sum(s["correct_relation"] for s in ss if s["condition"] == "relevant"),
            "fully_grounded_relevant_successes": sum(s["fully_grounded_relevant_success"] for s in ss),
            "withheld_trials": 4,
            "correct_withheld_abstentions": sum(s["correct_relation"] for s in ss if s["condition"] == "withheld"),
            "accepted_unsupported_answers": sum(s["accepted_unsupported_factual_answer"] for s in ss),
            "invalid_final_outputs": sum(not s["accepted"] for s in ss),
            "quote_context_gaps": sum(s["quote_context_gap"] for s in ss),
            "network_calls": sum(r["network_calls"] for r in rr),
            "total_tokens": sum(r["usage"]["total_tokens"] for r in rr),
            "mean_trial_seconds": sum(r["elapsed_seconds"] for r in rr) / len(rr),
            "correct_relations_by_case": dict(Counter(s["case_id"] for s in ss if s["condition"] == "relevant" and s["correct_relation"])),
        }
    report = {
        "reviewer": "Assistant manual semantic review plus offline integrity checks; not independent human evaluation.",
        "scoring_note": "The conservative context-completeness judgement was applied during post-run review, consistent with the preregistered extraction requirement. Correct relation is reported separately to expose this judgement. Both arms are judged against evidence visible at answer time. Python quote names Python within the same sentence; Paris source provenance supplies institutional context, with the decisive adoption event/date explicit in the quote.",
        "summary": summary,
        "integrity": {"trials": 32, "http_200_calls": 46, "exact_quotes_verified": quotes_checked, "frozen_hashes_match": True, "historical_database_hashes_match": True, "offline_negative_checks_pass": True},
        "rejected_unsupported_proposals": {"direct_simple": 2, "evidence_first": 0, "note": "Both direct proposals belong to the one withheld SHA-256 trial. Separate from accepted unsupported answers and from the SHA-256 quote-context gap."},
        "interpretation": "Evidence-first eliminated accepted unsupported answers in these four withheld controls, but did not improve relevant-evidence relation accuracy. It introduced one quote-context gap and retained two distinct Venus failures. This does not prove a general absence of unsupported additions or establish production readiness.",
        "limitations": protocol["limitations"],
        "trials": scores,
    }
    run.base.dump(root / "review.json", report)
    print(json.dumps({"summary": summary, "integrity": report["integrity"]}, indent=2))


if __name__ == "__main__":
    main()
