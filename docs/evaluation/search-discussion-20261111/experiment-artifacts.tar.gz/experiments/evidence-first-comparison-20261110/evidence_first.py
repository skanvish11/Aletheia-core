"""Isolated paired test: direct answer versus exact evidence then explanation."""

import argparse
import asyncio
import json
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated, Literal

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "assessment-comparison-20261110"
sys.path.insert(0, str(PREVIOUS))

import experiment as base
from aletheia.budgets import CallBudget
from aletheia.config import ProviderSettings
from aletheia.providers.errors import ProviderError
from aletheia.providers.nebius import NebiusProvider
from aletheia.tasks import REPAIR_GUIDANCE, InvalidTask, Tasks, TaskValidationError
from pydantic import BaseModel, ConfigDict, Field

CAP = 96
base.CAP = CAP  # Only this isolated process; no application files are changed.
REPAIRS = {
    "quote_exact": "Every quote must be a unique, exact, contiguous substring of its supplied span. Copy the original characters without edits. If no relevant evidence is present, return quotes=[].",
    "quote_reference": "Use only supplied span IDs. Do not repeat a quote. Return quotes=[] when no supplied passage bears on the claim.",
    "explanation_reference": "For a factual relation, provide nonempty explanation and valid evidence IDs. For not_established, explanation MUST be null and evidence_ids MUST be [].",
}
REPAIR_GUIDANCE.update(REPAIRS)


class ExactQuote(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    span_id: Annotated[int, Field(ge=1)]
    quote: Annotated[str, Field(min_length=16, max_length=1200)]


class Extraction(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    quotes: Annotated[list[ExactQuote], Field(max_length=4)]


class Explanation(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    relation: Literal["supports", "contradicts", "not_established"]
    explanation: Annotated[str | None, Field(max_length=300)]
    evidence_ids: Annotated[list[str], Field(max_length=4)]


EXTRACT_PROMPT = """Select exact source evidence that bears directly on the original assertion.text.
Do not decide the verdict or explain it. Return only source span IDs and literal quotes.
Copy complete informative sentences or clauses, keeping the subject, event, date,
quantity, negation and any qualification needed to understand the evidence. Include
nearby antecedent text if needed to identify what a pronoun refers to. Do not rewrite,
normalize whitespace, splice nonadjacent text, or supply facts from memory.
Select relevant evidence whether it supports or contradicts the claim. Do not demand
that a source repeat the claim's proposed answer. The assertion and its analysis are
not evidence. Titles, navigation and printing metadata alone do not establish the
claimed fact. If the supplied spans do not contain relevant factual evidence, return
quotes=[]. No evidence here does not mean the claim is false. Use at most four short
exact quotes, each from one supplied span; include context necessary for comparison.
"""

EXPLAIN_PROMPT = """Compare the original claim with the validated source quotations.
Use ONLY the quoted evidence as factual support. The claim is what is being tested,
not evidence that its proposed facts are true. Do not add people, entities, dates,
numbers or other facts from memory. Source metadata identifies provenance, not proof
of the claim. Explain the comparison in one short sentence grounded in cited quotes.
supports: the quotations establish all material facts in the claim.
contradicts: they explicitly establish an incompatible fact for the same subject/event.
not_established: the quotations do not settle the claim. In that case explanation=null
and evidence_ids=[]. Absence of support is not contradiction. Different factual values
for the same subject/event can be counterevidence, not automatically different scope.
Preserve conditions, negations and distinctions between dates or events. Do not invent
a replacement fact when the evidence only establishes that the proposed fact is wrong.
Every factual statement in the explanation must follow from the cited quotations;
refer to the original claim only to identify what is being compared.
"""


def quote_records(result, fixture):
    spans = {s.id: s for s in fixture["selected"]}
    records, seen = [], set()
    for q in result.quotes:
        if q.span_id not in spans or (q.span_id, q.quote) in seen:
            raise TaskValidationError("quote_reference")
        span = spans[q.span_id]
        if span.text.count(q.quote) != 1:
            raise TaskValidationError("quote_exact")
        start = span.start + span.text.index(q.quote)
        end = start + len(q.quote)
        text = fixture["source"].normalized_text[start:end]
        if text != q.quote:
            raise TaskValidationError("quote_exact")
        seen.add((q.span_id, q.quote))
        records.append(
            {
                "id": f"E{len(records) + 1}",
                "snapshot_id": fixture["source"].id,
                "span_id": q.span_id,
                "start": start,
                "end": end,
                "quote": text,
                "quote_sha256": base.sha(text.encode()),
            }
        )
    return records


def validate_explanation(result, records):
    valid = {e["id"] for e in records}
    ids = result.evidence_ids
    if result.relation == "not_established":
        if result.explanation is not None or ids:
            raise TaskValidationError("explanation_reference")
    elif (
        not result.explanation
        or not result.explanation.strip()
        or not ids
        or len(ids) != len(set(ids))
        or not set(ids) <= valid
    ):
        raise TaskValidationError("explanation_reference")


def offline_checks(fixtures):
    f = next(
        f for f in fixtures if f["case_id"] == "b0002" and f["condition"] == "relevant"
    )
    quote = f["selected"][0].text
    exact = Extraction(quotes=[ExactQuote(span_id=285, quote=quote)])
    records = quote_records(exact, f)
    assert records[0]["quote"] == quote
    for bad in [
        Extraction(
            quotes=[ExactQuote(span_id=285, quote=quote.replace("second", "first"))]
        ),
        Extraction(quotes=[ExactQuote(span_id=99999, quote=quote)]),
        Extraction(quotes=[ExactQuote(span_id=285, quote=quote)] * 2),
    ]:
        try:
            quote_records(bad, f)
        except TaskValidationError:
            pass
        else:
            raise AssertionError("An invalid quotation was accepted")
    for bad in [
        Explanation(
            relation="contradicts", explanation="A comparison.", evidence_ids=["E99"]
        ),
        Explanation(relation="supports", explanation="A comparison.", evidence_ids=[]),
        Explanation(
            relation="not_established", explanation="A claim.", evidence_ids=[]
        ),
    ]:
        try:
            validate_explanation(bad, records)
        except TaskValidationError:
            pass
        else:
            raise AssertionError("An invalid explanation reference was accepted")
    assert quote_records(Extraction(quotes=[]), f) == []
    validate_explanation(
        Explanation(relation="not_established", explanation=None, evidence_ids=[]), []
    )


async def execute(args):
    if (ROOT / "results.json").exists():
        raise SystemExit("Results already exist; no automatic rerun or overwrite.")
    fixtures = base.load_cases()
    offline_checks(fixtures)
    data = {}
    old_requests = json.loads((PREVIOUS / "requests.json").read_text())
    for f in fixtures:
        key = f["case_id"] + "/" + f["condition"]
        captured = await base.capture(f)
        assert captured[2] == old_requests[key]["input"]
        data[key] = captured[2]
    protocol = {
        "purpose": "Test whether exact evidence extraction before explanation reduces unsupported additions.",
        "arms": ["direct_simple", "evidence_first"],
        "baseline": "Unchanged simpler prompt/schema/validation from the previous experiment, rerun contemporaneously.",
        "source_code_revision": (PREVIOUS / "baseline-revision.txt")
        .read_text()
        .strip(),
        "cases": list(base.CASE_SPECS),
        "relevant_repetitions": 3,
        "withheld_repetitions": 1,
        "planned_trials": 32,
        "network_attempt_cap": CAP,
        "tavily_calls": 0,
        "task_repairs": 1,
        "transport_retries": 0,
        "no_evidence_policy": "Validated empty extraction deterministically produces not_established; no explanation call.",
        "primary_metrics": [
            "Correct relation with fully source-grounded cited answer/explanation, all 12 relevant trials in denominator.",
            "Unsupported factual additions in final accepted explanations and in rejected proposals, reported separately.",
            "Correct abstention with evidence withheld; validator-blocked unsupported answers are failures, not successful abstentions.",
        ],
        "extraction_metric": "Relevant decisive information retained; exact substring/offset integrity separately from semantic relevance.",
        "review": "Assistant review against saved source; no independent human ground truth or acceptance claim.",
        "matching": "Same saved excerpts and first-stage serialized data, model, settings, alternating arm order, one repair per stage. No expected labels sent to model.",
        "resource_difference": "Evidence-first uses up to two stages; direct uses one. This is an architecture comparison, not an equal-call-budget test.",
        "explanation_visibility": "Only original claim, source URL/title, and validated quotes. No rejected outputs, claim-analysis rationale, full source or expected answer.",
        "limitations": [
            "Four familiar development claims, not a general benchmark.",
            "Model sampling defaults and three repetitions do not establish statistical superiority.",
            "Exact quotes do not establish source truth or semantic entailment.",
            "No search, passage selector, source sufficiency, or production final-verdict evaluation.",
        ],
        "fixture_protocol_sha256": base.sha((PREVIOUS / "protocol.json").read_bytes()),
        "expected": {
            f["case_id"] + "/" + f["condition"]: f["expected_relation"]
            for f in fixtures
        },
    }
    requests = {
        "inputs": data,
        "direct_prompt": base.SIMPLE_PROMPT,
        "direct_schema": base.SimpleAssessment.model_json_schema(),
        "extract_prompt": EXTRACT_PROMPT,
        "extract_schema": Extraction.model_json_schema(),
        "explain_prompt": EXPLAIN_PROMPT,
        "explain_schema": Explanation.model_json_schema(),
        "repair_guidance": REPAIRS,
    }
    base.dump(ROOT / "protocol.json", protocol)
    base.dump(ROOT / "requests.json", requests)
    if not args.live:
        print(
            json.dumps(
                {
                    "prepared": True,
                    "planned_trials": 32,
                    "max_model_calls": CAP,
                    "offline_checks_passed": True,
                    "same_inputs_as_previous": True,
                }
            )
        )
        return
    loaded = ProviderSettings.from_environment(dotenv_path=args.dotenv)
    old_settings = json.loads((PREVIOUS / "manifest.json").read_text())["settings"]
    settings = ProviderSettings.model_validate({**loaded.model_dump(), **old_settings})
    if not settings.nebius_api_key:
        raise SystemExit("Model credential unavailable; no model call made.")
    settings.validate_model_controls()
    manifest = {
        "started_at": datetime.now(UTC).isoformat(),
        "settings": settings.model_dump(exclude={"nebius_api_key", "tavily_api_key"}),
        "temperature": "provider default",
        "seed": "not set",
        "python": sys.version,
        "script_sha256": base.sha(Path(__file__).read_bytes()),
        "base_script_sha256": base.sha((PREVIOUS / "experiment.py").read_bytes()),
        "protocol_sha256": base.sha((ROOT / "protocol.json").read_bytes()),
        "requests_sha256": base.sha((ROOT / "requests.json").read_bytes()),
    }
    base.dump(ROOT / "manifest.json", manifest)
    transport, rows = base.AuditTransport(), []
    async with NebiusProvider(settings, transport=transport) as model:
        schedule = []
        for rep in range(3):
            for f in fixtures:
                if f["condition"] == "withheld" and rep:
                    continue
                arms = ("direct_simple", "evidence_first")
                if (rep + list(base.CASE_SPECS).index(f["case_id"])) % 2:
                    arms = tuple(reversed(arms))
                schedule.extend((f, rep + 1, arm) for arm in arms)
        for f, rep, arm in schedule:
            key = f["case_id"] + "/" + f["condition"]
            trial = f"{key}/{rep}/{arm}"
            row = {
                "trial": trial,
                "case_id": f["case_id"],
                "condition": f["condition"],
                "repetition": rep,
                "arm": arm,
                "events": [],
                "status": "started",
            }
            started, before = time.monotonic(), len(transport.records)
            budget = CallBudget(
                4 if arm == "evidence_first" else 2, 0, 0, time.monotonic() + 190
            )

            async def emit(event, payload, row=row):
                row["events"].append({"type": event, "payload": payload})

            tasks = Tasks(model, budget, emit)
            try:
                if arm == "direct_simple":
                    transport.context = trial + "/answer"
                    result = await tasks.call(
                        "direct_answer",
                        base.SIMPLE_PROMPT,
                        data[key],
                        base.SimpleAssessment,
                        lambda result, f=f: base.validate_simple(result, f),
                    )
                    row["output"] = result.model_dump()
                else:
                    transport.context = trial + "/extract"
                    extraction = await tasks.call(
                        "extract_evidence",
                        EXTRACT_PROMPT,
                        data[key],
                        Extraction,
                        lambda result, f=f: quote_records(result, f),
                    )
                    records = quote_records(extraction, f)
                    row["evidence"] = records
                    if not records:
                        row["explanation_skipped"] = "no_extracted_evidence"
                        row["output"] = {
                            "relation": "not_established",
                            "explanation": None,
                            "evidence_ids": [],
                        }
                    else:
                        transport.context = trial + "/explain"
                        explanation_input = {
                            "claim": f["assertion"].text,
                            "source": {
                                "url": f["source"].url,
                                "title": f["source"].title,
                            },
                            "evidence": [
                                {"id": e["id"], "quote": e["quote"]} for e in records
                            ],
                        }
                        row["explanation_input"] = explanation_input
                        result = await tasks.call(
                            "explain_evidence",
                            EXPLAIN_PROMPT,
                            explanation_input,
                            Explanation,
                            lambda result, records=records: validate_explanation(
                                result, records
                            ),
                        )
                        row["output"] = result.model_dump()
                row["status"] = "accepted"
            except InvalidTask:
                row["status"] = "invalid_task_output"
            except ProviderError as exc:
                row.update(status=exc.code.value, validation_code=exc.validation_code)
            row.update(
                usage=tasks.tokens,
                elapsed_seconds=time.monotonic() - started,
                network_calls=len(transport.records) - before,
            )
            row["validation_failures"] = [
                e["payload"]["validation_code"]
                for e in row["events"]
                if e["type"] == "task_finished" and e["payload"]["outcome"] != "success"
            ]
            rows.append(row)
            base.dump(ROOT / "results.json", rows)
            base.dump(ROOT / "provider-records.json", transport.records)
            print(
                json.dumps(
                    {
                        k: row[k]
                        for k in [
                            "trial",
                            "status",
                            "network_calls",
                            "validation_failures",
                        ]
                    }
                ),
                flush=True,
            )
            if row["status"] in {
                "authentication",
                "quota_exceeded",
                "configuration",
                "invalid_request",
                "network",
                "unavailable",
                "rate_limited",
            }:
                manifest["stopped_early"] = row["status"]
                break
    manifest.update(
        finished_at=datetime.now(UTC).isoformat(),
        trials_recorded=len(rows),
        network_attempts=len(transport.records),
        historical_databases_unchanged=all(
            base.sha(Path(f["database_path"]).read_bytes()) == f["database_sha256"]
            for f in fixtures
        ),
    )
    base.dump(ROOT / "manifest.json", manifest)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv", type=Path)
    asyncio.run(execute(parser.parse_args()))
