#!/usr/bin/env python3
"""Read saved replay artifacts only; never import or execute either pipeline arm."""

import argparse
import ast
from collections import Counter, defaultdict
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DISPLAY_ANCHORS = {
    'b0012': ['released it publicly in 1991', 'first official release of Python'],
    'b0002': ['second planet from the Sun'],
    'b0011': ['fixed 256-bit', '256-bit digest', '256-bit hash'],
    'b0026': ['12December 2015', '12 December 2015'],
}


def display_sample(case, spans):
    """Choose a diagnostic preview, never use these known probes to score correctness."""
    chosen, position, matched = spans[0], 0, None
    for needle in DISPLAY_ANCHORS.get(case, []):
        match = next((s for s in spans if needle.casefold() in s['text'].casefold()), None)
        if match:
            chosen, position, matched = match, match['text'].casefold().index(needle.casefold()), needle
            break
    start = max(0, position - 220)
    end = min(len(chosen['text']), start + 700)
    preview = chosen['text'][start:end].replace('\n', ' ')
    if start or end < len(chosen['text']):
        preview = ('… ' if start else '') + preview + (' …' if end < len(chosen['text']) else '')
        preview += ' [display shortened; full span retained in JSON]'
    return chosen, preview, matched


def validation_guidance():
    """Read the frozen validator's literal explanations without importing application code."""
    path = ROOT / 'baseline/src/aletheia/tasks.py'
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == 'REPAIR_GUIDANCE'
                for target in node.targets):
            return ast.literal_eval(node.value)
    return {}


def read(path, default=None):
    return json.loads(path.read_text()) if path.exists() else default


def payloads(events, name):
    return [e['payload'] for e in events if e['type'] == name]


def counts(values):
    return dict(sorted(Counter(str(v) for v in values).items()))


def decoded(text):
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        return None


def wire_order(call):
    """Check actual returned JSON order, not the supplied schema order."""
    orders = []
    for choice in call.get('public_response', {}).get('choices', []):
        value = decoded(choice.get('content'))
        if not isinstance(value, dict):
            continue
        for assessment in value.get('assessments', []):
            if not isinstance(assessment, dict):
                continue
            keys = list(assessment)
            orders.append({'keys': keys, 'rationale_before_relation':
                           keys.index('rationale') < keys.index('relation')
                           if 'rationale' in keys and 'relation' in keys else None})
    return orders


def sufficiency_inputs(evidence, snapshots):
    """Expose saved gate inputs without pretending to re-grade their truth or policy."""
    by_id = {s['id']: s for s in snapshots}
    result = []
    for item in evidence:
        a = item['assessment']
        source = by_id.get(a['citation']['snapshot_id'], {})
        result.append({
            'evidence_id': item['id'], 'component_id': a.get('component_id'),
            'relation': a['relation'], 'admissible': item['admissible'],
            'rejection_reason': item.get('rejection_reason'),
            'scope_match': a['scope_match'], 'url': source.get('url'),
            'authoritative_record_claimed': a['authoritative_record'],
            'credible_synthesis_claimed': a['credible_synthesis'],
            'synthesis_coverage': a.get('synthesis_coverage'),
            'independence': a['independence'], 'origin': a.get('origin'),
            'provenance_note': a.get('provenance_note'),
            'provenance_span_ids': a.get('provenance_span_ids'),
            'source_content_hash': source.get('content_hash'),
            'source_limitations': source.get('limitations'),
            'assessment_limitations': a.get('limitations'),
            'values': a.get('values'),
        })
    return result


def analyze_trial(directory):
    trial = read(directory / 'trial.json', {})
    investigation = read(directory / 'investigation.json', {})
    summary = read(directory / 'summary.json', {})
    events = read(directory / 'events.json', [])
    records = read(directory / 'records.json', [])
    budget = read(directory / 'budget.json', {})
    calls = [(path, read(path)) for path in sorted(directory.glob('model_*.json'))]
    snapshots = [r['payload'] for r in records if r['kind'] == 'snapshot']
    evidence = [r['payload'] for r in records if r['kind'] == 'evidence']
    finished = payloads(events, 'task_finished')
    model_attempts, assessment_inputs, preliminary = [], [], []
    # A task_call_id is shared by its initial attempt and one repair. Match in order.
    by_task = defaultdict(list)
    for event in finished:
        by_task[event.get('task_call_id')].append(event)
    seen_task_calls = Counter()
    for path, call in calls:
        trace = call.get('trace', {})
        task_id = trace.get('task_call_id')
        index = seen_task_calls[task_id]
        seen_task_calls[task_id] += 1
        matching = by_task[task_id]
        finish = matching[index] if index < len(matching) else None
        data = decoded(call.get('input_text')) or {}
        attempt = {
            'artifact': str(path.relative_to(directory)), 'call_number': call.get('call_number'),
            'trace': trace, 'provider_schema_state': call.get('state'),
            'task_finished': finish,
            'accepted_by_task_validation': finish.get('outcome') == 'success' if finish else None,
            'request_number': call.get('request_number'), 'status_code': call.get('status_code'),
            'error_type': call.get('error_type'), 'error_code': call.get('error_code'),
            'validation_code': call.get('validation_code'),
            'usage': call.get('public_response', {}).get('usage'),
            'finish_reasons': [c.get('finish_reason') for c in
                               call.get('public_response', {}).get('choices', [])],
            'response_capture_truncated': call.get('response_capture_truncated'),
            'public_response_parse_error': call.get('public_response_parse_error'),
            'original_response_content_available': any(isinstance(c.get('content'), str)
                for c in call.get('public_response', {}).get('choices', [])),
            'budget_before': call.get('budget_before'), 'budget_after': call.get('budget_after'),
        }
        if trace.get('task') == 'assess':
            attempt['actual_response_field_order'] = wire_order(call)
            assessment_inputs.append({
                'artifact': attempt['artifact'], 'snapshot_id': data.get('snapshot_id'),
                'url': data.get('url'), 'source_truncated': data.get('source_truncated'),
                'assertion': data.get('assertion'), 'spans': data.get('spans', []),
                'selected_chars': sum(len(s['text']) for s in data.get('spans', [])),
                'selected_count': len(data.get('spans', [])),
                'proposal': call.get('validated_result'),
                'task_finished': finish,
            })
        if trace.get('task') == 'synthesize':
            preliminary.append({'artifact': attempt['artifact'], 'finding': data.get('finding'),
                                'almost_eligible': data.get('almost_eligible')})
        model_attempts.append(attempt)
    final_checks = [read(p) for p in sorted(
        (directory / 'investigations.sqlite3.diagnostics').glob('*.json'))]
    result = investigation.get('result') or {}
    finding = result.get('finding') or {}
    status = investigation.get('status', summary.get('status', 'incomplete_artifacts'))
    stop = investigation.get('stop_reason', summary.get('stop_reason'))
    errors = [e for e in finished if e.get('outcome') != 'success']
    operational_events = [e for e in events if e['type'] in {
        'assessment_rejected', 'source_rejected', 'task_output_rejected', 'research_stopped',
        'pipeline_failed', 'search_incomplete', 'budget_reached', 'provider_call_rejected'}]
    # Exposure is separate for each intervention: selection changes precede assessments.
    exposure = {'snapshot_split_reached': bool(snapshots or assessment_inputs),
                'assessment_prompt_reached': bool(assessment_inputs),
                'assessment_task_accepted': any(a['task_finished'] and
                    a['task_finished'].get('outcome') == 'success' for a in assessment_inputs)}
    if not (directory / 'summary.json').exists():
        classification = 'incomplete_artifacts_do_not_classify_failure_location'
    elif not snapshots:
        classification = 'upstream_of_both_interventions'
    elif not assessment_inputs:
        classification = 'snapshot_reached_assessment_not_reached'
    elif status in {'failed', 'partial'} or stop in {
            'invalid_task_output', 'semantic_rejection', 'provider_failure', 'budget_exhausted',
            'deadline_exceeded', 'interrupted', 'storage_failure'}:
        classification = 'intervention_reached_operational_or_validation_limit'
    elif finding.get('outcome') == 'unable_to_decide':
        classification = 'abstention_requires_source_and_component_review'
    elif finding.get('outcome') == 'decided':
        classification = 'decided_requires_factual_and_explanation_review'
    else:
        classification = 'intervention_reached_no_final_finding'
    return {
        **trial, 'directory': str(directory), 'claim': investigation.get('claim'),
        'artifact_complete': (directory / 'summary.json').exists(),
        'status': status, 'stop_reason': stop, 'classification': classification,
        'finding': finding, 'explanation': result.get('explanation'),
        'claim_analysis': investigation.get('claim_analysis'),
        'candidate_stage_exposure': exposure,
        'stage_progression': [{'sequence': e['sequence'], 'stage': e.get('stage'),
                               'payload': e['payload']} for e in events
                              if e['type'] == 'stage_started'],
        'event_counts': counts(e['type'] for e in events),
        'task_outcome_counts': counts(f"{e.get('task')}:{e.get('outcome')}" for e in finished),
        'task_errors': errors,
        'assessment_errors': [e for e in errors if e.get('task') == 'assess'],
        'operational_events': operational_events,
        'research_gate_events': payloads(events, 'research_gate'),
        'snapshot_count': len(snapshots), 'evidence_count': len(evidence),
        'admitted_evidence_count': sum(e['admissible'] for e in evidence),
        'evidence_relation_counts': counts(e['assessment']['relation'] for e in evidence),
        'admitted_relation_counts': counts(e['assessment']['relation'] for e in evidence
                                           if e['admissible']),
        'source_sufficiency_inputs': sufficiency_inputs(evidence, snapshots),
        'preliminary_findings': preliminary,
        'final_check_rejections': final_checks,
        'model_call_count': len(calls),
        'network_model_requests': summary.get('network_model_requests',
                                            sum('request_number' in c for _, c in calls)),
        'model_attempts': model_attempts, 'budget': budget,
        'trace': {
            'queries': payloads(events, 'search_started'),
            'retrieval_calls': read(directory / 'retrieval_calls.json', []),
            'pages_selected': payloads(events, 'source_selected'),
            'pages_extracted': [{k: s.get(k) for k in ('id', 'url', 'title', 'content_hash',
                'limitations', 'splitter_version')} | {'span_count': len(s.get('spans', []))}
                for s in snapshots],
            'assessment_inputs': assessment_inputs,
            'admitted_and_rejected_evidence': evidence,
        },
        'runner_failure': read(directory / 'runner_failure.json'),
        'safe_failure': read(directory / 'safe_failure.json'),
    }


def aggregate(trials):
    groups = defaultdict(list)
    for trial in trials:
        groups[(trial.get('case'), trial.get('arm'))].append(trial)
    result = []
    for (case, arm), rows in sorted(groups.items()):
        result.append({
            'case': case, 'arm': arm, 'trials_started': len(rows),
            'artifacts_complete': sum(r['artifact_complete'] for r in rows),
            'status_counts': counts(r['status'] for r in rows),
            'stop_reason_counts': counts(r['stop_reason'] for r in rows),
            'finding_counts': counts(r['finding'].get('verdict') or
                                    r['finding'].get('outcome', 'none') for r in rows),
            'classification_counts': counts(r['classification'] for r in rows),
            'stage_exposure_counts': {k: sum(r['candidate_stage_exposure'][k] for r in rows)
                                      for k in rows[0]['candidate_stage_exposure']},
            'assessment_error_codes': counts(e.get('validation_code') for r in rows
                                             for e in r['assessment_errors']),
            'model_calls': sum(r['model_call_count'] for r in rows),
            'network_model_requests': sum(r['network_model_requests'] for r in rows),
            'evidence_records': sum(r['evidence_count'] for r in rows),
            'admitted_evidence': sum(r['admitted_evidence_count'] for r in rows),
            'final_semantic_rejections': sum(len(r['final_check_rejections']) for r in rows),
        })
    return result


def markdown(report):
    lines = ['# Isolated replay artifact summary', '',
             '**Capture limitation:** the wire-response audit has a compression parsing defect. '
             'Actual decoded pipeline responses are unchanged. Parsed, schema-valid proposals '
             'and task events remain available; original raw responses, their original key order, '
             'and text rejected before schema validation are unavailable. Exact response-order '
             'claims cannot be made. See `shared/capture-limitation.json`.', '',
             'Diagnostic probes only. Frozen retrieval excludes query quality; independent model '
             'calls prevent attributing every paired difference to the patch. A saved model '
             'proposal passing its schema does not mean task validation accepted it.', '',
             '| Claim | Arm | Started/complete | Status | Finding | Assessment errors | Calls |',
             '|---|---|---:|---|---|---|---:|']
    for row in report['case_arm_counts']:
        lines.append(f"| {row['case']} | {row['arm']} | {row['trials_started']}/"
                     f"{row['artifacts_complete']} | {row['status_counts']} | "
                     f"{row['finding_counts']} | {row['assessment_error_codes']} | "
                     f"{row['network_model_requests']} |")
    for trial in report['trials']:
        lines.extend(['', f"## {trial.get('case')} / {trial.get('repetition')} / {trial.get('arm')}",
                      '', trial.get('claim') or '(Claim artifact not yet available.)', '',
                      f"Status: **{trial['status']}**; stop: `{trial['stop_reason']}`; "
                      f"classification: `{trial['classification']}`.", '',
                      f"Stages: {' → '.join(s['stage'] or '?' for s in trial['stage_progression'])}",
                      f"Evidence: {trial['admitted_evidence_count']}/{trial['evidence_count']} "
                      f"admitted; final semantic rejections: {len(trial['final_check_rejections'])}.",
                      '', 'Queries:'])
        lines.extend(f"- {q.get('purpose')}: {q.get('query')}" for q in trial['trace']['queries'])
        lines.extend(['', 'Retrieved pages:'])
        lines.extend(f"- {s['url']} ({s['span_count']} saved spans)"
                     for s in trial['trace']['pages_extracted'])
        lines.extend(['', 'Assessment attempts:'])
        for attempt in trial['trace']['assessment_inputs']:
            event = attempt['task_finished'] or {}
            lines.append(f"- `{attempt['artifact']}`: {attempt['selected_count']} spans / "
                         f"{attempt['selected_chars']} characters; outcome "
                         f"`{event.get('outcome', 'pending')}`; validation "
                         f"`{event.get('validation_code')}`; {attempt['url']}")
        selected = trial['trace']['assessment_inputs']
        supplied_spans = [span for attempt in selected for span in attempt['spans']]
        if supplied_spans:
            span, preview, anchor = display_sample(trial.get('case'), supplied_spans)
            lines.extend(['', 'Selected-span sample (known diagnostic anchor when available; '
                          'display selection only):'])
            lines.extend(['', f"Span {span['id']} [{span.get('start')}:{span.get('end')}]: "
                          f"{preview}"])
        cited = [excerpt for item in trial['trace']['admitted_and_rejected_evidence']
                 for excerpt in item.get('excerpts', [])]
        if cited:
            excerpt, preview, anchor = display_sample(trial.get('case'), cited)
            lines.extend(['', f"Cited-span sample {excerpt['span_ids']} "
                          f"[{excerpt['start']}:{excerpt['end']}]: {preview}"])
        if trial['task_errors']:
            lines.extend(['', 'Recorded task failures:'])
            lines.extend(f"- {e.get('task')} attempt {e.get('attempt')}: "
                         f"`{e.get('outcome')}` / `{e.get('validation_code')}` "
                         f"(fields: {e.get('schema_fields')}; limit: {e.get('limit_reason')}). "
                         f"{report['validation_code_guidance'].get(e.get('validation_code'), '')}"
                         for e in trial['task_errors'])
        lines.extend(['', 'The JSON report retains exact selected spans, proposals, citations, '
                      'source-sufficiency inputs, final-check failures, and task acceptance. '
                      'Insufficient evidence is not automatically a factual error or a justified '
                      'abstention; inspect component coverage and source quality.'])
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=Path, default=ROOT / 'runs')
    parser.add_argument('--output', type=Path, default=ROOT / 'analysis/results')
    args = parser.parse_args()
    trials = [analyze_trial(p.parent) for p in sorted(args.runs.glob('*/*/*/trial.json'))]
    report = {
        'analysis_version': 1, 'runs': str(args.runs.resolve()),
        'validation_code_guidance': validation_guidance(),
        'capture_limitation': read(ROOT / 'shared/capture-limitation.json'),
        'started_trials': len(trials), 'case_arm_counts': aggregate(trials), 'trials': trials,
        'interpretation_limits': [
            'Counts are artifact-derived, not automatic factual quality scores.',
            'Source authority/independence fields are model claims requiring review.',
            'No final finding or completed status should be inferred from missing artifacts.',
            'Upstream failures do not test candidate assessment changes.',
            'A source-insufficient abstention can be appropriate; a missing comparison operand '
            'may instead identify a representation failure. Review exact components and evidence.',
        ],
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'analysis.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    (args.output / 'summary.md').write_text(markdown(report))
    print(json.dumps({'trials': len(trials), 'output': str(args.output.resolve())}))


if __name__ == '__main__':
    main()
