"""Offline analyzer checks; no application imports or provider access."""
import json
from pathlib import Path
import tempfile
import unittest

from analyze_replay import aggregate, analyze_trial


class AnalysisChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.write('trial.json', {'case': 'probe', 'arm': 'candidate', 'repetition': 1})

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value))

    def test_missing_outputs_do_not_imply_completed_or_exposed(self):
        row = analyze_trial(self.root)
        self.assertFalse(row['artifact_complete'])
        self.assertEqual(row['status'], 'incomplete_artifacts')
        self.assertEqual(row['classification'],
                         'incomplete_artifacts_do_not_classify_failure_location')
        self.assertEqual(row['network_model_requests'], 0)

    def test_provider_validation_is_separate_from_task_validation_and_repairs(self):
        self.write('investigation.json', {'status': 'partial', 'stop_reason': 'semantic_rejection'})
        self.write('records.json', [{'kind': 'snapshot', 'payload': {
            'id': 'source', 'spans': [{'id': 1, 'start': 0, 'end': 4, 'text': 'fact'}]}}])
        self.write('events.json', [
            {'sequence': i, 'type': 'task_finished', 'payload': {
                'task_call_id': 't1', 'task': 'assess', 'attempt': str(i),
                'outcome': outcome, 'validation_code': code}}
            for i, outcome, code in [(1, 'invalid_task_output', 'comparison_relation'),
                                     (2, 'success', 'unknown')]])
        for number in (1, 2):
            self.write(f'model_{number:02}.json', {
                'call_number': number, 'request_number': number, 'state': 'validated',
                'trace': {'task_call_id': 't1', 'task': 'assess'},
                'input_text': json.dumps({'snapshot_id': 'source', 'spans': [
                    {'id': 1, 'start': 0, 'end': 4, 'text': 'fact'}]}),
                'public_response': {'choices': [{'content': json.dumps({'assessments': [
                    {'rationale': 'reason', 'relation': 'context'}]})}]}})
        self.write('investigations.sqlite3.diagnostics/final.json', {
            'failed_conditions': ['unsupported_explanation']})
        row = analyze_trial(self.root)
        self.assertFalse(row['model_attempts'][0]['accepted_by_task_validation'])
        self.assertTrue(row['model_attempts'][1]['accepted_by_task_validation'])
        self.assertEqual(row['assessment_errors'][0]['validation_code'], 'comparison_relation')
        self.assertEqual(row['final_check_rejections'][0]['failed_conditions'],
                         ['unsupported_explanation'])
        self.assertEqual(row['trace']['assessment_inputs'][0]['spans'][0]['text'], 'fact')
        self.assertTrue(row['model_attempts'][0]['actual_response_field_order'][0]
                        ['rationale_before_relation'])
        grouped = aggregate([row])[0]
        self.assertEqual(grouped['assessment_error_codes'], {'comparison_relation': 1})
        self.assertEqual(grouped['network_model_requests'], 2)

    def test_abstention_not_automatically_labeled_error_or_success(self):
        self.write('summary.json', {})
        self.write('investigation.json', {'status': 'completed', 'result': {
            'finding': {'outcome': 'unable_to_decide', 'unable_to_decide_reason':
                        'insufficient_evidence'}}})
        self.write('records.json', [{'kind': 'snapshot', 'payload': {'id': 's'}}])
        self.write('model_01.json', {'trace': {'task': 'assess', 'task_call_id': 't1'},
                                   'input_text': '{}', 'state': 'validated'})
        row = analyze_trial(self.root)
        self.assertEqual(row['classification'], 'abstention_requires_source_and_component_review')


if __name__ == '__main__':
    unittest.main()
