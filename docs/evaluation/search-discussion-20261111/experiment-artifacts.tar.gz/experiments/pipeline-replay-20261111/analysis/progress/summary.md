# Isolated replay artifact summary

**Capture limitation:** the wire-response audit has a compression parsing defect. Actual decoded pipeline responses are unchanged. Parsed, schema-valid proposals and task events remain available; original raw responses, their original key order, and text rejected before schema validation are unavailable. Exact response-order claims cannot be made. See `shared/capture-limitation.json`.

Diagnostic probes only. Frozen retrieval excludes query quality; independent model calls prevent attributing every paired difference to the patch. A saved model proposal passing its schema does not mean task validation accepted it.

| Claim | Arm | Started/complete | Status | Finding | Assessment errors | Calls |
|---|---|---:|---|---|---|---:|
| b0002 | baseline | 2/2 | {'failed': 2} | {'none': 2} | {} | 4 |
| b0002 | candidate | 2/2 | {'failed': 2} | {'none': 2} | {} | 9 |
| b0011 | baseline | 2/2 | {'failed': 1, 'partial': 1} | {'none': 1, 'unable_to_decide': 1} | {'scope_flag': 1} | 12 |
| b0011 | candidate | 2/2 | {'failed': 2} | {'none': 2} | {'scope_flag': 1} | 10 |
| b0012 | baseline | 3/3 | {'failed': 3} | {'none': 3} | {} | 18 |
| b0012 | candidate | 3/2 | {'failed': 1, 'incomplete_artifacts': 1, 'partial': 1} | {'none': 2, 'unable_to_decide': 1} | {} | 15 |
| b0026 | baseline | 2/2 | {'partial': 2} | {'unable_to_decide': 2} | {'citation_spans': 2, 'scope_flag': 1} | 17 |
| b0026 | candidate | 2/2 | {'failed': 1, 'partial': 1} | {'none': 1, 'unable_to_decide': 1} | {} | 18 |

## b0002 / 1 / baseline

Venus is the closest planet to the Sun.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.
- interpret attempt 2: `invalid_task_output` / `comparison_method` (fields: unknown; limit: unknown). A component with comparison fields requires method record_comparison, not record_lookup.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0002 / 1 / candidate

Venus is the closest planet to the Sun.

Status: **failed**; stop: `invalid_task_output`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → extracting → verifying → planning → planning
Evidence: 2/4 admitted; final semantic rejections: 0.

Queries:
- support: Closest planet to the Sun in the solar system: Mercury
- support: Distance from Sun: Mercury 0.39 AU, Venus 0.72 AU
- contradiction: Is Venus ever closer to Sun than Mercury
- context: Mercury is the closest planet to the Sun in the solar system
- support: Venus orbital distance comparison to Mercury distance from Sun
- contradiction: Do any planets have orbits that bring them closer to the Sun than Mercury at any point

Retrieved pages:
- https://science.nasa.gov/venus/venus-facts (439 saved spans)
- https://www.ukcloudmagnets.co.uk/mercury-1 (46 saved spans)

Assessment attempts:
- `model_03.json`: 115 spans / 11999 characters; outcome `success`; validation `unknown`; https://science.nasa.gov/venus/venus-facts
- `model_04.json`: 32 spans / 2804 characters; outcome `success`; validation `unknown`; https://www.ukcloudmagnets.co.uk/mercury-1

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 285 [23178:23254]: Venus is the second planet from the Sun, and our closest planetary neighbor.

Cited-span sample [285] [23178:23254]: Venus is the second planet from the Sun, and our closest planetary neighbor.

Recorded task failures:
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.
- plan attempt 2: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0002 / 2 / baseline

Venus is the closest planet to the Sun.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.
- interpret attempt 2: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0002 / 2 / candidate

Venus is the closest planet to the Sun.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.
- interpret attempt 2: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0011 / 1 / baseline

The SHA-256 cryptographic hash algorithm produces a 256-bit digest.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.
- interpret attempt 2: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0011 / 1 / candidate

The SHA-256 cryptographic hash algorithm produces a 256-bit digest.

Status: **failed**; stop: `invalid_task_output`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → extracting → verifying → planning → planning
Evidence: 4/4 admitted; final semantic rejections: 0.

Queries:
- support: SHA-256 algorithm produces 256-bit digest documented in FIPS 180-4
- support: SHA-256 defined output length 256 bits in RFC 6232
- contradiction: SHA-256 output length differs from 256 bits claim
- support: FIPS 180-4 publication defining SHA-256 256-bit digest output
- support: RFC 6232 specification confirming SHA-256 produces 256-bit digest
- contradiction: SHA-256 algorithm independently invented or derived outside NSA NIST standardization

Retrieved pages:
- https://www.encryptionconsulting.com/education-center/sha-256 (195 saved spans)
- https://ssojet.com/dev-guides/sha-256-vs-shake256 (55 saved spans)

Assessment attempts:
- `model_03.json`: 110 spans / 11997 characters; outcome `invalid_task_output`; validation `scope_flag`; https://www.encryptionconsulting.com/education-center/sha-256
- `model_04.json`: 110 spans / 11997 characters; outcome `success`; validation `unknown`; https://www.encryptionconsulting.com/education-center/sha-256
- `model_05.json`: 52 spans / 5807 characters; outcome `success`; validation `unknown`; https://ssojet.com/dev-guides/sha-256-vs-shake256

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 21 [1238:1606]: **SHA-256 is a cryptographic hash function from the SHA-2 family, designed by the NSA and standardized by NIST. It takes any input and produces a fixed 256-bit (64-character hexadecimal) digest. SHA-256 is one-way: it cannot be reversed to recover the input. It is not encryption; it is used to verify integrity, in digital signatures, certificates, and blockchains.**

Cited-span sample [99] [10927:11039]: It takes an input of any size and produces a fixed 256-bit output, written as a 64-character hexadecimal string.

Recorded task failures:
- assess attempt 1: `invalid_task_output` / `scope_flag` (fields: unknown; limit: unknown). Narrower evidence cannot directly support the full claim scope.
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.
- plan attempt 2: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0011 / 2 / baseline

The SHA-256 cryptographic hash algorithm produces a 256-bit digest.

Status: **partial**; stop: `budget_exhausted`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → extracting → verifying → planning → planning → synthesizing
Evidence: 4/4 admitted; final semantic rejections: 0.

Queries:
- support: SHA-256 hash algorithm specification output digest size bits
- contradiction: SHA-256 256-bit digest standard confirmation from NIST FIPS publication
- context: SHA-256 digest size historical definition and any proposed changes
- support: NIST FIPS PUB 180-4 SHA-256 specification output digest size bits
- contradiction: SHA-256 algorithm specification historical definition and any proposed changes to output size
- context: Original SHA-256 specification from 2001 or earlier defining 256-bit digest output
- support: SHA-256 specification in Federal Information Processing Publication 180-4 with exact 256-bit digest output definition
- contradiction: Alternative cryptographic hash standard defining a different digest size for SHA-256

Retrieved pages:
- https://www.encryptionconsulting.com/education-center/sha-256 (195 saved spans)
- https://ssojet.com/dev-guides/sha-256-vs-shake256 (55 saved spans)

Assessment attempts:
- `model_03.json`: 110 spans / 11997 characters; outcome `success`; validation `unknown`; https://www.encryptionconsulting.com/education-center/sha-256
- `model_04.json`: 52 spans / 5807 characters; outcome `invalid_task_output`; validation `scope_flag`; https://ssojet.com/dev-guides/sha-256-vs-shake256
- `model_05.json`: 52 spans / 5807 characters; outcome `success`; validation `unknown`; https://ssojet.com/dev-guides/sha-256-vs-shake256

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 21 [1238:1606]: **SHA-256 is a cryptographic hash function from the SHA-2 family, designed by the NSA and standardized by NIST. It takes any input and produces a fixed 256-bit (64-character hexadecimal) digest. SHA-256 is one-way: it cannot be reversed to recover the input. It is not encryption; it is used to verify integrity, in digital signatures, certificates, and blockchains.**

Cited-span sample [99] [10927:11039]: It takes an input of any size and produces a fixed 256-bit output, written as a 64-character hexadecimal string.

Recorded task failures:
- assess attempt 1: `invalid_task_output` / `scope_flag` (fields: unknown; limit: unknown). Narrower evidence cannot directly support the full claim scope.
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0011 / 2 / candidate

The SHA-256 cryptographic hash algorithm produces a 256-bit digest.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.
- interpret attempt 2: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0012 / 1 / baseline

The original version of the Python programming language was first publicly released in 2001.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_numbers` (fields: unknown; limit: unknown). Retain every material detail: numbers and dates from the original must occur in component text, including modifiers.
- interpret attempt 2: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0012 / 1 / candidate

The original version of the Python programming language was first publicly released in 2001.

Status: **failed**; stop: `invalid_task_output`; classification: `upstream_of_both_interventions`.

Stages: interpreting
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_text` (fields: unknown; limit: unknown). Copy each component text as an exact contiguous substring of the original; put the subject in its separate field, without adding it to the quote.
- interpret attempt 2: `invalid_task_output` / `component_numbers` (fields: unknown; limit: unknown). Retain every material detail: numbers and dates from the original must occur in component text, including modifiers.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0012 / 2 / baseline

The original version of the Python programming language was first publicly released in 2001.

Status: **failed**; stop: `invalid_task_output`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → extracting → verifying → planning → planning
Evidence: 1/4 admitted; final semantic rejections: 0.

Queries:
- support: Python programming language first public release date 2001 original version
- contradiction: Python 0.9.0 initial release year historical record
- context: Python software foundation timeline initial release date Guido van Rossum
- support: Python 0.9.0 initial public release date and year 2001
- contradiction: Guido van Rossum Python language first public release 1991 historical record
- context: Python 1.0 release year and original version timeline

Retrieved pages:
- https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html (3 saved spans)
- https://www.youtube.com/shorts/xnpEox0O0uo (14 saved spans)

Assessment attempts:
- `model_04.json`: 2 spans / 18 characters; outcome `success`; validation `unknown`; https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html
- `model_05.json`: 14 spans / 740 characters; outcome `success`; validation `unknown`; https://www.youtube.com/shorts/xnpEox0O0uo

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 9 [233:380]: The first official release of Python occurred on February 20, 1991, marking Python's official birthday. #Python #programming #history #coding #tech

Cited-span sample [9] [233:380]: The first official release of Python occurred on February 20, 1991, marking Python's official birthday. #Python #programming #history #coding #tech

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_numbers` (fields: unknown; limit: unknown). Retain every material detail: numbers and dates from the original must occur in component text, including modifiers.
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.
- plan attempt 2: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0012 / 2 / candidate

The original version of the Python programming language was first publicly released in 2001.

Status: **partial**; stop: `budget_exhausted`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → extracting → verifying → planning → planning → synthesizing
Evidence: 0/4 admitted; final semantic rejections: 0.

Queries:
- support: Python 0.9.0 first public release date
- contradiction: Python 0.9.0 release year 2000 or 2001
- support: Python 0.9.0 first public release date year 2000 or 2001
- contradiction: Python initial release Guido van Rossum 1991 2000 2001 public version
- context: Python 1.0 release date official first public release version history
- support: Python 0.9.0 first public release date year
- support: Python 1.0 official first public release date version history
- contradiction: Guido van Rossum Python initial release year 1991 2000 2001 public version

Retrieved pages:
- https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html (37 saved spans)
- https://www.youtube.com/shorts/xnpEox0O0uo (14 saved spans)

Assessment attempts:
- `model_03.json`: 10 spans / 11590 characters; outcome `success`; validation `unknown`; https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html
- `model_04.json`: 14 spans / 740 characters; outcome `success`; validation `unknown`; https://www.youtube.com/shorts/xnpEox0O0uo

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 3 [20:1372]: … as the scripting language for the Amoeba operating system.[[2]](#ref2) Its design was inspired by a number of other languages, including C, Modula-3, and particularly the educational language ABC.[[3]](#ref3) Van Rossum released it publicly in 1991, and since then Python has been gathering a large and enthusiastic group of users including professional programmers, educators, and computer scientists. [display shortened; full span retained in JSON]

Cited-span sample [3] [20:1372]: … as the scripting language for the Amoeba operating system.[[2]](#ref2) Its design was inspired by a number of other languages, including C, Modula-3, and particularly the educational language ABC.[[3]](#ref3) Van Rossum released it publicly in 1991, and since then Python has been gathering a large and enthusiastic group of users including professional programmers, educators, and computer scientists. [display shortened; full span retained in JSON]

Recorded task failures:
- plan attempt 1: `invalid_task_output` / `query_identity` (fields: unknown; limit: unknown). Queries must be nonblank, distinct and new.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0012 / 3 / baseline

The original version of the Python programming language was first publicly released in 2001.

Status: **failed**; stop: `invalid_task_output`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → extracting → verifying → planning → planning
Evidence: 3/3 admitted; final semantic rejections: 0.

Queries:
- support: Python first public release date 2001
- contradiction: Python 0.9.0 release year
- context: Python Guido van Rossum first release timeline
- support: Guido van Rossum Python language first public release date 1991 vs 2001
- contradiction: Python 0.9.0 initial release year and date details
- context: Python language creation timeline pre 2000 official first release

Retrieved pages:
- https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html (3 saved spans)
- https://www.youtube.com/shorts/xnpEox0O0uo (14 saved spans)

Assessment attempts:
- `model_04.json`: 2 spans / 18 characters; outcome `success`; validation `unknown`; https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html
- `model_05.json`: 14 spans / 740 characters; outcome `success`; validation `unknown`; https://www.youtube.com/shorts/xnpEox0O0uo

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 9 [233:380]: The first official release of Python occurred on February 20, 1991, marking Python's official birthday. #Python #programming #history #coding #tech

Cited-span sample [9] [233:380]: The first official release of Python occurred on February 20, 1991, marking Python's official birthday. #Python #programming #history #coding #tech

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_numbers` (fields: unknown; limit: unknown). Retain every material detail: numbers and dates from the original must occur in component text, including modifiers.
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.
- plan attempt 2: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0012 / 3 / candidate

(Claim artifact not yet available.)

Status: **incomplete_artifacts**; stop: `None`; classification: `incomplete_artifacts_do_not_classify_failure_location`.

Stages: 
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:

Retrieved pages:

Assessment attempts:
- `model_05.json`: 10 spans / 11590 characters; outcome `pending`; validation `None`; https://www.cs.ubc.ca/wccce/Program03/papers/Toby.html
- `model_06.json`: 14 spans / 740 characters; outcome `pending`; validation `None`; https://www.youtube.com/shorts/xnpEox0O0uo

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 3 [20:1372]: … as the scripting language for the Amoeba operating system.[[2]](#ref2) Its design was inspired by a number of other languages, including C, Modula-3, and particularly the educational language ABC.[[3]](#ref3) Van Rossum released it publicly in 1991, and since then Python has been gathering a large and enthusiastic group of users including professional programmers, educators, and computer scientists. [display shortened; full span retained in JSON]

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0026 / 1 / baseline

The Paris Agreement was adopted at the United Nations climate conference in December 2015.

Status: **partial**; stop: `invalid_task_output`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → planning → planning → synthesizing
Evidence: 0/0 admitted; final semantic rejections: 0.

Queries:
- support: Paris Agreement adoption United Nations climate conference December 2015
- contradiction: UN climate conference Paris Agreement date and location December 2015
- context: Paris Agreement UN climate conference venue December 2015
- support: Paris Agreement adoption December 2015 UN climate conference venue and record
- contradiction: Paris Agreement adoption December 2015 date and venue in primary UN records
- context: Paris Agreement December 2015 adoption location venue United Nations climate conference records
- support: Paris Agreement adoption date December 2015 UN climate conference record
- contradiction: Paris Agreement adoption 2015 UN climate conference venue confirmation

Retrieved pages:
- https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf (338 saved spans)

Assessment attempts:
- `model_04.json`: 30 spans / 11996 characters; outcome `invalid_task_output`; validation `scope_flag`; https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf
- `model_05.json`: 30 spans / 11996 characters; outcome `invalid_task_output`; validation `citation_spans`; https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 5 [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_numbers` (fields: unknown; limit: unknown). Retain every material detail: numbers and dates from the original must occur in component text, including modifiers.
- assess attempt 1: `invalid_task_output` / `scope_flag` (fields: unknown; limit: unknown). Narrower evidence cannot directly support the full claim scope.
- assess attempt 2: `invalid_task_output` / `citation_spans` (fields: unknown; limit: unknown). Use only supplied span IDs, sorted in increasing order without duplicates.
- plan attempt 1: `invalid_task_output` / `query_gap` (fields: unknown; limit: unknown). Follow-up needs a named evidence gap.
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0026 / 1 / candidate

The Paris Agreement was adopted at the United Nations climate conference in December 2015.

Status: **partial**; stop: `budget_exhausted`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → planning → planning → synthesizing
Evidence: 3/3 admitted; final semantic rejections: 1.

Queries:
- support: Paris Agreement adoption United Nations climate conference December 2015 record
- contradiction: Paris Agreement adoption venue December 2015 UN climate conference alternate location
- context: Paris Agreement adoption date 2015 UN climate conference decision text
- support: Paris Agreement adopted 12 December 2015 United Nations climate conference COP 21 official record
- contradiction: Paris Agreement adoption date December 2015 alternate source or correction
- context: UN climate conference COP 21 Paris 2015 adoption venue and date primary record
- support: Paris Agreement adoption date and venue: UNFCCC COP 21 12 December 2015 official record
- contradiction: Paris Agreement adoption date and venue: alternative source stating different date or location

Retrieved pages:
- https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf (342 saved spans)

Assessment attempts:
- `model_03.json`: 31 spans / 11998 characters; outcome `success`; validation `unknown`; https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 5 [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Cited-span sample [5] [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Recorded task failures:
- plan attempt 1: `invalid_task_output` / `query_capacity` (fields: unknown; limit: unknown). Reduce queries to fit the remaining search capacity; retain counterevidence coverage when possible.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0026 / 2 / baseline

The Paris Agreement was adopted at the United Nations climate conference in December 2015.

Status: **partial**; stop: `budget_exhausted`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → planning → planning → synthesizing
Evidence: 2/2 admitted; final semantic rejections: 0.

Queries:
- support: Paris Agreement adoption United Nations climate conference December 2015 record
- contradiction: Paris Agreement adoption dissenting countries December 2015
- context: Paris Agreement United Nations climate conference venue December 2015
- support: Paris Agreement adoption by UNFCCC COP21 in December 2015 official record
- contradiction: Early draft or precursor documents of the Paris Agreement prior to December 2015
- context: UNFCCC conference venue and date records for December 2015 adoption of Paris Agreement
- support: Paris Agreement adoption on 12 December 2015 UNFCCC COP21 official record with explicit location and date
- contradiction: List of countries that dissented or did not adopt the Paris Agreement at UNFCCC COP21 December 2015

Retrieved pages:
- https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf (338 saved spans)

Assessment attempts:
- `model_03.json`: 30 spans / 11996 characters; outcome `invalid_task_output`; validation `citation_spans`; https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf
- `model_04.json`: 30 spans / 11996 characters; outcome `success`; validation `unknown`; https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 5 [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Cited-span sample [5] [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Recorded task failures:
- assess attempt 1: `invalid_task_output` / `citation_spans` (fields: unknown; limit: unknown). Use only supplied span IDs, sorted in increasing order without duplicates.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.

## b0026 / 2 / candidate

The Paris Agreement was adopted at the United Nations climate conference in December 2015.

Status: **failed**; stop: `semantic_rejection`; classification: `intervention_reached_operational_or_validation_limit`.

Stages: interpreting → planning → extracting → verifying → synthesizing
Evidence: 2/2 admitted; final semantic rejections: 2.

Queries:
- support: Paris Agreement adoption December 2015 UN climate conference
- contradiction: UN climate conference Paris Agreement adoption date 2015 record

Retrieved pages:
- https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf (342 saved spans)

Assessment attempts:
- `model_04.json`: 31 spans / 11998 characters; outcome `success`; validation `unknown`; https://unfccc.int/sites/default/files/resource/parisagreement_publication.pdf

Selected-span sample (known diagnostic anchor when available; display selection only):

Span 5 [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Cited-span sample [5] [277:392]: 1 INTRODUCTION The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015.

Recorded task failures:
- interpret attempt 1: `invalid_task_output` / `component_numbers` (fields: unknown; limit: unknown). Retain every material detail: numbers and dates from the original must occur in component text, including modifiers.

The JSON report retains exact selected spans, proposals, citations, source-sufficiency inputs, final-check failures, and task acceptance. Insufficient evidence is not automatically a factual error or a justified abstention; inspect component coverage and source quality.
