"""Read-only grading assembly from frozen replay artifacts; no provider or network calls."""
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / 'runs'
assert len(list(RUNS.glob('*/*/*/summary.json'))) == 24
per_trial = []
counts = {}
for arm in ('baseline', 'candidate'):
    stats = Counter()
    validation_codes = Counter()
    for p in sorted(RUNS.glob(f'*/*/{arm}/summary.json')):
        directory = p.parent
        name = str(directory.relative_to(RUNS))
        s = json.loads(p.read_text())
        inv = json.loads((directory / 'investigation.json').read_text())
        events = json.loads((directory / 'events.json').read_text())
        calls = [json.loads(q.read_text()) for q in sorted(directory.glob('model_*.json'))]
        finished = [e['payload'] for e in events if e['type'] == 'task_finished']
        rejected = [e for e in finished if e.get('outcome') != 'success']
        diagnostics = [json.loads(q.read_text()) for q in (directory / 'investigations.sqlite3.diagnostics').glob('*.json')]
        result = inv.get('result')
        stats['trials'] += 1
        stats[s['status']] += 1
        stats['model_requests'] += s['network_model_requests']
        stats['fatal_interpretation_trials'] += s['tasks'] == ['interpret', 'interpret']
        stats['trials_reaching_assessment'] += s['candidate_stage_exposure']['assess_task_called']
        stats['assessment_attempts'] += sum(e.get('task') == 'assess' for e in finished)
        stats['assessment_attempts_accepted_by_task_validator'] += sum(e.get('task') == 'assess' and e.get('outcome') == 'success' for e in finished)
        stats['final_checker_null_decision_attempts'] += sum(c['trace'].get('task') == 'check_explanation' and c.get('validated_result', {}).get('decision_supported', 'absent') is None for c in calls)
        stats['final_semantic_rejections'] += len(diagnostics)
        stats['fatal_query_capacity_trials'] += bool(s['status'] == 'failed' and len(rejected) >= 2 and all(e.get('validation_code') == 'query_capacity' for e in rejected[-2:]))
        stats['published_decided_verdicts'] += bool(result and result['outcome'] == 'decided')
        stats['published_undecided_results'] += bool(result and result['outcome'] == 'unable_to_decide')
        validation_codes.update(e.get('validation_code') for e in rejected)
        per_trial.append({
            'trial': name, 'status': s['status'], 'stop_reason': s['stop_reason'],
            'outcome': result['outcome'] if result else None,
            'verdict': result['verdict'] if result else None,
            'model_requests': s['network_model_requests'],
            'assessment_reached': s['candidate_stage_exposure']['assess_task_called'],
            'task_rejections': [{'task': e.get('task'), 'code': e.get('validation_code')} for e in rejected],
            'final_semantic_rejections': [{'conditions': d['failed_conditions'], 'affected_units': d.get('affected_units', [])} for d in diagnostics],
            'published_explanation': result.get('explanation', []) if result else [],
        })
    counts[arm] = {**dict(stats), 'task_rejection_codes': dict(validation_codes)}

report = {
    'status': 'Independent review complete for all 24 completed isolated trials',
    'basis': 'Expected semantic/source-policy distinctions frozen before live calls in expected-cases.json. Review read actual typed task outputs, selected excerpts, evidence, task events, final diagnostics and published results. No new model or network calls.',
    'headline': 'No improvement in end-to-end decided answers: one correct Paris True out of twelve trials in each arm. Both arms also produced three undecided results and eight failures. Candidate repaired Python passage availability when reached, but scope, authority, interpretation, planning and final-check failures remain.',
    'counts': counts,
    'counting_notes': [
        'Task acceptance is structural/application validation, not independent semantic correctness.',
        'Assessment attempts include repairs and are conditional on surviving interpretation; 15/16 versus 12/16 is not a randomized assessment-only causal estimate.',
        'Final semantic rejection counts are attempt-level: candidate Paris repetition 1 and 3 recover; candidate Paris repetition 2 and Venus repetition 3 do not. Baseline SHA repetition 3 also has one checker rejection before later synthesis fails.',
        'Fatal query capacity counts exclude recoverable planning errors and partial results that preserved an honest abstention.'
    ],
    'case_reviews': {
        'b0012': {
            'local_success': 'In both repetitions that reached UBC assessment, baseline received only 18 characters in two formatting spans; candidate selected 11590 characters and included Python antecedent and 1991 release sentence.',
            'semantic_failure': 'Candidate repetitions 2 and 3 explicitly call 1991 direct counterevidence to 2001 but set scope_match=false. Baseline similarly mishandles YouTube counterevidence. Different year for the same event is not a different scope.',
            'authority_failure': 'Candidate repetition 2 marks the pedagogical paper authoritative; repetition 3 marks the YouTube source authoritative despite its own source caveat. These flags are not justified merely by text stating a date.',
            'publication': 'No decided answer. Candidate repetitions 2 and 3 abstain without prose. Insufficiency can remain appropriate for this frozen secondary-source corpus even after scope is repaired.',
            'evidence_paths': ['runs/b0012/2/baseline/model_04.json', 'runs/b0012/2/candidate/model_03.json', 'runs/b0012/3/candidate/model_05.json']
        },
        'b0002': {
            'semantic_failure': 'NASA explicitly says Venus second from the Sun; both arms sometimes treat this as mere context or scope mismatch because it does not enumerate every planet. That ignores direct counterevidence to closest.',
            'authority_failure': 'Relevant NASA record repeatedly marked non-authoritative without a sufficient factual reason.',
            'unsupported_attempted_addition': 'Candidate repetition 3 adds Mercury as closest in synthesis while citing only NASA evidence with Venus second/orbital distance/Earth-neighbor passages. Assessor rationale also falsely places Earth between Venus and Sun. Final checker lists the explanation unit as supported despite the citation gap.',
            'publication': 'No final prose from this candidate trial was published: decision_supported=null on both final checks blocks publication. Other trials fail interpretation or planning.',
            'evidence_paths': ['runs/b0002/1/candidate/model_03.json', 'runs/b0002/3/candidate/model_05.json', 'runs/b0002/3/candidate/model_09.json', 'runs/b0002/3/candidate/model_12.json']
        },
        'b0011': {
            'semantic_success': 'Most reached assessments correctly read fixed 256-bit output; source insufficiency is plausible because frozen guides are secondary and independence is not demonstrated.',
            'semantic_failure': 'Candidate repetition 3 marks explicit Encryption Consulting support as context because it is a specification rather than a measured numeric quantity, conflating the empty values field with support relation.',
            'unsupported_published_addition': 'Baseline repetition 2 publishes multiple authoritative statements confirming the specification while its assessments mark authoritative_record=false and use secondary guides. The digest fact is supported; the added authority characterization is not established. Headline remains unable_to_decide while prose affirms the claim.',
            'additional_failure': 'Baseline repetition 3 overclassifies the educational source authoritative, then repeatedly proposes Almost corrections while saying no correction is needed. A checker null and subsequent correction_ineligible failures prevent publication.',
            'evidence_paths': ['runs/b0011/2/baseline/investigation.json', 'runs/b0011/3/baseline/model_09.json', 'runs/b0011/3/candidate/model_03.json']
        },
        'b0026': {
            'correct_completed_results': 'Both repetition 3 True outputs are grounded in cited official UNFCCC passages: adoption at the 21st Conference of Parties on 12 December 2015, DONE at Paris date clause, and formal adoption under United Nations Framework Convention on Climate Change. The combined citations adequately supply institution/date/location context. Candidate prose is shorter; neither success demonstrates a higher completion rate.',
            'authority_failure': 'Candidate repetition 1 and baseline repetition 2 read correct adoption facts but mark official narrow-record evidence non-authoritative, citing missing broader context/truncation. The remaining document tail is unnecessary for this narrow adoption record.',
            'final_checker_failure': 'Candidate repetition 2 reaches a supported provisional True, but decision_supported=null on both final checks produces semantic_rejection. Null is not evidence of contradictory source facts.',
            'partial_publication_issue': 'Candidate repetition 1 and baseline repetition 2 publish an undecided headline with prose affirming adoption. Date/adoption are grounded; prose fails to explain the abstention. Candidate repetition 1 institutional label expansion is not explicit in its two cited excerpts, unlike both repetition 3 successes which also cite formal UNFCCC adoption wording.',
            'evidence_paths': ['runs/b0026/1/candidate/records.json', 'runs/b0026/2/candidate/model_08.json', 'runs/b0026/3/candidate/records.json', 'runs/b0026/3/baseline/records.json']
        }
    },
    'cross_cutting_findings': [
        {'failure': 'Interpretation contract', 'finding': 'Seven trials terminate before assessment. Component substring/numeral checks fail although dates can be present in other component fields. Other outputs invent version 1.0 or mix lookup/comparison. Candidate does not change this stage.'},
        {'failure': 'Scope and relation consistency', 'finding': 'A different release date or second-versus-closest is repeatedly treated as mismatched scope even when rationale says direct contradiction. These outputs pass application validation but are semantically wrong.'},
        {'failure': 'Authority is a separate decision', 'finding': 'Models alternately understate primary NASA/UNFCCC authority and overstate UBC/YouTube/secondary-guide authority. Do not repair by forcing all supportive passages authoritative.'},
        {'failure': 'Planner capacity', 'finding': 'Six trials terminate after plan and repair both exceed current query capacity. This is downstream control-contract failure, not proof additional web results would solve the claim.'},
        {'failure': 'Final checker nullable decision', 'finding': 'Seven final checker attempts return decision_supported=null while sometimes saying units are supported. Six are candidate attempts; one baseline. The validator blocks or retries; null does not explain whether the assertion or authority policy is wrong.'},
        {'failure': 'Correction object misuse', 'finding': 'Baseline synthesis proposes Almost objects even when no correction is needed, causing four correction_ineligible attempt rejections across SHA and Paris.'},
        {'failure': 'Explanation cap and unfinished prose', 'finding': 'Candidate Venus repetition 3 repair and Paris repetition 2 initial synthesis are exactly 300 characters and end mid-sentence. Current generation cap remains 300; no evidence application code sliced these outputs, and raw wire capture is unavailable.'},
        {'failure': 'Publication consistency and citation grounding', 'finding': 'At least one accepted baseline SHA explanation adds unsupported authority characterization; some partial outputs affirm claims without explaining undecided headlines. Final checker sometimes marks unsupported extra claims grounded even when another decision check prevents publication.'}
    ],
    'audit_limitations': [
        'Every model request lacks raw public_response capture because capture tee saw encoded transport bytes; local gzip reproduction supports this diagnosis but live response encoding headers were not retained. Typed schema-valid values and task/evidence/diagnostic records remain. Exact raw field order and schema-rejected raw bodies cannot be reviewed.',
        'Fixed retrieval reconstructs saved corpus with blank search snippets and synthetic ordering. It cannot evaluate query quality, new authoritative sources, original SERP faithfulness, or missing extracted tails.',
        'Three stochastic repetitions of four known cases are diagnostics, not held-out accuracy evidence. Interpretation differs independently between arms and changes downstream exposure.',
        'Candidate is a bundled port of bounded splitting, rationale schema order and rationale cap relaxation. It omits prior whole-claim abstention normalization and is not a literal reproduction of the earlier simplified experiment.'
    ],
    'recommendation': 'Keep production unchanged. Treat passage repair as locally confirmed, not an end-to-end win. Next isolate and test interpretation/structured-output fidelity, contradiction-versus-scope and authority classifications, planner capacity handling, and final decision/prose consistency with fixed upstream inputs; preserve source-policy gates and distinguish legitimate abstention from pipeline failure.',
    'trials': per_trial,
}
(ROOT / 'review/final-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'counts': counts, 'review': str(ROOT / 'review/final-review.json')}, indent=2))
