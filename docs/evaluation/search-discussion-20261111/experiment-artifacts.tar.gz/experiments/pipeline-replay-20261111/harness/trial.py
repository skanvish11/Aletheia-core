"""One isolated actual-pipeline invocation; imported source arm selected before application imports."""

import argparse
import asyncio
import json
import sqlite3
import sys
import time
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path

from run_replay import MODEL, ROOT, SETTINGS, read, verify, write_new


def update(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n"
    )
    temporary.chmod(0o600)
    temporary.replace(path)


def build_adapters():
    import httpx
    from aletheia.providers.tavily import TavilyProvider
    from pydantic import SecretStr

    class CorpusTransport(httpx.AsyncBaseTransport):
        def __init__(self, sources, directory):
            self.sources = sources
            self.directory = directory
            self.calls = []

        async def handle_async_request(self, request):
            assert request.url.host == "api.tavily.com"
            payload = json.loads(request.content)
            operation = request.url.path.strip("/")
            if operation == "search":
                response = {
                    "results": [
                        {
                            "url": s["url"],
                            "title": s["title"],
                            "content": "",
                            "score": 1.0 - index * 0.01,
                            "published_date": s["published_date"],
                        }
                        for index, s in enumerate(
                            self.sources[: payload["max_results"]]
                        )
                    ]
                }
            elif operation == "extract":
                assert len(payload["urls"]) == 1
                url = payload["urls"][0]
                source = next((s for s in self.sources if s["url"] == url), None)
                response = {
                    "results": [{"url": url, "raw_content": source["original_text"]}]
                    if source
                    else [],
                    "failed_results": [] if source else [{"url": url}],
                }
            else:
                raise RuntimeError("Unexpected retrieval endpoint")
            self.calls.append(
                {
                    "operation": operation,
                    "payload": payload,
                    "returned_urls": [s["url"] for s in response["results"]],
                    "failed_urls": [
                        s["url"] for s in response.get("failed_results", [])
                    ],
                }
            )
            if self.directory:
                update(self.directory / "retrieval_calls.json", self.calls)
            return httpx.Response(200, json=response, request=request)

    class ReplaySearch:
        def __init__(self, settings, sources, directory=None):
            self.settings = settings.model_copy(
                update={"tavily_api_key": SecretStr("offline-replay-only")}
            )
            self.sources = sources
            self.transport = CorpusTransport(sources, directory)
            self.provider = TavilyProvider(self.settings, transport=self.transport)

        async def search(self, *args, **kwargs):
            return await self.provider.search(*args, **kwargs)

        async def extract(self, *args, **kwargs):
            result = await self.provider.extract(*args, **kwargs)
            pages = []
            for page in result.pages:
                source = next((s for s in self.sources if s["url"] == page.url), None)
                if (
                    source
                    and page.content is not None
                    and "page_text_truncated" in source["limitations"]
                ):
                    page = replace(
                        page,
                        truncated=True,
                        limitations=tuple(
                            dict.fromkeys((*page.limitations, "page_text_truncated"))
                        ),
                    )
                pages.append(page)
            # The actual gather path extracts one URL at a time; retain that page's capture date.
            first = next(
                (s for s in self.sources if pages and s["url"] == pages[0].url), None
            )
            return replace(
                result,
                pages=tuple(pages),
                retrieved_at=datetime.fromisoformat(first["retrieved_at"])
                if first
                else result.retrieved_at,
            )

        async def aclose(self):
            await self.provider.aclose()

    class CaptureStream(httpx.AsyncByteStream):
        def __init__(self, original, record, save, limit):
            self.original, self.record, self.save, self.limit = (
                original,
                record,
                save,
                limit,
            )
            self.parts = bytearray()
            self.too_large = False

        async def __aiter__(self):
            async for chunk in self.original:
                if len(self.parts) + len(chunk) <= self.limit:
                    self.parts.extend(chunk)
                else:
                    self.too_large = True
                yield chunk

        async def aclose(self):
            await self.original.aclose()
            self.record["response_capture_truncated"] = self.too_large
            if not self.too_large:
                try:
                    envelope = json.loads(self.parts)
                    # Do not record hidden reasoning or arbitrary provider error text.
                    self.record["public_response"] = {
                        "choices": [
                            {
                                "content": item.get("message", {}).get("content"),
                                "refusal": bool(item.get("message", {}).get("refusal")),
                                "finish_reason": item.get("finish_reason"),
                            }
                            for item in envelope.get("choices", [])
                        ],
                        "usage": {
                            key: envelope.get("usage", {}).get(key)
                            for key in (
                                "prompt_tokens",
                                "completion_tokens",
                                "total_tokens",
                            )
                        },
                    }
                except (ValueError, TypeError, AttributeError):
                    self.record["public_response_parse_error"] = True
            self.save()

    class AuditTransport(httpx.AsyncBaseTransport):
        def __init__(self, directory, settings, inner=None):
            self.directory, self.settings = directory, settings
            self.inner = (
                inner
                if inner is not None
                else httpx.AsyncHTTPTransport(retries=0, trust_env=False)
            )
            self.current = None
            self.count = 0

        async def handle_async_request(self, request):
            assert request.url.host == "api.tokenfactory.nebius.com"
            assert request.url.path == "/v1/chat/completions"
            assert self.current is not None
            if self.count >= 16:
                raise RuntimeError("Per-trial transport request cap reached")
            payload = json.loads(request.content)
            assert payload["model"] == MODEL and payload["store"] is False
            self.count += 1
            record, save = self.current
            record.update(request_number=self.count, public_request=payload)
            save()
            response = await self.inner.handle_async_request(request)
            if response.is_stream_consumed:
                response = httpx.Response(
                    response.status_code,
                    headers=response.headers,
                    stream=httpx.ByteStream(response.content),
                    extensions=response.extensions,
                    request=request,
                )
            record["status_code"] = response.status_code
            save()
            response.stream = CaptureStream(
                response.stream, record, save, self.settings.max_response_bytes
            )
            return response

        async def aclose(self):
            await self.inner.aclose()

    class TrackingModel:
        def __init__(self, provider, transport, directory):
            self.provider, self.transport, self.directory = (
                provider,
                transport,
                directory,
            )
            self.settings = provider.settings
            self.calls = []

        async def generate(self, **kwargs):
            budget = kwargs["budget"]
            number = len(self.calls) + 1
            record = {
                "call_number": number,
                "trace": dict(budget.trace_context),
                "budget_before": budget.trace_budget(),
                "instructions": kwargs["instructions"],
                "input_text": kwargs["input_text"],
                "schema": kwargs["response_type"].model_json_schema(),
                "state": "pending",
            }
            self.calls.append(record)
            path = self.directory / f"model_{number:02d}.json"
            save = lambda: update(path, record)
            save()
            self.transport.current = record, save
            try:
                result = await self.provider.generate(**kwargs)
                record.update(
                    state="schema_validated",
                    validated_result=result.value.model_dump(mode="json"),
                )
                return result
            except Exception as exc:
                record.update(
                    state="rejected",
                    error_type=type(exc).__name__,
                    error_code=getattr(getattr(exc, "code", None), "value", None),
                    validation_code=getattr(exc, "validation_code", None),
                )
                raise
            finally:
                record["budget_after"] = budget.trace_budget()
                save()
                self.transport.current = None

    return ReplaySearch, AuditTransport, TrackingModel


async def execute(args, *, offline=False, offline_case=None, offline_transport=None):
    import httpx
    from aletheia.budgets import RunBudget
    from aletheia.config import ProviderSettings
    from aletheia.contracts import InvestigationRequest
    from aletheia.orchestrator import Pipeline
    from aletheia.providers.nebius import NebiusProvider
    from aletheia.storage import Storage
    from pydantic import SecretStr

    ReplaySearch, AuditTransport, TrackingModel = build_adapters()
    case = (
        offline_case
        if offline and offline_case is not None
        else read(ROOT / "shared/fixtures.json")["cases"][args.case]
    )
    directory = Path(args.output)
    db = directory / "investigations.sqlite3"
    if db.exists() or list(directory.glob("model_*.json")):
        raise RuntimeError("Refusing reused trial persistence")
    if offline:
        settings = ProviderSettings(
            nebius_api_key=SecretStr("offline-only"), **SETTINGS
        )
        inner = offline_transport or httpx.MockTransport(
            lambda request: httpx.Response(
                200,
                json={
                    "choices": [
                        {
                            "message": {"role": "assistant", "content": "{}"},
                            "finish_reason": "stop",
                        }
                    ]
                },
                request=request,
            )
        )
    else:
        # The runtime loader is the only credential access. Never inspect dotenv or environment.
        loaded = ProviderSettings.from_environment(dotenv_path=Path(args.dotenv))
        settings = loaded.model_copy(update=SETTINGS)
        inner = None
    write_new(directory / "public_settings.json", SETTINGS)
    transport = AuditTransport(directory, settings, inner=inner)
    provider = NebiusProvider(settings, transport=transport)
    model = TrackingModel(provider, transport, directory)
    search = ReplaySearch(settings, case["sources"], directory)
    storage = Storage(db)
    await storage.initialize()
    request = InvestigationRequest(claim=case["claim"], context=case["context"])
    submitted = await storage.submit(request)
    investigation = await storage.claim_next()
    assert investigation.id == submitted.id
    budgets = []

    def factory():
        value = RunBudget()
        budgets.append(value)
        return value

    started = time.monotonic()
    execution_error = None
    try:
        await Pipeline(storage, model, search, MODEL, budget_factory=factory).run(
            investigation
        )
    except Exception as exc:  # noqa: BLE001 -- retain safe exception type, never sensitive values
        execution_error = type(exc).__name__
    finally:
        await provider.aclose()
        await search.aclose()
    saved = await storage.get(investigation.id)
    events = [
        event.model_dump(mode="json")
        for event in await storage.events(investigation.id)
    ]
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as connection:
        records = [
            {"kind": row[0], "record_id": row[1], "payload": json.loads(row[2])}
            for row in connection.execute(
                "SELECT kind,record_id,payload_json FROM research_records ORDER BY rowid"
            )
        ]
    write_new(directory / "investigation.json", saved.model_dump(mode="json"))
    write_new(directory / "events.json", events)
    write_new(directory / "records.json", records)
    write_new(
        directory / "budget.json",
        {
            "used": budgets[0].used,
            "limits": budgets[0].trace_budget(),
            "attempts": [asdict(item) for item in budgets[0].attempts],
        },
    )
    tasks = [item["trace"].get("task") for item in model.calls]
    first_error = next(
        (
            event
            for event in events
            if event["type"]
            in {
                "task_output_rejected",
                "assessment_rejected",
                "source_rejected",
                "search_incomplete",
                "research_stopped",
                "final_check_rejected",
            }
            or (
                event["type"] == "task_finished"
                and event["payload"].get("outcome") != "success"
            )
        ),
        None,
    )
    systemic_codes = {
        "authentication",
        "quota_exceeded",
        "configuration",
        "network",
        "unavailable",
    }
    summary = {
        "status": saved.status,
        "stop_reason": saved.stop_reason,
        "network_model_requests": transport.count,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "tasks": tasks,
        "first_failure_event": first_error,
        "candidate_stage_exposure": {
            "snapshots_created": any(r["kind"] == "snapshot" for r in records),
            "assess_task_called": any("assess" in (name or "") for name in tasks),
        },
        "execution_error_type": execution_error,
        "systemic_provider_failure": any(
            call.get("error_code") in systemic_codes
            or call.get("status_code") in {401, 402, 403, 429, 432, 433, 500, 502, 503}
            for call in model.calls
        ),
    }
    write_new(directory / "summary.json", summary)
    if execution_error:
        raise RuntimeError("Pipeline execution exception; safe type saved")
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=("baseline", "candidate"), required=True)
    parser.add_argument("--case", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--dotenv", required=True)
    args = parser.parse_args()
    verify()
    sys.path.insert(0, str(ROOT / args.arm / "src"))
    try:
        asyncio.run(execute(args))
    except Exception as exc:  # noqa: BLE001 -- retain safe exception type, never sensitive values
        target = Path(args.output) / "safe_failure.json"
        if not target.exists():
            write_new(target, {"type": type(exc).__name__})
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
