"""Immutable, bounded, fixed-corpus actual-pipeline replay. No live calls by default."""

import argparse
import hashlib
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
CASES = ("b0012", "b0002", "b0011", "b0026")
ARMS = ("baseline", "candidate")
MODEL = "nvidia/Nemotron-3_5-Lightning"
SETTINGS = {
    "nebius_model": MODEL,
    "nebius_response_format": "json_schema",
    "nebius_thinking": "disabled",
    "max_output_tokens": 4096,
    "timeout_seconds": 45.0,
    "max_retries": 0,
    "max_extracted_chars": 100000,
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, default=str)
        stream.write("\n")
    path.chmod(0o600)


def read(path):
    return json.loads(path.read_text())


def code_hashes():
    paths = [p for arm in ARMS for p in (ROOT / arm / "src").rglob("*.py")]
    paths += list((ROOT / "harness").glob("*.py"))
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(paths)}


def fixtures():
    target = ROOT / "shared/fixtures.json"
    if target.exists():
        raise SystemExit("Fixtures already exist; refusing automatic overwrite.")
    result = {"cases": {}, "source_artifacts": {}}
    pilot = REPO / "aletheia-phase-one/data/phase-one-pilot-reviewed-20261110"
    for case in CASES:
        report = pilot / case / f"{case}.json"
        db = pilot / case / "investigations.sqlite3"
        original = read(report)["investigation"]
        with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as connection:
            rows = connection.execute(
                "SELECT payload_json FROM research_records WHERE kind='snapshot' ORDER BY rowid"
            ).fetchall()
        sources = []
        for row in rows:
            source = json.loads(row[0])
            if not isinstance(source.get("original_text"), str):
                raise SystemExit(
                    "Saved original_text is required; no normalized-text substitution."
                )
            sources.append(
                {
                    key: source[key]
                    for key in (
                        "url",
                        "canonical_url",
                        "title",
                        "published_date",
                        "retrieved_at",
                        "original_text",
                        "normalized_text",
                        "content_hash",
                        "limitations",
                    )
                }
            )
        if not sources or len({s["url"] for s in sources}) != len(sources):
            raise SystemExit("Missing or duplicate cached source URL.")
        result["cases"][case] = {
            "claim": original["claim"],
            "context": original["context"],
            "sources": sources,
        }
        for path in (report, db):
            result["source_artifacts"][str(path.relative_to(REPO))] = digest(path)
    write_new(target, result)
    print("Frozen original-text fixtures for four cases; no expected labels included.")


def freeze():
    fixture = ROOT / "shared/fixtures.json"
    if not fixture.exists():
        raise SystemExit("Prepare fixtures first.")
    schedule = []
    for rep in range(1, 4):
        for position, case in enumerate(CASES):
            for arm in ARMS if (rep + position) % 2 else tuple(reversed(ARMS)):
                schedule.append({"case": case, "repetition": rep, "arm": arm})
    protocol = {
        "version": 1,
        "base_revision": "0246699a9e478b4588a38df252a0a047a4910624",
        "cases": CASES,
        "repetitions": 3,
        "maximum_investigations": 24,
        "maximum_model_requests": 384,
        "maximum_model_requests_per_trial": 16,
        "settings": SETTINGS,
        "sampling": "Provider defaults; no seed or sampling override.",
        "schedule": schedule,
        "fixture_sha256": digest(fixture),
        "code_sha256": code_hashes(),
        "retrieval": {
            "mode": "fixed saved extracted corpus, independent of generated query",
            "search_results": "All cached URLs in historical snapshot insertion order; blank snippets; synthetic score 1 - rank_index * .01; limited to requested max_results.",
            "extraction": "Actual TavilyProvider MockTransport parses exact original_text; unknown URLs deterministically fail. No Tavily network.",
            "truncation": "Historical page_text_truncated is retained; unavailable tails cannot be restored.",
            "dates": "Historical retrieval timestamp is retained for extracted pages.",
            "budgets": "Actual RunBudget: quick 10/4/4/120s; deep 16/8/10/240s; finalization reserve 4 model attempts/45s. Search and extract mock requests consume real budget units.",
        },
        "interpretation": "Independent real model calls per trial; no upstream output sharing. End-to-end stochastic comparison, not causal attribution of each paired difference.",
        "limitations": [
            "Historical search response bodies are unavailable; retrieval ranking and query quality are excluded.",
            "Four previously examined cases are diagnostic probes, not held-out accuracy estimates.",
            "Historical extracted prefixes may lack decisive information; candidate cannot recover missing source text.",
            "Provider timing can trigger unchanged actual deadlines differently across arms.",
        ],
        "capture_semantics": "schema_validated/validated_result mean provider JSON schema acceptance only. Actual task_finished outcomes and persisted evidence determine semantic acceptance. Final semantic rejection diagnostics are sidecars beside the fresh SQLite file.",
        "capture": "Per-task safe input, actual public request JSON, raw message.content, public usage/status, validated result/error, all SQLite events/records, final-check diagnostics. No headers, credential values or hidden reasoning.",
        "reruns": "No overwriting, automatic rerun or automatic resume; every started trial remains on disk.",
    }
    write_new(ROOT / "shared/protocol.json", protocol)
    print("Frozen protocol: 24 trials, maximum 384 model requests.")


def verify():
    protocol = read(ROOT / "shared/protocol.json")
    if protocol["code_sha256"] != code_hashes():
        raise SystemExit("Frozen code hash mismatch; refusing run.")
    if protocol["fixture_sha256"] != digest(ROOT / "shared/fixtures.json"):
        raise SystemExit("Frozen fixture hash mismatch; refusing run.")
    fixture = read(ROOT / "shared/fixtures.json")
    for name, expected in fixture["source_artifacts"].items():
        if digest(REPO / name) != expected:
            raise SystemExit(f"Historical source artifact changed: {name}")
    return protocol


def run(dotenv):
    protocol = verify()
    if not dotenv or not Path(dotenv).is_absolute():
        raise SystemExit("Live mode requires an explicit absolute --dotenv path.")
    runs = ROOT / "runs"
    runs.mkdir(exist_ok=False)
    write_new(
        runs / "started.json",
        {
            "protocol_sha256": digest(ROOT / "shared/protocol.json"),
            "maximum_model_requests": 384,
        },
    )
    summaries = []
    for trial in protocol["schedule"]:
        verify()
        directory = runs / trial["case"] / str(trial["repetition"]) / trial["arm"]
        directory.mkdir(parents=True, exist_ok=False)
        write_new(directory / "trial.json", trial)
        command = [
            sys.executable,
            str(ROOT / "harness/trial.py"),
            "--arm",
            trial["arm"],
            "--case",
            trial["case"],
            "--output",
            str(directory),
            "--dotenv",
            dotenv,
        ]
        try:
            process = subprocess.run(
                command,
                cwd=REPO,
                capture_output=True,
                text=True,
                timeout=300,
                check=False,
            )
        except subprocess.TimeoutExpired:
            write_new(
                directory / "runner_failure.json",
                {"reason": "outer_300_second_timeout"},
            )
            raise SystemExit(
                "Outer trial timeout; stopping batch, preserving all artifacts."
            ) from None
        if process.returncode:
            # Raw stderr can contain third-party exception values: retain safe failure only.
            write_new(
                directory / "runner_failure.json",
                {"reason": "child_failed", "exit_code": process.returncode},
            )
            raise SystemExit(
                f"Trial process failed: {trial}; stopping batch. See safe trial artifacts."
            )
        summary = read(directory / "summary.json")
        summaries.append({**trial, **summary})
        total = sum(item["network_model_requests"] for item in summaries)
        if total > protocol["maximum_model_requests"]:
            raise SystemExit("Invariant violation: global request cap exceeded.")
        print(
            json.dumps(
                {
                    **trial,
                    "status": summary["status"],
                    "stop_reason": summary["stop_reason"],
                    "model_requests_total": total,
                }
            ),
            flush=True,
        )
        if summary["systemic_provider_failure"]:
            write_new(
                runs / "stopped.json",
                {"reason": "systemic_provider_failure", "trials": summaries},
            )
            return
    verify()
    write_new(
        runs / "completed.json",
        {
            "trials": summaries,
            "network_model_requests": sum(
                s["network_model_requests"] for s in summaries
            ),
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare-fixtures", action="store_true")
    modes.add_argument("--freeze", action="store_true")
    modes.add_argument("--verify", action="store_true")
    modes.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv")
    args = parser.parse_args()
    if args.prepare_fixtures:
        fixtures()
    elif args.freeze:
        freeze()
    elif args.verify:
        verify()
        print("Frozen fixtures, code, and historical sources verified.")
    else:
        run(args.dotenv)


if __name__ == "__main__":
    main()
