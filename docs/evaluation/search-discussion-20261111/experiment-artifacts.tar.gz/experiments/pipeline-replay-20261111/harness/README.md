# Isolated actual-pipeline replay

The runner loads each frozen source arm in a separate process and submits the original claim/context through actual SQLite Storage and Pipeline.run. Only retrieval I/O is replaced: the actual Tavily adapter receives a fixed saved corpus through an in-memory transport. Every generated query returns the same saved pages, with blank snippets and stable synthetic rank. Unknown extraction URLs fail deterministically. Actual extraction limits, normalization, budgets, assessment admission, component aggregation, synthesis, and final semantic checks still run.

This evaluates the complete pipeline on a controlled corpus, excluding search quality. The two arms call the model independently, including interpretation and planning; their stochastic upstream differences can affect outcomes before either proposed change is reached. There is no expected answer or reviewer judgment in model inputs. Historical truncation remains explicit and missing page tails are unavailable.

The protocol freezes 24 investigations (4 claims, 2 arms, 3 repetitions), maximum 16 model requests per investigation and 384 total. Quick/deep budgets, deadlines, reserve, repair, and escalation are production defaults. Sampling is provider default. Only the fixed model/JSON schema/thinking/output/timeout/retry settings are pinned to the preceding experiment. Runtime credentials are loaded only through ProviderSettings using an explicit --dotenv path. Search never uses the network.

From the repository root, using aletheia-step7/.venv/bin/python:

- `harness/run_replay.py --prepare-fixtures` creates saved source fixtures once.
- `harness/check_offline.py` checks both arms without network or credentials.
- `harness/run_replay.py --freeze` freezes protocol, source, fixture, and harness hashes once.
- `harness/run_replay.py --verify` verifies frozen inputs and unchanged historical artifacts.
- `harness/run_replay.py --live --dotenv /absolute/runtime/settings/path` starts the one bounded paid batch.

Prefix those harness paths with `experiments/pipeline-replay-20261111/`. No automatic overwrite, resume, or retry of completed trials is allowed. The batch stops on systemic provider failures and preserves partial artifacts. Every model call writes pending input before transport; actual request JSON and raw public message content are captured without headers, credentials or hidden reasoning. `schema_validated` means JSON schema acceptance only; `task_finished` events and persisted evidence determine actual semantic acceptance.

Artifacts live in `runs/<case>/<repetition>/<arm>/`: fresh `investigations.sqlite3`, investigation/events/research-record dumps, per-task model input/request/raw-output records, retrieval requests, budget accounting, and summary. Actual final semantic rejection diagnostics remain in the production-generated sibling `investigations.sqlite3.diagnostics/` directory. The summary's first failure is an initial diagnostic; inspect task events to distinguish a repaired attempt from a terminal failure.
