"""Network-free integrity and full-pipeline storage/capture checks, separately for each arm."""

import argparse
import asyncio
import json
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

from run_replay import ARMS, REPO, ROOT, SETTINGS, read


async def checks(arm):
    sys.path.insert(0, str(ROOT / arm / "src"))
    import httpx
    from aletheia.budgets import CallBudget, RunBudget
    from aletheia.config import ProviderSettings
    from aletheia.evidence import snapshot
    from trial import build_adapters, execute

    sys.path.insert(0, str(REPO / "aletheia-phase-one/tests"))
    from research_fixtures import Providers

    ReplaySearch, _, _ = build_adapters()
    settings = ProviderSettings(**SETTINGS)
    fixture = read(ROOT / "shared/fixtures.json")
    total_sources = 0
    for case in fixture["cases"].values():
        replay = ReplaySearch(settings, case["sources"])
        budget = CallBudget(0, 3, 5, time.monotonic() + 30)
        first = await replay.search("first neutral question", budget=budget)
        second = await replay.search("totally different question", budget=budget)
        assert first.results == second.results
        assert all(hit.content == "" for hit in first.results)
        assert [hit.url for hit in first.results] == [s["url"] for s in case["sources"]]
        for source in case["sources"]:
            result = await replay.extract([source["url"]], budget=budget)
            page = result.pages[0]
            assert page.content == source["original_text"]
            assert ("page_text_truncated" in page.limitations) == (
                "page_text_truncated" in source["limitations"]
            )
            assert result.retrieved_at == datetime.fromisoformat(source["retrieved_at"])
            new = snapshot(
                url=page.url,
                title=source["title"],
                published_date=source["published_date"],
                retrieved_at=result.retrieved_at,
                text=page.content,
            )
            assert new.normalized_text == source["normalized_text"]
            assert new.content_hash == source["content_hash"]
            total_sources += 1
        absent = await replay.extract(
            ["https://not-saved.example/unknown"], budget=budget
        )
        assert (
            absent.pages[0].content is None
            and absent.pages[0].error == "extraction_failed"
        )
        assert budget.used == {
            "model": 0,
            "search": 2,
            "extract": len(case["sources"]) + 1,
        }
        await replay.aclose()
    budget = RunBudget()
    assert budget.model_attempts == 10 and budget.reserve_model_attempts == 4
    budget.escalate()
    assert (
        budget.model_attempts == 16
        and budget.search_attempts == 8
        and budget.extraction_attempts == 10
    )
    with tempfile.TemporaryDirectory(prefix="pipeline-replay-offline-") as temporary:
        base = Path(temporary)
        invalid = base / "invalid"
        invalid.mkdir()
        args = SimpleNamespace(case="b0002", output=str(invalid), dotenv=None)
        result = await execute(args, offline=True)
        assert result["status"] == "failed" and result["network_model_requests"] == 2, (
            result
        )
        assert not result["candidate_stage_exposure"]["snapshots_created"]
        complete = base / "complete"
        complete.mkdir()
        providers = Providers()
        case = {
            "claim": "The Archive opened in 2000.",
            "context": {},
            "sources": [
                {
                    "url": "https://source.test/0",
                    "title": "Synthetic Archive",
                    "published_date": None,
                    "retrieved_at": "2026-11-10T00:00:00+00:00",
                    "original_text": "The Archive opened in 2000.",
                    "limitations": [],
                }
            ],
        }
        args.output = str(complete)
        result = await execute(
            args,
            offline=True,
            offline_case=case,
            offline_transport=httpx.MockTransport(providers.handle),
        )
        assert result["status"] == "completed", result
        final = read(complete / "investigation.json")
        assert final["result"]["verdict"] == "true"
        assert final["result"]["budget_used"] == {"model": 5, "search": 2, "extract": 1}
        records = read(complete / "records.json")
        assert {"snapshot", "evidence", "claim_analysis"} <= {
            r["kind"] for r in records
        }
        calls = [read(path) for path in sorted(complete.glob("model_*.json"))]
        assert len(calls) == 5
        assert all(
            c["public_request"]["store"] is False
            and c["public_response"]["choices"][0]["content"]
            for c in calls
        )
        assert all("validated_result" in c for c in calls)
        assert calls[-1]["schema"]["title"] == "ExplanationCheck"
        try:
            await execute(args, offline=True)
        except RuntimeError as error:
            assert "Refusing reused" in str(error)
        else:
            raise AssertionError("A trial was overwritten")
        rejected = base / "rejected"
        rejected.mkdir()
        args.output = str(rejected)
        reject_provider = Providers(invalid_explanation=True)
        result = await execute(
            args,
            offline=True,
            offline_case=case,
            offline_transport=httpx.MockTransport(reject_provider.handle),
        )
        assert (
            result["status"] == "failed"
            and result["stop_reason"] == "semantic_rejection"
        ), result
        assert list((rejected / "investigations.sqlite3.diagnostics").glob("*.json"))
    print(
        json.dumps(
            {
                "arm": arm,
                "passed": True,
                "saved_source_hashes_verified": total_sources,
                "checks": [
                    "query-independent fixed corpus",
                    "original text and normalization hashes",
                    "truncation preserved",
                    "unknown URL deterministic failure",
                    "real search/extraction budgets",
                    "actual quick/deep budgets",
                    "full pipeline success + semantic check diagnostics",
                    "invalid JSON repair/failure",
                    "safe transport capture",
                    "fresh SQLite and overwrite refusal",
                ],
            }
        )
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=ARMS)
    args = parser.parse_args()
    if args.arm:
        asyncio.run(checks(args.arm))
    else:
        for arm in ARMS:
            subprocess.run([sys.executable, __file__, "--arm", arm], check=True)


if __name__ == "__main__":
    main()
