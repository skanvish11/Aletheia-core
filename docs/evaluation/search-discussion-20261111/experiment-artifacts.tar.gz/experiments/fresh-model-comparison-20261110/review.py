"""Reproducible offline scoring with separately recorded manual grounding review."""

import json
import statistics
from collections import Counter
from pathlib import Path

import run_comparison as run

ROOT = Path(__file__).resolve().parent


def main():
    rows = run.read("results.json")
    records = run.read("provider-records.json")
    manifest = run.read("manifest.json")
    annotations = run.read("semantic-review.json")
    assert annotations["reviewed_accepted_trials"] == len(rows)
    assert annotations["reviewed_provider_proposals"] == len(records)
    for name, digest in manifest["hashes"].items():
        assert run.base.sha((ROOT / name).read_bytes()) == digest
    for name, digest in manifest["imported_hashes"].items():
        assert run.base.sha(Path(name).read_bytes()) == digest
    cases, protocol, requests = run.prepare()
    assert protocol == run.read("protocol.json")
    assert requests == run.read("requests.json")
    assert len(rows) == len({r["trial"] for r in rows}) == 96
    assert len(records) == sum(r["network_calls"] for r in rows)
    assert all(r["http_status"] == 200 for r in records)
    for family, source in run.read("sources.json").items():
        assert (
            run.base.sha((ROOT / "sources" / (family + ".html")).read_bytes())
            == source["raw_sha256"]
        )
    old_fixtures = json.loads((run.base.ROOT / "protocol.json").read_text())["fixtures"]
    for f in old_fixtures:
        assert (
            run.base.sha(Path(f["database_path"]).read_bytes()) == f["database_sha256"]
        )
    case_map = {c["id"]: c for c in cases}
    details = []
    for row in rows:
        calls = [r for r in records if r["trial"] == row["trial"]]
        assert len(calls) == row["network_calls"]
        assert all(r["model"] == row["model"] for r in calls)
        expected = case_map[row["case_id"]]["expected"]
        finished = [e for e in row["events"] if e["type"] == "task_finished"]
        output = row.get("output") or {}
        first = calls[0].get("output") or {}
        accepted = row["status"] == "accepted"
        correct = accepted and output.get("relation") == expected
        added = row["trial"] in annotations["accepted_additions"]
        details.append(
            {
                "trial": row["trial"],
                "arm": row["arm"],
                "case_id": row["case_id"],
                "condition": row["condition"],
                "expected": expected,
                "observed": output.get("relation"),
                "final_correct": correct,
                "first_label_correct": first.get("relation") == expected,
                "first_valid_correct": finished[0]["payload"]["outcome"] == "success"
                and first.get("relation") == expected,
                "fully_grounded_correct": correct and not added,
                "accepted_unsupported_factual_addition": added,
                "unsupported_decisive_verdict": accepted
                and expected == "not_established"
                and output.get("relation") != "not_established",
                "notes": annotations["accepted_additions"].get(row["trial"], [])
                + annotations["other_notes"].get(row["trial"], []),
            }
        )
    summary = {}
    for arm, model in run.MODELS.items():
        ss = [s for s in details if s["arm"] == arm]
        rr = [r for r in rows if r["arm"] == arm]
        by_case = {
            c["id"]: sum(
                s["fully_grounded_correct"] for s in ss if s["case_id"] == c["id"]
            )
            for c in cases
        }
        summary[arm] = {
            "model": model,
            "trials": len(ss),
            "first_correct_labels": sum(s["first_label_correct"] for s in ss),
            "first_valid_correct": sum(s["first_valid_correct"] for s in ss),
            "final_correct_relations": sum(s["final_correct"] for s in ss),
            "fully_grounded_correct": sum(s["fully_grounded_correct"] for s in ss),
            "accepted_unsupported_additions": sum(
                s["accepted_unsupported_factual_addition"] for s in ss
            ),
            "unsupported_decisive_verdicts": sum(
                s["unsupported_decisive_verdict"] for s in ss
            ),
            "rejected_unsupported_additions": sum(
                1
                for x in annotations["rejected_additions"]
                if x["trial"].endswith("/" + arm)
            ),
            "invalid_final_outputs": sum(r["status"] != "accepted" for r in rr),
            "fully_grounded_by_condition": {
                condition: {
                    "correct": sum(
                        s["fully_grounded_correct"]
                        for s in ss
                        if s["condition"] == condition
                    ),
                    "total": sum(s["condition"] == condition for s in ss),
                }
                for condition in [
                    "supports",
                    "contradicts",
                    "not_established",
                    "withheld",
                ]
            },
            "fully_grounded_by_case": by_case,
            "cases_correct_all_three": sum(n == 3 for n in by_case.values()),
            "network_calls": sum(r["network_calls"] for r in rr),
            "repair_calls": sum(r["network_calls"] - 1 for r in rr),
            "total_tokens": sum(r["usage"]["total_tokens"] for r in rr),
            "mean_trial_seconds": statistics.mean(r["elapsed_seconds"] for r in rr),
            "median_trial_seconds": statistics.median(r["elapsed_seconds"] for r in rr),
        }
    pairs = {}
    for s in details:
        key = s["trial"].rsplit("/", 1)[0]
        pairs.setdefault(key, {})[s["arm"]] = s["fully_grounded_correct"]
    pair_counts = Counter(
        "both_correct"
        if p["current"] and p["comparison"]
        else "current_only"
        if p["current"]
        else "comparison_only"
        if p["comparison"]
        else "neither_correct"
        for p in pairs.values()
    )
    report = {
        "reviewer": "Assistant semantic review against predeclared labels and supplied evidence, not independent human adjudication.",
        "summary": summary,
        "paired_outcomes": dict(pair_counts),
        "semantic_review": annotations,
        "integrity": {
            "trials": len(rows),
            "http_200_calls": len(records),
            "frozen_hashes_match": True,
            "inputs_and_protocol_reconstructed": True,
            "source_snapshots_verified": 4,
            "exact_quote_variants_verified": len(cases),
            "historical_databases_unchanged": True,
            "offline_validator_checks_pass": True,
        },
        "limitations": protocol["limitations"],
        "trials": details,
    }
    run.base.dump(ROOT / "review.json", report)
    print(
        json.dumps(
            {
                "summary": summary,
                "paired_outcomes": dict(pair_counts),
                "integrity": report["integrity"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
