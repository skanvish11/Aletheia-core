"""Fetch public primary sources and freeze a small diagnostic claim set."""

import hashlib
import json
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent
SOURCES = {
    "mars": {
        "url": "https://science.nasa.gov/solar-system/planets/",
        "title": "About the Planets — NASA Science",
        "quote": "Mars is the fourth planet from the Sun, and the seventh largest planet.",
        "control": "Mars Facts",
        "claims": [
            (
                "supports",
                "Mars is the fourth planet from the Sun.",
                "Quotation explicitly establishes the orbital position.",
            ),
            (
                "contradicts",
                "Mars is the closest planet to the Sun.",
                "Fourth is incompatible with closest; no replacement planet may be invented.",
            ),
            (
                "not_established",
                "Mars is the fourth planet from the Sun and has two moons.",
                "Orbital position is established, but the supplied quotation does not establish the moon count.",
            ),
        ],
    },
    "aes": {
        "url": "https://csrc.nist.gov/pubs/fips/197/final",
        "title": "FIPS 197 — Advanced Encryption Standard (AES)",
        "quote": "Three members of the Rijndael family are specified in this Standard: AES-128, AES-192, and AES-256. Each of them transforms data in blocks of 128 bits, and the numerical suffix indicates the bit length of the associated cryptographic keys.",
        "control": "National Institute of Standards and Technology",
        "claims": [
            (
                "supports",
                "AES-256 uses 128-bit data blocks and a 256-bit cryptographic key.",
                "Both block size and the meaning of the numerical suffix are explicit.",
            ),
            (
                "contradicts",
                "AES-256 transforms data in 256-bit blocks.",
                "The quoted 128-bit block size contradicts 256-bit blocks; key length must not be confused with block length.",
            ),
            (
                "not_established",
                "AES-256 uses 128-bit data blocks and encrypts data faster than AES-128.",
                "Block size is given but no speed comparison is supplied.",
            ),
        ],
    },
    "web": {
        "url": "https://home.cern/science/computing/the-birth-of-the-web",
        "title": "The birth of the Web — CERN",
        "quote": "On 30 April 1993, CERN put the World Wide Web software in the public domain.",
        "control": "The birth of the Web",
        "claims": [
            (
                "supports",
                "CERN put the World Wide Web software in the public domain on 30 April 1993.",
                "Same event and exact date.",
            ),
            (
                "contradicts",
                "CERN put the World Wide Web software in the public domain on 30 April 1989.",
                "Same event but incompatible year.",
            ),
            (
                "not_established",
                "The World Wide Web was invented in 1989.",
                "The quotation dates entry into the public domain, not invention. Other text on the page is deliberately not supplied.",
            ),
        ],
    },
    "http": {
        "url": "https://www.rfc-editor.org/rfc/rfc9110.html",
        "title": "RFC 9110: HTTP Semantics",
        "quote": "The 403 (Forbidden) status code indicates that the server understood the request but refuses to fulfill it.",
        "control": "HTTP Semantics",
        "claims": [
            (
                "supports",
                "HTTP 403 indicates that the server understood a request but refuses to fulfill it.",
                "The stated interpretation matches the quotation.",
            ),
            (
                "contradicts",
                "HTTP 403 indicates that the server did not understand the request.",
                "Understood contradicts did not understand.",
            ),
            (
                "not_established",
                "Every HTTP 403 response means the user supplied an incorrect password.",
                "The quotation does not identify passwords or establish this universal causal claim.",
            ),
        ],
    },
}


class Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.skip += 1

    def handle_endtag(self, tag):
        if tag in {"script", "style"}:
            self.skip = max(0, self.skip - 1)

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def main():
    if (ROOT / "cases.json").exists():
        raise SystemExit("Frozen cases already exist; no overwrite.")
    (ROOT / "sources").mkdir(exist_ok=True)
    cases, snapshots = [], {}
    with httpx.Client(timeout=45, follow_redirects=True) as client:
        for family, source in SOURCES.items():
            response = client.get(source["url"])
            response.raise_for_status()
            parser = Text()
            parser.feed(response.text)
            normalized = " ".join(" ".join(parser.parts).split())
            (ROOT / "sources" / (family + ".html")).write_bytes(response.content)
            (ROOT / "sources" / (family + ".txt")).write_text(normalized)
            snapshots[family] = {
                "url": source["url"],
                "resolved_url": str(response.url),
                "retrieved_at": datetime.now(UTC).isoformat(),
                "raw_sha256": sha(response.content),
                "normalized_sha256": sha(normalized.encode()),
                "normalization": "HTML text nodes excluding script/style; whitespace collapsed. Exactness is relative to this saved text, not raw HTML.",
            }
            for kind, claim, rationale in source["claims"] + [
                (
                    "withheld",
                    source["claims"][0][1],
                    "Only a source heading/credit is supplied; metadata does not establish the claimed fact.",
                )
            ]:
                quote = source["control"] if kind == "withheld" else source["quote"]
                assert quote in normalized, (family, kind)
                start = normalized.index(quote)
                cases.append(
                    {
                        "id": family + "_" + kind,
                        "family": family,
                        "condition": kind,
                        "claim": claim,
                        "expected": "not_established" if kind == "withheld" else kind,
                        "rationale": rationale,
                        "source": {"url": source["url"], "title": source["title"]},
                        "evidence": [{"id": "E1", "quote": quote}],
                        "provenance": {
                            "start": start,
                            "end": start + len(quote),
                            "quote_sha256": sha(quote.encode()),
                        },
                    }
                )
            print(
                json.dumps(
                    {
                        "source": family,
                        "http_status": response.status_code,
                        "quotes_verified": True,
                    }
                ),
                flush=True,
            )
    dump("sources.json", snapshots)
    dump("cases.json", cases)


if __name__ == "__main__":
    main()
