"""Bounded fresh-claim comparison of two hosted models; never mutates the pipeline."""

import argparse
import asyncio
import importlib.util
import json
import sys
import time
from contextlib import AsyncExitStack
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "fixed-evidence-decision-20261110"
spec = importlib.util.spec_from_file_location(
    "fixed_decision", PREVIOUS / "experiment.py"
)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
base, runtime = prior.base, prior.prior
MODELS = {
    "current": "nvidia/Nemotron-3_5-Lightning",
    "comparison": "Qwen/Qwen3-235B-A22B-Instruct-2507",
}
base.CAP = 192


def read(name):
    return json.loads((ROOT / name).read_text())


def prepare():
    cases, sources = read("cases.json"), read("sources.json")
    assert len(cases) == len({c["id"] for c in cases}) == 16
    assert len({c["claim"] for c in cases}) == 12
    available = {m["id"] for m in read("available-models.json")}
    assert set(MODELS.values()) <= available
    old_claims = {
        v["claim"]
        for v in json.loads((PREVIOUS / "requests.json").read_text())["inputs"].values()
    }
    assert not old_claims & {c["claim"] for c in cases}
    for c in cases:
        text = (ROOT / "sources" / (c["family"] + ".txt")).read_text()
        assert base.sha(text.encode()) == sources[c["family"]]["normalized_sha256"]
        quote = c["evidence"][0]["quote"]
        assert text[c["provenance"]["start"] : c["provenance"]["end"]] == quote
        assert base.sha(quote.encode()) == c["provenance"]["quote_sha256"]
    runtime.offline_checks(base.load_cases())
    protocol = {
        "purpose": "Compare the unchanged explicit comparison prompt across two models on newly authored claims with fixed exact evidence.",
        "models": MODELS,
        "fresh_unique_claims": 12,
        "withheld_control_variants": 4,
        "repetitions_per_model_per_case": 3,
        "planned_trials": 96,
        "network_attempt_cap": 192,
        "comparison_selection": "Different model family available on the same provider; Qwen's published model card identifies this Instruct release as non-thinking.",
        "model_card": "https://huggingface.co/Qwen/Qwen3-235B-A22B-Instruct-2507",
        "settings": "Same provider, frozen adapter, prompt, schema, 4096 output-token ceiling, 45-second request timeout, no transport retries, one structural repair, default sampling and no seed. Nemotron thinking explicitly disabled; Qwen non-thinking Instruct uses default because adapter does not support its thinking override.",
        "schedule": "Alternate model order by case and repetition; sequential requests, no history shared across trials.",
        "control_policy": "Both models must assess heading/credit quotations; no deterministic abstention shortcut.",
        "metrics": [
            "First-attempt and final correct accepted relations",
            "Grounded correct decisions (including appropriate abstentions)",
            "Unsupported additions in accepted and rejected proposals, separately",
            "All-three-repetition consistency by case",
            "Network calls, tokens and observed latency",
        ],
        "semantic_review": "Assistant reviews against frozen labels/rationales and supplied quotations. Correct label alone is insufficient when explanation adds unsupported facts. No semantic expected-answer hints enter validation or repairs.",
        "limitations": [
            "Small diagnostic with four source families; related variants and repetitions are not independent claims.",
            "Fresh to these experiments, not guaranteed unseen in either model's training; labels authored by the assistant, not independently adjudicated.",
            "Manual quotation selection bypasses search/extraction; no production-pipeline or source-authority evaluation.",
            "Provider-default sampling can differ by model; comparison measures these hosted configurations, not model weights alone.",
            "No prompt tuning, model substitution or discarded unsuccessful trials after outputs are observed.",
        ],
        "prompt_sha256": base.sha(prior.COMPARISON_PROMPT.encode()),
        "expected": {c["id"]: c["expected"] for c in cases},
        "tavily_calls": 0,
    }
    requests = {
        "prompt": prior.COMPARISON_PROMPT,
        "schema": runtime.Explanation.model_json_schema(),
        "repair_guidance": runtime.REPAIRS["explanation_reference"],
        "inputs": {
            c["id"]: {k: c[k] for k in ["claim", "source", "evidence"]} for c in cases
        },
    }
    assert (
        requests["prompt"]
        == json.loads((PREVIOUS / "requests.json").read_text())["prompts"][
            "explicit_comparison"
        ]
    )
    return cases, protocol, requests


async def execute(args):
    if (ROOT / "results.json").exists():
        raise SystemExit("Results exist; no overwrite or automatic rerun.")
    cases, protocol, requests = prepare()
    for name, data in [("protocol.json", protocol), ("requests.json", requests)]:
        base.dump(ROOT / name, data)
    if not args.live:
        print(
            json.dumps(
                {
                    "prepared": True,
                    "offline_checks_passed": True,
                    "trials": 96,
                    "call_cap": 192,
                    "unchanged_prompt": True,
                }
            )
        )
        return
    loaded = runtime.ProviderSettings.from_environment(dotenv_path=args.dotenv)
    if not loaded.nebius_api_key:
        raise SystemExit("Credential unavailable; no call made.")
    old_settings = json.loads((PREVIOUS / "manifest.json").read_text())["settings"]
    settings = {}
    for arm, model in MODELS.items():
        settings[arm] = runtime.ProviderSettings.model_validate(
            {
                **loaded.model_dump(),
                **old_settings,
                "nebius_model": model,
                "nebius_thinking": "disabled" if arm == "current" else "default",
            }
        )
        settings[arm].validate_model_controls()
    files = [
        "run_comparison.py",
        "prepare_sources.py",
        "cases.json",
        "sources.json",
        "protocol.json",
        "requests.json",
        "available-models.json",
    ]
    imports = [
        PREVIOUS / "experiment.py",
        runtime.ROOT / "evidence_first.py",
        base.ROOT / "experiment.py",
    ]
    manifest = {
        "started_at": datetime.now(UTC).isoformat(),
        "settings": {
            k: v.model_dump(exclude={"nebius_api_key", "tavily_api_key"})
            for k, v in settings.items()
        },
        "temperature": "provider defaults",
        "seed": "not set",
        "python": sys.version,
        "hashes": {name: base.sha((ROOT / name).read_bytes()) for name in files},
        "imported_hashes": {str(p): base.sha(p.read_bytes()) for p in imports},
    }
    base.dump(ROOT / "manifest.json", manifest)
    transports = {arm: base.AuditTransport() for arm in MODELS}
    rows, records = [], []
    schedule = []
    for rep in range(3):
        for i, c in enumerate(cases):
            arms = list(MODELS)
            if (i + rep) % 2:
                arms.reverse()
            schedule.extend((c, rep + 1, arm) for arm in arms)
    async with AsyncExitStack() as stack:
        models = {
            arm: await stack.enter_async_context(
                runtime.NebiusProvider(settings[arm], transport=transports[arm])
            )
            for arm in MODELS
        }
        for c, rep, arm in schedule:
            assert len(records) < 192
            trial = f"{c['id']}/{rep}/{arm}"
            row = {
                "trial": trial,
                "case_id": c["id"],
                "family": c["family"],
                "condition": c["condition"],
                "repetition": rep,
                "arm": arm,
                "model": MODELS[arm],
                "events": [],
            }
            started, before = time.monotonic(), len(transports[arm].records)

            async def emit(event, payload, row=row):
                row["events"].append({"type": event, "payload": payload})

            tasks = runtime.Tasks(
                models[arm], runtime.CallBudget(2, 0, 0, time.monotonic() + 95), emit
            )
            transports[arm].context = trial
            try:
                result = await tasks.call(
                    "explain_evidence",
                    prior.COMPARISON_PROMPT,
                    requests["inputs"][c["id"]],
                    runtime.Explanation,
                    lambda result, c=c: runtime.validate_explanation(
                        result, c["evidence"]
                    ),
                )
                row.update(status="accepted", output=result.model_dump())
            except runtime.InvalidTask:
                row["status"] = "invalid_task_output"
            except runtime.ProviderError as exc:
                row.update(status=exc.code.value, validation_code=exc.validation_code)
            new = transports[arm].records[before:]
            records.extend(dict(record, model=MODELS[arm]) for record in new)
            row.update(
                usage=tasks.tokens,
                elapsed_seconds=time.monotonic() - started,
                network_calls=len(new),
            )
            row["validation_failures"] = [
                e["payload"]["validation_code"]
                for e in row["events"]
                if e["type"] == "task_finished" and e["payload"]["outcome"] != "success"
            ]
            rows.append(row)
            base.dump(ROOT / "results.json", rows)
            base.dump(ROOT / "provider-records.json", records)
            print(
                json.dumps(
                    {
                        k: row[k]
                        for k in [
                            "trial",
                            "status",
                            "network_calls",
                            "validation_failures",
                        ]
                    }
                ),
                flush=True,
            )
            if row["status"] not in {"accepted", "invalid_task_output"}:
                manifest["stopped_early"] = row["status"]
                break
    manifest.update(
        finished_at=datetime.now(UTC).isoformat(),
        trials_recorded=len(rows),
        network_attempts=len(records),
    )
    base.dump(ROOT / "manifest.json", manifest)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv", type=Path)
    asyncio.run(execute(parser.parse_args()))
