"""Select relevant immutable spans across a document while retaining nearby context."""

import math
import re
from collections import Counter

STOP = {
    "the",
    "a",
    "an",
    "is",
    "was",
    "were",
    "in",
    "on",
    "of",
    "to",
    "and",
    "or",
    "for",
    "at",
    "by",
    "with",
    "from",
    "that",
    "this",
    "as",
    "it",
    "its",
}


def terms(text):
    return set(re.findall(r"[\w]+", text.casefold())) - STOP


def boilerplate(text):
    stripped = text.strip()
    return bool(
        re.fullmatch(r"(?:[-*]\s*)?\[[^\]]+\]\([^\n]+\)", stripped)
        or normalized_navigation(stripped)
    )


def normalized_navigation(text):
    # Markdown formatting alone does not make a heading navigation.
    label = re.sub(r"^#{1,6}\s+", "", text).rstrip("#").strip()
    return label.casefold() in {
        "skip to content",
        "navigation",
        "contents",
        "menu",
        "log in",
        "sign in",
        "privacy policy",
        "cookie policy",
        "accept cookies",
        "jump to content",
    }


def _original_order(assertion, candidates):
    query = terms(assertion.text)
    frequencies = Counter(t for span in candidates for t in terms(span.text))
    return sorted(
        candidates,
        key=lambda s: (-sum(1 / frequencies[t] for t in terms(s.text) & query), s.id),
    )


def _ranked_order(assertion, candidates, selected):
    """Relevance followed by novelty; a repeated template cannot take every slot.

    This changes priority, never discards a fact because it resembles another one.
    Numeric and polarity differences receive a floor on the novelty penalty.
    """
    query = terms(assertion.text)
    token_sets = {span.id: terms(span.text) for span in candidates}
    frequencies = Counter(token for tokens in token_sets.values() for token in tokens)
    weights = {
        token: math.log1p(len(candidates) / (1 + count))
        for token, count in frequencies.items()
    }
    average = sum(len(tokens) for tokens in token_sets.values()) / len(candidates)
    scores = {
        span.id: sum(weights[token] for token in token_sets[span.id] & query)
        / (0.4 + 0.6 * len(token_sets[span.id]) / max(average, 1))
        for span in candidates
    }
    words = {
        span.id: frozenset(
            token for token in token_sets[span.id] if not token.isdecimal()
        )
        for span in candidates
    }
    numbers = {
        span.id: frozenset(re.findall(r"\b\d+(?:[.,]\d+)*\b", span.text))
        for span in candidates
    }
    negatives = {"not", "no", "never", "without", "except", "excluding", "only"}
    polarity = {span.id: token_sets[span.id] & negatives for span in candidates}
    remaining = {span.id: span for span in candidates}
    novelty = dict.fromkeys(remaining, 1.0)
    represented = set()
    while remaining:
        anchor_id = max(
            remaining, key=lambda key: (scores[key] * novelty[key], scores[key], -key)
        )
        anchor = remaining.pop(anchor_id)
        yield anchor
        for admitted_id in selected.keys() - represented:
            for key in remaining:
                union = words[key] | words[admitted_id]
                similarity = (
                    len(words[key] & words[admitted_id]) / len(union) if union else 1.0
                )
                factor = max(0.03, 1.0 - similarity)
                if numbers[key] != numbers[admitted_id]:
                    factor = max(factor, 0.18)
                if polarity[key] != polarity[admitted_id]:
                    factor = max(factor, 0.5)
                novelty[key] = min(novelty[key], factor)
        represented.update(selected)


def _table_cells(text):
    line = text.strip()
    if "\n" in line or "|" not in line:
        return None
    cells = [cell.strip() for cell in line.strip("|").split("|")]
    return cells if len(cells) >= 2 else None


def _structure(source):
    """Recognize explicit Markdown structure without inventing missing context."""
    spans = source.spans
    by_id = {span.id: span for span in spans}
    headings, stack, tables, table_ends, definitions = {}, [], {}, {}, {}
    for span in spans:
        match = re.match(r"\s*(#{1,6})\s+\S", span.text)
        if match:
            level = len(match[1])
            stack = [(n, key) for n, key in stack if n < level]
            stack.append((level, span.id))
        headings[span.id] = [key for _, key in stack]
        match = re.match(r"\s*\[(\^?[^\]\s]+)\]\s*:?\s+", span.text)
        if match:
            definitions.setdefault(match[1], []).append(span.id)
        match = re.match(r"\s*([*†‡]+)\s+\S", span.text)
        if match:
            definitions.setdefault(match[1], []).append(span.id)

    # A delimiter row is required: arbitrary prose containing a pipe is not a table.
    for index, span in enumerate(spans):
        cells = _table_cells(span.text)
        if not cells or not all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells):
            continue
        if index == 0:
            continue
        header = spans[index - 1]
        if not _table_cells(header.text):
            continue
        tables[header.id] = header.id
        table_ends[header.id] = span.id
        previous = span
        for row in spans[index + 1 :]:
            gap = source.normalized_text[previous.end : row.start]
            if not _table_cells(row.text) or gap.count("\n") > 1:
                break
            tables[row.id] = header.id
            table_ends[header.id] = row.id
            previous = row

    sections = {}
    for span in spans:
        if headings[span.id]:
            sections.setdefault(tuple(headings[span.id]), []).append(span.id)
    short_sections = {
        path: keys
        for path, keys in sections.items()
        if len(keys) <= 20 and sum(len(by_id[key].text) for key in keys) <= 1500
    }

    structural = {}
    for span in spans:
        required = list(headings[span.id])
        # A short explicitly headed section is a coherent evidence unit; retaining
        # it protects definitions and qualifications beyond immediate neighbors.
        required.extend(short_sections.get(tuple(headings[span.id]), []))
        if span.id in tables:
            required.append(tables[span.id])
            if span.id == tables[span.id]:
                previous = by_id.get(span.id - 1)
                if previous and headings[previous.id] == headings[span.id]:
                    required.append(previous.id)
        markers = re.findall(r"\[(\^?[^\]\s]+)\](?!\()", span.text)
        if span.id in tables:
            markers += re.findall(r"[*†‡]+", span.text)
        for marker in markers:
            if marker in definitions:
                # Prefer a local definition; avoid using a footnote from another section.
                matching = [
                    key
                    for key in definitions[marker]
                    if headings[key] == headings[span.id]
                ]
                if marker[0] in "*†‡" and span.id in tables:
                    table_header = tables[span.id]
                    next_table = min(
                        (key for key in table_ends if key > table_ends[table_header]),
                        default=float("inf"),
                    )
                    matching = [
                        key
                        for key in matching
                        if table_ends[table_header] < key < next_table
                    ]
                if matching:
                    required.append(min(matching, key=lambda key: abs(key - span.id)))
        structural[span.id] = list(dict.fromkeys(required))

    def expand(keys):
        result = set()
        pending = list(keys)
        while pending:
            key = pending.pop()
            if key in result:
                continue
            result.add(key)
            pending.extend(structural.get(key, []))
        return result

    dependencies = {}
    for span in spans:
        required = [span.id]
        if span.id not in tables:
            # Neighboring prose preserves nearby subjects, negation and qualifications.
            for key in (span.id - 1, span.id + 1):
                neighbor = by_id.get(key)
                if (
                    neighbor is not None
                    and key not in tables
                    and not boilerplate(neighbor.text)
                    and headings[key] == headings[span.id]
                ):
                    required.append(key)
        # Structural references are transitive (row -> header -> units footnote),
        # while prose neighbors expand only once rather than swallowing a section.
        dependencies[span.id] = sorted(expand(required))
    return dependencies


def select_passages(
    assertion, source, *, max_chars=12000, max_spans=120, profile="combined"
):
    """Return original spans within the same budget; no summaries or inferred facts.

    Profiles separate ranking/packing from structural context for offline ablation.
    A structural bundle is all-or-nothing: a row does not silently lose its header.
    """
    if profile not in {"rank_only", "context_only", "combined"}:
        raise ValueError("Unknown passage selection profile")
    candidates = [s for s in source.spans if not boilerplate(s.text)]
    if not candidates or max_chars <= 0 or max_spans <= 0:
        return []
    selected, size = {}, 0
    ranked = (
        _original_order(assertion, candidates)
        if profile == "context_only"
        else _ranked_order(assertion, candidates, selected)
    )
    by_id = {s.id: s for s in candidates}
    dependencies = _structure(source) if profile != "rank_only" else {}
    for anchor in ranked:
        if len(selected) >= max_spans or size >= max_chars:
            break
        if anchor.id in selected or len(anchor.text) > max_chars:
            continue
        if profile != "rank_only":
            ids = dependencies[anchor.id]
            bundle = [by_id[key] for key in ids if key in by_id and key not in selected]
            if (
                size + sum(len(s.text) for s in bundle) > max_chars
                or len(selected) + len(bundle) > max_spans
            ):
                continue
            for span in bundle:
                selected[span.id] = span
                size += len(span.text)
            continue
        # Ranking-only arm retains the existing optional-neighbor policy.
        for span_id in (anchor.id, anchor.id - 1, anchor.id + 1):
            span = by_id.get(span_id)
            if span is None or span_id in selected:
                continue
            if size + len(span.text) <= max_chars and len(selected) < max_spans:
                selected[span_id] = span
                size += len(span.text)
    return [selected[i] for i in sorted(selected)]
