"""Sensitivity checks for the coverage evaluator, independent of selection design."""

from types import SimpleNamespace

import pytest
from evaluate import anchor_check, intervals


def span(start, end):
    return SimpleNamespace(start=start, end=end)


def test_chunk_seam_and_whitespace_are_covered():
    text = "Aster opened in 1987."
    selected = [span(0, 12), span(9, len(text))]
    assert anchor_check(text, text, intervals(selected, text))["covered"]
    assert anchor_check(text, text, intervals([span(0, 5), span(6, len(text))], text))[
        "covered"
    ]


def test_deleted_fact_or_nonadjacent_stitching_fails():
    text = "Aster closed temporarily. Aster opened in 1987."
    assert not anchor_check(
        "Aster opened in 1987.",
        text,
        intervals([span(0, 5), span(32, len(text))], text),
    )["covered"]
    assert not anchor_check("1987", text, intervals([span(0, 10)], text))["covered"]


def test_incorrect_expected_anchor_fails_instead_of_lower_score():
    with pytest.raises(AssertionError):
        anchor_check("1987", "No date supplied.", [[0, 17]])
