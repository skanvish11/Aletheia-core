"""Exercise the real selection/assessment boundary and API persistence without a model."""

import asyncio
import hashlib
import json
import sys
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "candidate/src"))

import httpx
from aletheia.api import create_app
from aletheia.config import Settings
from aletheia.evidence import admit, snapshot
from aletheia.passages import select_passages
from aletheia.research_contracts import Assertion, Citation, Snapshot
from aletheia.tasks import TaskValidationError
from aletheia.verification import assess


class ScriptedBoundary:
    """A context-only response tests transport; it never simulates a correct verdict."""

    def __init__(self, selected):
        self.selected = selected
        self.captured = None

    async def call(self, name, instructions, data, schema, validate):
        assert name == "assess"
        assert data["spans"] == [s.model_dump() for s in self.selected]
        self.captured = data
        ids = [s.id for s in self.selected[:6]]
        result = schema.model_validate(
            {
                "assessments": [
                    {
                        "component_id": "c1",
                        "values": [],
                        "citation": {
                            "snapshot_id": data["snapshot_id"],
                            "span_ids": ids,
                        },
                        "relation": "context",
                        "scope_match": False,
                        "authoritative_record": False,
                        "credible_synthesis": False,
                        "synthesis_coverage": None,
                        "publisher": None,
                        "origin": None,
                        "independence": "unknown",
                        "provenance_span_ids": [],
                        "provenance_note": None,
                        "rationale": "Scripted context-only transport check; no truth or authority assessment.",
                        "limitations": [],
                        "flags": [],
                    }
                ],
                "gap": "No model assessment performed.",
            }
        )
        validate(result)
        return result


async def run():
    fixtures = json.loads((ROOT / "shared/regressions.json").read_text())["cases"]
    rows = []
    with tempfile.TemporaryDirectory(prefix="selection-integration-") as directory:
        settings = Settings(
            database_path=Path(directory) / "test.sqlite3", research_enabled=False
        )
        app = create_app(settings)
        reads = []
        async with (
            app.router.lifespan_context(app),
            httpx.AsyncClient(
                transport=httpx.ASGITransport(app), base_url="http://test"
            ) as client,
        ):
            for case in fixtures:
                response = await client.post(
                    "/investigations", json={"claim": case["claim"]}
                )
                assert response.status_code == 202
                investigation_id = UUID(response.json()["id"])
                running = await app.state.storage.claim_next()
                assert running.id == investigation_id
                source = snapshot(
                    url=case["url"],
                    title=case["id"],
                    published_date=None,
                    retrieved_at=datetime(2026, 11, 11, tzinfo=UTC),
                    text=case["text"],
                )
                before = hashlib.sha256(source.model_dump_json().encode()).hexdigest()
                await app.state.storage.save_records(
                    investigation_id, "snapshot", [source]
                )
                claim = Assertion(
                    text=case["claim"],
                    kind="direct_record",
                    consequential=False,
                    recommended_route="quick",
                )
                selected = select_passages(claim, source)
                assert selected
                tasks = ScriptedBoundary(selected)
                evidence, gap = await assess(tasks, claim, source)
                assert tasks.captured is not None and gap
                await app.state.storage.save_records(
                    investigation_id, "evidence", evidence
                )
                assert (
                    hashlib.sha256(source.model_dump_json().encode()).hexdigest()
                    == before
                )
                stored = await app.state.storage.records(
                    investigation_id, "snapshot", Snapshot
                )
                assert stored[0] == source
                assert select_passages(claim, stored[0]) == selected
                path = f"/investigations/{investigation_id}/evidence"
                readback = await client.get(path)
                assert readback.status_code == 200
                public = readback.json()
                assert public["evidence"] == [
                    e.model_dump(mode="json") for e in evidence
                ]
                assert (
                    public["sources"][0]["splitter_version"] == source.splitter_version
                )
                assert "original_text" not in public["sources"][0]
                reads.append((path, public))
                checked = evidence[0].assessment
                for bad_citation in (
                    Citation(
                        snapshot_id=str(uuid4()), span_ids=checked.citation.span_ids
                    ),
                    Citation(snapshot_id=source.id, span_ids=[len(source.spans) + 1]),
                    Citation(
                        snapshot_id=source.id,
                        span_ids=[selected[0].id, selected[0].id],
                    ),
                ):
                    try:
                        admit(
                            checked.model_copy(update={"citation": bad_citation}),
                            source,
                            {s.id for s in selected},
                        )
                    except TaskValidationError:
                        pass
                    else:
                        raise AssertionError("Bad citation admitted")
                rows.append(
                    {
                        "id": case["id"],
                        "selected_spans": len(selected),
                        "selected_chars": sum(len(s.text) for s in selected),
                        "snapshot_immutable": True,
                        "actual_assessment_input_matches": True,
                        "api_readback": True,
                        "stale_unknown_duplicate_citations_rejected": True,
                    }
                )
        reopened = create_app(settings)
        async with (
            reopened.router.lifespan_context(reopened),
            httpx.AsyncClient(
                transport=httpx.ASGITransport(reopened), base_url="http://test"
            ) as client,
        ):
            for path, public in reads:
                assert (await client.get(path)).json() == public
    print(
        json.dumps(
            {
                "passed": True,
                "provider_calls": 0,
                "claim": "Transport/persistence checks only; no semantic or source-authority accuracy claim.",
                "cases": rows,
                "restart_readback": True,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    asyncio.run(run())
