"""Freeze experiment sources and corpus inputs; refuse changed evaluation artifacts."""

import argparse
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def hashes():
    files = list((ROOT / "baseline/src").rglob("*.py"))
    files += list((ROOT / "candidate/src").rglob("*.py"))
    files += list((ROOT / "analysis").glob("*.py"))
    files += [
        ROOT / item
        for item in (
            "shared/protocol.json",
            "shared/regressions.json",
            "evaluation/development.json",
            "evaluation/sealed-holdout.json",
            "review/real-corpus-fixtures.json",
            "review/predeclared-rubric.json",
        )
    ]
    return {str(path.relative_to(ROOT)): digest(path) for path in sorted(files)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    target = ROOT / "shared/evaluation-freeze.json"
    if args.freeze:
        with target.open("x") as out:
            json.dump(
                {
                    "frozen_at": datetime.now(UTC).isoformat(),
                    "hashes": hashes(),
                    "primary_arm": "combined",
                    "holdout_inspected_by_implementer": False,
                    "scope": "Offline passage selection only; no model calls or production change.",
                },
                out,
                indent=2,
            )
            out.write("\n")
        print("Frozen sources and all evaluation corpora before held-out scoring.")
    else:
        saved = json.loads(target.read_text())
        assert saved["hashes"] == hashes(), (
            "Experiment source or corpus changed after freeze"
        )
        original = json.loads((ROOT / "shared/initial-freeze.json").read_text())
        workspace = ROOT.parents[1]
        assert all(
            digest(workspace / path) == expected
            for path, expected in original["production_hashes"].items()
        )
        print("Frozen experiment and all32 production source hashes unchanged.")


if __name__ == "__main__":
    main()
