"""Offline, separate-process passage-selection evaluation; no provider calls."""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARMS = ("current", "splitter_only", "rank_only", "context_only", "combined")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write("\n")


def intervals(spans, text):
    merged = []
    for span in spans:
        if merged and (
            span.start <= merged[-1][1] or not text[merged[-1][1] : span.start].strip()
        ):
            merged[-1][1] = max(merged[-1][1], span.end)
        else:
            merged.append([span.start, span.end])
    return merged


def anchor_check(anchor, text, covered):
    import re

    anchor = re.sub(r"[^\S\n]+", " ", anchor.replace("\r\n", "\n").replace("\r", "\n"))
    occurrences = []
    start = text.find(anchor)
    while start >= 0:
        end = start + len(anchor)
        occurrences.append(
            {
                "start": start,
                "end": end,
                "covered": any(a <= start and b >= end for a, b in covered),
            }
        )
        start = text.find(anchor, start + 1)
    if not occurrences:
        raise AssertionError(f"Expected anchor absent from fixture: {anchor[:80]}")
    return {
        "anchor": anchor,
        "covered": any(o["covered"] for o in occurrences),
        "occurrences": occurrences,
    }


def worker(arm, fixture, output):
    source_arm = "baseline" if arm == "current" else "candidate"
    sys.path.insert(0, str(ROOT / source_arm / "src"))
    from aletheia.evidence import digest, excerpts, snapshot
    from aletheia.research_contracts import Assertion

    original_spec = importlib.util.spec_from_file_location(
        "original_evidence", ROOT / "baseline/src/aletheia/evidence.py"
    )
    original_module = importlib.util.module_from_spec(original_spec)
    original_spec.loader.exec_module(original_module)

    if arm == "splitter_only":
        spec = importlib.util.spec_from_file_location(
            "unchanged_selector", ROOT / "baseline/src/aletheia/passages.py"
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        select = mod.select_passages
    else:
        from aletheia.passages import select_passages

        select = select_passages
    cases = json.loads(fixture.read_text())["cases"]
    results = []
    for case in cases:
        source = snapshot(
            url=case.get("url")
            or case.get("source_url")
            or "https://example.org/" + case["id"],
            title=case["id"],
            published_date=None,
            retrieved_at=datetime(2026, 11, 11, tzinfo=UTC),
            text=case["text"],
        )
        original = original_module.snapshot(
            url=source.url,
            title=source.title,
            published_date=None,
            retrieved_at=source.retrieved_at,
            text=case["text"],
        )
        assert source.normalized_text == original.normalized_text
        assert source.content_hash == original.content_hash
        claim = Assertion(
            text=case["claim"],
            kind="direct_record",
            consequential=False,
            recommended_route="quick",
        )
        options = {} if arm in ("current", "splitter_only") else {"profile": arm}
        selected = select(claim, source, max_chars=12000, max_spans=120, **options)
        ids = [s.id for s in selected]
        assert ids == sorted(set(ids))
        assert sum(len(s.text) for s in selected) <= 12000 and len(selected) <= 120
        by_id = {s.id: s for s in source.spans}
        for span in selected:
            assert span == by_id[span.id]
            assert span.text == source.normalized_text[span.start : span.end]
        if arm != "current":
            assert all(len(s.text) <= 1500 for s in source.spans)
        quotes = excerpts(source, ids, set(ids)) if ids else []
        for quote in quotes:
            assert quote.text == source.normalized_text[quote.start : quote.end]
            assert quote.quote_hash == digest(quote.text)
        covered = intervals(selected, source.normalized_text)
        routes = [case["required_groups"], *case.get("alternative_required_groups", [])]
        assert all(len(route) == len(routes[0]) for route in routes)
        route_details = [
            [
                [
                    anchor_check(anchor, source.normalized_text, covered)
                    for anchor in group
                ]
                for group in route
            ]
            for route in routes
        ]
        route_coverage = [
            [all(x["covered"] for x in group) for group in route]
            for route in route_details
        ]
        group_coverage = [
            any(route[i] for route in route_coverage) for i in range(len(routes[0]))
        ]
        full = (
            any(all(route) for route in route_coverage)
            if case["expected"] == "evidence_present"
            else None
        )
        result = {
            "id": case["id"],
            "family": case["family"],
            "claim": case["claim"],
            "expected": case["expected"],
            "notes": case.get("notes"),
            "arm": arm,
            "full_coverage": full,
            "groups_covered": group_coverage,
            "route_details": route_details,
            "route_coverage": route_coverage,
            "selected_chars": sum(len(s.text) for s in selected),
            "selected_count": len(selected),
            "source_chars": len(source.normalized_text),
            "source_span_count": len(source.spans),
            "source_content_hash": source.content_hash,
            "source_url": source.url,
            "constrained": sum(len(s.text) for s in original.spans) > 12000
            or len(original.spans) > 120,
            "arm_span_pool_constrained": sum(len(s.text) for s in source.spans) > 12000
            or len(source.spans) > 120,
            "selected_spans": [s.model_dump(mode="json") for s in selected],
            "exact_citation_groups": [q.model_dump(mode="json") for q in quotes],
            "integrity_pass": True,
        }
        results.append(result)
    dump(output, {"arm": arm, "fixture_sha256": sha(fixture), "cases": results})


def aggregate(paths):
    results = [json.loads(p.read_text()) for p in paths]
    summary = {"arms": {}, "regressions_vs_splitter": []}
    for item in results:
        cases = item["cases"]
        positive = [c for c in cases if c["expected"] == "evidence_present"]
        constrained = [c for c in positive if c["constrained"]]
        families = {}
        for family in sorted({c["family"] for c in positive}):
            subset = [c for c in positive if c["family"] == family]
            families[family] = {
                "covered": sum(c["full_coverage"] for c in subset),
                "total": len(subset),
            }
        summary["arms"][item["arm"]] = {
            "covered": sum(c["full_coverage"] for c in positive),
            "total": len(positive),
            "constrained_covered": sum(c["full_coverage"] for c in constrained),
            "constrained_total": len(constrained),
            "control_counts": dict(
                Counter(
                    c["expected"] for c in cases if c["expected"] != "evidence_present"
                )
            ),
            "families": families,
            "misses": [c["id"] for c in positive if not c["full_coverage"]],
            "integrity_pass": all(c["integrity_pass"] for c in cases),
        }
    baseline = {
        c["id"]: c for r in results if r["arm"] == "splitter_only" for c in r["cases"]
    }
    for result in results:
        if result["arm"] in ("current", "splitter_only"):
            continue
        for case in result["cases"]:
            reference = baseline[case["id"]]
            lost = [
                i
                for i, (old, new) in enumerate(
                    zip(reference["groups_covered"], case["groups_covered"])
                )
                if old and not new
            ]
            if lost:
                summary["regressions_vs_splitter"].append(
                    {
                        "arm": result["arm"],
                        "id": case["id"],
                        "expected": case["expected"],
                        "lost_groups": lost,
                    }
                )
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--worker", choices=ARMS)
    args = parser.parse_args()
    if args.worker:
        worker(args.worker, args.fixtures, args.output)
        return
    args.output.mkdir(parents=True, exist_ok=False)
    paths = []
    for arm in ARMS:
        target = args.output / f"{arm}.json"
        subprocess.run(
            [
                sys.executable,
                __file__,
                "--worker",
                arm,
                "--fixtures",
                str(args.fixtures.resolve()),
                "--output",
                str(target.resolve()),
            ],
            check=True,
        )
        paths.append(target)
    summary = aggregate(paths)
    dump(args.output / "summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
