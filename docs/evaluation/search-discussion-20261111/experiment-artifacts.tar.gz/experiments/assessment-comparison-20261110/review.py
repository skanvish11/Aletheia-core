"""Auditable assistant review of the frozen outputs; never calls a provider.

This is not an independent human review. The original predeclared full-component
coverage metric and a narrower decisive-fact metric are reported separately.
The latter is a post-run diagnostic breakdown, not a preregistered endpoint.
"""

import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = json.loads((ROOT / "results.json").read_text())
protocol = json.loads((ROOT / "protocol.json").read_text())
fixtures = {(f["case_id"], f["condition"]): f for f in protocol["fixtures"]}
decisive_components = {"b0012": "c8", "b0002": "c2", "b0011": "c3", "b0026": "c2"}
decisive_spans = {"b0012": {3}, "b0002": {285}, "b0011": {21, 23}, "b0026": {5}}
reviewed = []

for row in rows:
    case, arm, condition = row["case_id"], row["arm"], row["condition"]
    fixture = fixtures[case, condition]
    expected = fixture["expected_relation"]
    accepted = row["status"] == "accepted"
    result = row.get("output", {})
    decisive = complete = correct_abstention = False
    note = ""
    if condition == "withheld":
        if arm == "simple":
            correct_abstention = (
                accepted and result.get("relation") == "not_established"
            )
            note = (
                "Correctly abstained after one repair; first output asserted the claim with no citation."
                if case == "b0026"
                else "Correctly abstained on irrelevant supplied text."
                if correct_abstention
                else "Both attempts asserted SHA-256's output size with no citation; validator blocked publication."
            )
        else:
            correct_abstention = accepted and not any(
                a["relation"] in {"supports", "contradicts"}
                for a in result["assessments"]
            )
            note = "Returned only context/irrelevance; no factual decision from absent evidence."
    elif arm == "simple":
        correct_relation = accepted and result.get("relation") == expected
        decisive_citation = bool(decisive_spans[case] & set(result.get("span_ids", [])))
        unsupported_addition = case == "b0002" and row["repetition"] == 1
        decisive = complete = (
            correct_relation and decisive_citation and not unsupported_addition
        )
        if unsupported_addition:
            note = "Correct contradiction and citation, but adds Mercury as closest; Mercury is absent from the supplied spans. Fails full-answer grounding."
        elif result.get("relation") == "not_established":
            note = "Unnecessary abstention despite the supplied decisive passage."
        else:
            note = "Correct claim relation and concise answer, grounded in supplied decisive passage."
    else:
        assessments = result.get("assessments", [])

        def usable(component, expected=expected, case=case, assessments=assessments):
            return any(
                a["component_id"] == component
                and a["relation"] == expected
                and a["scope_match"]
                and bool(decisive_spans[case] & set(a["citation"]["span_ids"]))
                for a in assessments
            )

        decisive = accepted and usable(decisive_components[case])
        complete = accepted and all(usable(c) for c in fixture["target_components"])
        if case == "b0012":
            note = "Recognizes 1991 vs 2001, but scope_match=false excludes the contradiction from usable evidence."
        elif case == "b0002" and row["repetition"] == 1:
            note = "Returns only context for c1; decisive closest-planet component is missing."
        elif case == "b0002" and row["repetition"] == 2:
            note = "Decisive contradiction cites only distance span 333, not ordering span 285; rationale imports Mercury's ~0.39 AU from outside the supplied evidence."
        elif case == "b0002":
            note = "Decisive contradiction cites distance alone and scope_match=false; ordering evidence is misclassified."
        elif case == "b0011":
            note = "Correctly supports digest-size component c3, but c1/c2 remain context, so full predeclared component coverage is incomplete."
        else:
            note = "Both adoption components supported with the exact saved adoption sentence; source authority/final verdict are outside this test."
    reviewed.append(
        {
            "trial": row["trial"],
            "case_id": case,
            "arm": arm,
            "condition": condition,
            "repetition": row["repetition"],
            "schema_and_reference_checks_passed": accepted,
            "predeclared_component_coverage_pass": complete
            if condition == "relevant"
            else None,
            "posthoc_usable_decisive_fact": decisive
            if condition == "relevant"
            else None,
            "correct_abstention": correct_abstention
            if condition == "withheld"
            else None,
            "review_note": note,
        }
    )

summary = {}
for arm in ("current", "simple"):
    selected = [r for r in reviewed if r["arm"] == arm]
    summary[arm] = {
        "relevant_trials": 12,
        "full_predeclared_component_coverage": sum(
            r["predeclared_component_coverage_pass"] is True for r in selected
        ),
        "usable_decisive_fact_posthoc": sum(
            r["posthoc_usable_decisive_fact"] is True for r in selected
        ),
        "withheld_trials": 4,
        "correct_abstention": sum(r["correct_abstention"] is True for r in selected),
    }

assert len(rows) == 32 and len({r["trial"] for r in rows}) == 32
assert summary["current"]["full_predeclared_component_coverage"] == 3
assert summary["simple"]["full_predeclared_component_coverage"] == 9
assert summary["current"]["usable_decisive_fact_posthoc"] == 6
assert summary["simple"]["usable_decisive_fact_posthoc"] == 9
assert summary["current"]["correct_abstention"] == 4
assert summary["simple"]["correct_abstention"] == 3

by_case = defaultdict(dict)
for case in decisive_components:
    for arm in ("current", "simple"):
        subset = [
            r
            for r in reviewed
            if r["case_id"] == case and r["arm"] == arm and r["condition"] == "relevant"
        ]
        by_case[case][arm] = {
            "attempts": len(subset),
            "complete_component_coverage": sum(
                r["predeclared_component_coverage_pass"] for r in subset
            ),
            "usable_decisive_fact": sum(
                r["posthoc_usable_decisive_fact"] for r in subset
            ),
        }

report = {
    "reviewer": "assistant; no independent human review",
    "primary_rubric": "Predeclared target-component coverage, correct source-grounded relation, valid exact citations, and no unsupported assertion in the simple answer. Current evidence must be scope-admissible. This is not a final-verdict/source-authority test.",
    "secondary_rubric": "Post-run diagnostic: correctly cited and scope-admissible decisive fact, without requiring every current component to be marked supported. Reported separately to avoid conflating component completeness with reading the key fact.",
    "limitations": [
        "Four familiar hand-selected development claims, three repetitions each; no statistical or general-accuracy claim.",
        "Frozen pilot claim analysis is supplied to both arms; the current interpretation stage is not rerun.",
        "The simple task assesses the whole claim, while the current task assesses components and additional metadata. This tests a task/contract redesign bundle, not schema size alone.",
        "The Python excerpt was recovered manually from an oversized saved span. Passage selection is intentionally bypassed.",
        "No new web retrieval, final synthesis, source-sufficiency evaluation, or pipeline-budget evaluation.",
        "Model sampling uses provider defaults; three calls are repeated trials, not independent claims.",
        "One current SHA-256 answer marks a truncated source as credible_synthesis; auxiliary metadata correctness is not included in the decisive-fact score.",
    ],
    "summary": summary,
    "by_case": dict(by_case),
    "trials": reviewed,
}
(ROOT / "review.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"summary": summary, "by_case": dict(by_case)}, indent=2))
