"""Frozen-passage assessment A/B diagnostic; does not alter application code or data."""

import argparse
import asyncio
import hashlib
import json
import sqlite3
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated, Literal

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline/src"))

import httpx
from aletheia import verification
from aletheia.budgets import CallBudget
from aletheia.config import ProviderSettings
from aletheia.evidence import excerpts
from aletheia.providers.errors import ErrorCode, ProviderError
from aletheia.providers.nebius import NebiusProvider
from aletheia.research_contracts import Assertion, Snapshot, Span
from aletheia.tasks import InvalidTask, Tasks, TaskValidationError
from pydantic import BaseModel, ConfigDict, Field

PILOT = ROOT.parents[1] / "aletheia-phase-one/data/phase-one-pilot-reviewed-20261110"
CASE_SPECS = {
    "b0012": ("ubc.ca", [3], [1, 2], "contradicts", ["c8"]),
    "b0002": ("nasa.gov", [285, 333], [3, 4, 5], "contradicts", ["c2"]),
    "b0011": ("encryptionconsulting", [21, 23], [2, 3], "supports", ["c1", "c2", "c3"]),
    "b0026": ("unfccc", [5, 6, 7, 8], [2, 3, 4], "supports", ["c1", "c2"]),
}
CAP = 64


def dump(path, obj):
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def sha(value):
    return hashlib.sha256(value).hexdigest()


class SimpleAssessment(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    relation: Literal["supports", "contradicts", "not_established"]
    answer: Annotated[str | None, Field(max_length=300)]
    span_ids: Annotated[
        list[Annotated[int, Field(strict=True, ge=1)]], Field(max_length=6)
    ]


SIMPLE_PROMPT = """Read only the supplied source spans and assess the original assertion.text.
Return a short source-grounded answer, the decisive span IDs, and the relation to the
entire claim. supports means all material factual details are established by these
spans. contradicts means an explicit incompatible fact about the same subject/event
is established. not_established means these spans do not settle the claim; return
answer=null and span_ids=[] in that case. Lack of evidence is not contradiction.
Do not use outside knowledge or treat the assertion's analysis/reason as evidence.
Preserve the exact subject, event, timeframe, quantity, units and definition;
do not conflate different events or treat a narrower fact as the entire claim.
Cite only supplied IDs, sorted and unique. The application reconstructs quotations.
This assesses what the supplied passage establishes, not overall source sufficiency.
"""


class Captured(Exception):
    pass


class CaptureTask:
    async def call(self, name, instructions, data, schema, validate):
        self.arguments = (name, instructions, data, schema, validate)
        raise Captured


def load_cases():
    fixtures = []
    for cid, (host, positive, negative, expected, targets) in CASE_SPECS.items():
        saved_path = PILOT / cid / f"{cid}.json"
        db_path = PILOT / cid / "investigations.sqlite3"
        saved = json.loads(saved_path.read_text())
        inv = saved["investigation"]
        assertion = Assertion(
            text=inv["claim"],
            analysis=inv["claim_analysis"],
            kind="direct_record",
            consequential=False,
            recommended_route="quick",
        )
        with sqlite3.connect(f"file:{db_path}?mode=ro", uri=True) as connection:
            sources = [
                json.loads(row[0])
                for row in connection.execute(
                    "SELECT payload_json FROM research_records WHERE kind='snapshot'"
                )
            ]
        source = Snapshot.model_validate(next(s for s in sources if host in s["url"]))
        original_hash = sha(db_path.read_bytes())
        derived = None
        if cid == "b0012":
            # Extract an exact bounded subsection of the giant saved span; no new facts.
            start = source.normalized_text.index("1. A Brief History of Python")
            anchor = source.normalized_text.index(
                "Van Rossum released it publicly in 1991"
            )
            end = source.normalized_text.index("computer scientists.", anchor) + len(
                "computer scientists."
            )
            old = next(s for s in source.spans if s.id == 3)
            assert old.start <= start < end <= old.end
            derived = {
                "parent_span_id": 3,
                "parent_start": old.start,
                "parent_end": old.end,
                "excerpt_start": start,
                "excerpt_end": end,
            }
            replacement = Span(
                id=3,
                start=start,
                end=end,
                text=source.normalized_text[start:end],
                kind="block",
            )
            source = source.model_copy(
                update={
                    "spans": [replacement if s.id == 3 else s for s in source.spans]
                }
            )
        for condition, ids in [("relevant", positive), ("withheld", negative)]:
            selected = [s for s in source.spans if s.id in ids]
            assert len(selected) == len(ids)
            for span in selected:
                assert source.normalized_text[span.start : span.end] == span.text
            fixtures.append(
                {
                    "case_id": cid,
                    "condition": condition,
                    "assertion": assertion,
                    "source": source,
                    "selected": selected,
                    "expected_relation": expected
                    if condition == "relevant"
                    else "not_established",
                    "target_components": targets,
                    "derived_excerpt": derived,
                    "database_path": str(db_path),
                    "database_sha256": original_hash,
                    "saved_case_sha256": sha(saved_path.read_bytes()),
                }
            )
    return fixtures


async def capture(fixture):
    task = CaptureTask()
    original = verification.select_passages
    verification.select_passages = lambda assertion, source: fixture["selected"]
    try:
        await verification.assess(task, fixture["assertion"], fixture["source"])
    except Captured:
        return task.arguments
    finally:
        verification.select_passages = original
    raise AssertionError("Assessment request was not captured")


def validate_simple(result, fixture):
    ids = result.span_ids
    supplied = {s.id for s in fixture["selected"]}
    if result.relation == "not_established":
        if ids or result.answer is not None:
            raise TaskValidationError("citation_spans")
    else:
        if not result.answer or not ids:
            raise TaskValidationError("citation_spans")
        excerpts(fixture["source"], ids, supplied)


class AuditTransport(httpx.AsyncBaseTransport):
    """Retain only requested public JSON output and safe usage, never headers or reasoning."""

    def __init__(self):
        self.inner = httpx.AsyncHTTPTransport()
        self.records = []
        self.context = None

    async def handle_async_request(self, request):
        if len(self.records) >= CAP:
            raise ProviderError("nebius", ErrorCode.BUDGET)
        record = {"trial": self.context, "http_status": None}
        self.records.append(record)
        started = time.monotonic()
        try:
            response = await self.inner.handle_async_request(request)
            await response.aread()
            record["http_status"] = response.status_code
            if response.status_code == 200:
                try:
                    body = response.json()
                    record["usage"] = body.get("usage")
                    choice = body["choices"][0]
                    record["finish_reason"] = choice.get("finish_reason")
                    content = choice["message"].get("content") or ""
                    record["output_chars"] = len(content)
                    try:
                        record["output"] = json.loads(content)
                    except (ValueError, TypeError):
                        record["non_json_output_sha256"] = sha(content.encode())
                except (ValueError, KeyError, IndexError, TypeError):
                    record["response_envelope_invalid"] = True
            return response
        finally:
            record["elapsed_seconds"] = time.monotonic() - started

    async def aclose(self):
        await self.inner.aclose()


def protocol(fixtures):
    return {
        "baseline_revision": (ROOT / "baseline-revision.txt").read_text().strip(),
        "pilot_revision": "c885bbad8c4fb29a619bdf41236c95b94ef003ed",
        "purpose": "Compare supplied-passage assessment, not retrieval or final verdict quality.",
        "arms": ["current", "simple"],
        "relevant_repetitions": 3,
        "withheld_repetitions": 1,
        "planned_trials": 32,
        "network_attempt_cap": CAP,
        "task_repair_limit": 1,
        "transport_retries": 0,
        "tavily_calls": 0,
        "matching": "Identical serialized input per pair, frozen original claim analysis, same model/settings and task wrapper.",
        "scope": "Source sufficiency, authority, full component coverage and final synthesis are not equivalent between arms; common metric is grounded decisive relation.",
        "scoring": "Assistant-predeclared source-based relation, cited decisive passage, manual output review; not independent human acceptance.",
        "sampling": "Three repetitions of four familiar development claims, plus one withheld-evidence control per claim. No significance claim.",
        "python_excerpt": "Exact subsection of original saved span 3; deliberately bypasses the known selection failure in both arms.",
        "fixtures": [
            {
                k: (v.model_dump(mode="json") if k == "assertion" else v)
                for k, v in f.items()
                if k not in {"source", "selected"}
            }
            | {
                "source_id": f["source"].id,
                "url": f["source"].url,
                "source_content_hash": f["source"].content_hash,
                "selected_spans": [s.model_dump() for s in f["selected"]],
            }
            for f in fixtures
        ],
    }


def summarize(rows):
    output = {}
    for arm in ("current", "simple"):
        arm_rows = [r for r in rows if r["arm"] == arm]
        output[arm] = {
            "trials": len(arm_rows),
            "valid_first_attempt": sum(r["valid_first_attempt"] for r in arm_rows),
            "valid_after_repair": sum(r["status"] == "accepted" for r in arm_rows),
            "network_calls": sum(r["network_calls"] for r in arm_rows),
            "prompt_tokens": sum(r["usage"]["prompt_tokens"] for r in arm_rows),
            "completion_tokens": sum(r["usage"]["completion_tokens"] for r in arm_rows),
            "elapsed_seconds_sum": sum(r["elapsed_seconds"] for r in arm_rows),
        }
    return output


async def execute(fixtures, args):
    request_specs = {}
    for fixture in fixtures:
        key = fixture["case_id"] + "/" + fixture["condition"]
        request_specs[key] = await capture(fixture)
    dump(ROOT / "protocol.json", protocol(fixtures))
    dump(
        ROOT / "requests.json",
        {
            key: {
                "input": args_[2],
                "input_sha256": sha(json.dumps(args_[2], ensure_ascii=False).encode()),
                "current_instructions": args_[1],
                "current_schema": args_[3].model_json_schema(),
                "simple_instructions": SIMPLE_PROMPT,
                "simple_schema": SimpleAssessment.model_json_schema(),
            }
            for key, args_ in request_specs.items()
        },
    )
    # Meaningful offline check: both malformed references and unsupported abstention shapes fail.
    f = fixtures[0]
    validate_simple(
        SimpleAssessment(relation="contradicts", answer="1991", span_ids=[3]), f
    )
    for bad in [
        SimpleAssessment(relation="contradicts", answer="1991", span_ids=[999999]),
        SimpleAssessment(relation="not_established", answer="1991", span_ids=[]),
    ]:
        try:
            validate_simple(bad, f)
        except TaskValidationError:
            pass
        else:
            raise AssertionError("Invalid test response admitted")
    if not args.live:
        print(
            json.dumps(
                {
                    "prepared": True,
                    "fixtures": len(fixtures),
                    "planned_trials": 32,
                    "max_network_attempts": CAP,
                    "network_calls": 0,
                }
            ),
            flush=True,
        )
        return
    if (ROOT / "results.json").exists():
        raise SystemExit("Results already exist; no automatic rerun.")
    loaded = ProviderSettings.from_environment(dotenv_path=args.dotenv)
    pilot_config = json.loads(
        (
            ROOT.parents[1]
            / "aletheia-phase-one/docs/evaluation/phase-one-reviewed-pilot-results.json"
        ).read_text()
    )["manifest"]["config"]
    settings = ProviderSettings.model_validate(
        {**loaded.model_dump(), **pilot_config, "max_retries": 0}
    )
    if not settings.nebius_api_key:
        raise SystemExit("Model credential unavailable; no provider call made.")
    settings.validate_model_controls()
    manifest = {
        "started_at": datetime.now(UTC).isoformat(),
        "settings": settings.model_dump(exclude={"nebius_api_key", "tavily_api_key"}),
        "temperature": "provider default, matching baseline adapter",
        "seed": "not set",
        "protocol_sha256": sha((ROOT / "protocol.json").read_bytes()),
        "requests_sha256": sha((ROOT / "requests.json").read_bytes()),
        "script_sha256": sha(Path(__file__).read_bytes()),
        "python": sys.version,
    }
    dump(ROOT / "manifest.json", manifest)
    rows = []
    transport = AuditTransport()
    async with NebiusProvider(settings, transport=transport) as model:
        schedule = []
        for repetition in range(3):
            for fixture in fixtures:
                if fixture["condition"] == "withheld" and repetition:
                    continue
                order = (
                    ("current", "simple")
                    if (repetition + list(CASE_SPECS).index(fixture["case_id"])) % 2
                    == 0
                    else ("simple", "current")
                )
                for arm in order:
                    schedule.append((fixture, repetition + 1, arm))
        for fixture, repetition, arm in schedule:
            key = fixture["case_id"] + "/" + fixture["condition"]
            trial = f"{key}/{repetition}/{arm}"
            row = {
                "trial": trial,
                "case_id": fixture["case_id"],
                "condition": fixture["condition"],
                "repetition": repetition,
                "arm": arm,
                "events": [],
                "status": "started",
            }
            transport.context = trial
            before = len(transport.records)
            started = time.monotonic()
            budget = CallBudget(2, 0, 0, time.monotonic() + 100)

            async def emit(event, payload, row=row):
                row["events"].append({"type": event, "payload": payload})

            tasks = Tasks(model, budget, emit)
            name, prompt, data, schema, validate = request_specs[key]
            if arm == "simple":
                prompt, schema = SIMPLE_PROMPT, SimpleAssessment
                validate = lambda result, f=fixture: validate_simple(result, f)
            try:
                result = await tasks.call(name, prompt, data, schema, validate)
                row.update(status="accepted", output=result.model_dump(mode="json"))
            except InvalidTask:
                row["status"] = "invalid_task_output"
            except ProviderError as exc:
                row.update(status=exc.code.value, validation_code=exc.validation_code)
            row["usage"] = tasks.tokens
            row["elapsed_seconds"] = time.monotonic() - started
            row["network_calls"] = len(transport.records) - before
            finishes = [
                e["payload"] for e in row["events"] if e["type"] == "task_finished"
            ]
            row["valid_first_attempt"] = bool(
                finishes and finishes[0]["outcome"] == "success"
            )
            row["validation_failures"] = [
                p["validation_code"] for p in finishes if p["outcome"] != "success"
            ]
            rows.append(row)
            dump(ROOT / "results.json", rows)
            dump(ROOT / "provider-records.json", transport.records)
            dump(ROOT / "summary.json", summarize(rows))
            print(
                json.dumps(
                    {
                        k: row[k]
                        for k in [
                            "trial",
                            "status",
                            "network_calls",
                            "validation_failures",
                        ]
                    }
                ),
                flush=True,
            )
            if row["status"] in {
                "authentication",
                "quota_exceeded",
                "configuration",
                "invalid_request",
                "network",
                "unavailable",
                "rate_limited",
            }:
                manifest["stopped_early"] = row["status"]
                break
    manifest.update(
        finished_at=datetime.now(UTC).isoformat(),
        trials_recorded=len(rows),
        network_attempts=len(transport.records),
        historical_databases_unchanged=all(
            sha(Path(f["database_path"]).read_bytes()) == f["database_sha256"]
            for f in fixtures
        ),
    )
    dump(ROOT / "manifest.json", manifest)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv", type=Path)
    arguments = parser.parse_args()
    asyncio.run(execute(load_cases(), arguments))
