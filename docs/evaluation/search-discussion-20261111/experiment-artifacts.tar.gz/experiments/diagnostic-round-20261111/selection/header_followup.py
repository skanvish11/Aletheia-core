"""Post-audit offline header test holding anchor-bundle admission fixed."""

import json
from collections import Counter
from datetime import UTC, datetime

import selection_experiment as run


def select(assertion, source, *, include_header):
    candidates = [s for s in source.spans if not run.boilerplate(s.text)]
    query = run.terms(assertion.text)
    frequencies = Counter(t for s in candidates for t in run.terms(s.text))
    ranked = sorted(
        candidates,
        key=lambda s: (
            -sum(1 / frequencies[t] for t in run.terms(s.text) & query),
            s.id,
        ),
    )
    by_id = {s.id: s for s in candidates}
    headers = run.table_context(source)
    selected, size = {}, 0
    for anchor in ranked:
        if anchor.id in selected:
            continue
        mandatory = [anchor.id]
        if include_header:
            mandatory.append(headers.get(anchor.id, anchor.id))
        mandatory = list(dict.fromkeys(mandatory))
        additions = [by_id[i] for i in mandatory if i in by_id and i not in selected]
        if (
            size + sum(len(s.text) for s in additions) > run.MAX_CHARS
            or len(selected) + len(additions) > run.MAX_SPANS
        ):
            continue
        for span in additions:
            selected[span.id] = span
            size += len(span.text)
        for i in [anchor.id - 1, anchor.id + 1]:
            span = by_id.get(i)
            if (
                span
                and i not in selected
                and size + len(span.text) <= run.MAX_CHARS
                and len(selected) < run.MAX_SPANS
            ):
                selected[i] = span
                size += len(span.text)
    return [selected[i] for i in sorted(selected)]


def main():
    if (run.ROOT / "header-followup-results.json").exists():
        raise SystemExit("Follow-up results exist; refusing overwrite.")
    names = [
        "selection_experiment.py",
        "protocol.json",
        "results.json",
        "manifest.json",
    ]
    frozen_hashes = {name: run.sha((run.ROOT / name).read_bytes()) for name in names}
    protocol = {
        "purpose": "Distinguish table-header dependency from the changed anchor-bundle admission behavior in the original structural candidate.",
        "timing": "Post-result audit follow-up, not part of the original preregistered experiment.",
        "arms": ["bundle_admission_without_headers", "bundle_admission_with_headers"],
        "fixed": "Same derived bounded spans, lexical scoring, atomic anchor-bundle admission, optional adjacent context, 12000-character budget and 120-span budget.",
        "difference": "Only whether a table anchor's mandatory bundle includes its associated header.",
        "expectation": "No predeclared winner; compare retained required evidence/context using the original frozen fixture expectations.",
        "original_hashes": frozen_hashes,
        "runner_sha256": run.sha((run.ROOT / "header_followup.py").read_bytes()),
    }
    run.dump("header-followup-protocol.json", protocol)
    rows = []
    for fixture in run.cases():
        source, _ = run.derived_view(fixture["source"])
        for include_header in [False, True]:
            selected = select(
                fixture["assertion"], source, include_header=include_header
            )
            if include_header:
                assert selected == run.select_with_structure(
                    fixture["assertion"], source
                )
            assert sum(len(s.text) for s in selected) <= run.MAX_CHARS
            assert len(selected) <= run.MAX_SPANS
            for span in selected:
                assert (
                    fixture["source"].normalized_text[span.start : span.end]
                    == span.text
                )
            coverage = run.coverage(fixture["required"], source, selected)
            rows.append(
                {
                    "case_id": fixture["id"],
                    "include_header": include_header,
                    "context_complete": all(x["covered"] for x in coverage)
                    if coverage
                    else None,
                    "coverage": coverage,
                    "selected_ids": [s.id for s in selected],
                    "selected_count": len(selected),
                    "selected_chars": sum(len(s.text) for s in selected),
                }
            )
    assert all(
        run.sha((run.ROOT / name).read_bytes()) == digest
        for name, digest in frozen_hashes.items()
    )
    run.dump("header-followup-results.json", rows)
    addendum = {
        "created_at": datetime.now(UTC).isoformat(),
        "original_comparison_limitation": "The original bounded versus bounded_with_table_context contrast changed two behaviors: header inclusion and anchor-bundle admission. Current select_passages can still admit a neighbor when an anchor does not fit; the structural candidate skips the whole anchor iteration if its mandatory bundle does not fit. Therefore the original contrast alone cannot attribute gains to headers alone.",
        "original_files_unchanged": True,
        "followup": "A new offline paired check holds structural anchor-bundle admission fixed and toggles only header dependency. Results are separately saved; no production or original result files changed.",
        "causal_scope": "The follow-up can identify the header-dependency effect on the frozen fixtures under the shared structural admission policy. It is not an independent confirmation set or evidence about all document layouts.",
        "results": [
            {
                "case_id": fixture["id"],
                "without_headers": next(
                    r["context_complete"]
                    for r in rows
                    if r["case_id"] == fixture["id"] and not r["include_header"]
                ),
                "with_headers": next(
                    r["context_complete"]
                    for r in rows
                    if r["case_id"] == fixture["id"] and r["include_header"]
                ),
            }
            for fixture in run.cases()
        ],
        "artifacts": [
            "header-followup-protocol.json",
            "header-followup-results.json",
            "header_followup.py",
        ],
    }
    run.dump("audit-addendum.json", addendum)
    print(json.dumps(addendum, indent=2))


if __name__ == "__main__":
    main()
