"""Offline reproducibility, provenance and negative checks for the selection candidate."""

import json
import subprocess

import selection_experiment as run
from aletheia.tasks import TaskValidationError


def main():
    rows = json.loads((run.ROOT / "results.json").read_text())
    manifest = json.loads((run.ROOT / "manifest.json").read_text())
    assert (
        run.sha((run.ROOT / "selection_experiment.py").read_bytes())
        == manifest["runner_sha256"]
    )
    assert (
        run.sha((run.ROOT / "protocol.json").read_bytes())
        == manifest["protocol_sha256"]
    )
    fixtures = {f["id"]: f for f in run.cases()}
    checked_spans, checked_groups = 0, 0
    for row in rows:
        f = fixtures[row["case_id"]]
        original = f["source"]
        view, parents = run.derived_view(original)
        source = original if row["arm"] == "current" else view
        selected = [run.Span.model_validate(s) for s in row["selected"]]
        assert source.id == row["snapshot_id"]
        for s in selected:
            assert original.normalized_text[s.start : s.end] == s.text
            if row["arm"] != "current":
                p = parents[s.id]
                parent = next(
                    span for span in original.spans if span.id == p["original_span_id"]
                )
                assert p["original_snapshot_id"] == original.id
                assert parent.start <= s.start < s.end <= parent.end
                assert source.id != original.id
                assert source.normalized_text == original.normalized_text
                assert source.content_hash == original.content_hash
            checked_spans += 1
        ids = [s.id for s in selected]
        if ids:
            for quote in run.excerpts(source, ids, set(ids)):
                assert quote.text == original.normalized_text[quote.start : quote.end]
                assert quote.quote_hash == run.sha(quote.text.encode())
                checked_groups += 1
        assert sum(len(s.text) for s in selected) <= run.MAX_CHARS
        assert len(ids) <= run.MAX_SPANS
        assert run.coverage(f["required"], source, selected) == row["coverage"]
    # Demonstrate that the declared coverage metric detects the original Python omission.
    python_rows = {r["arm"]: r for r in rows if r["case_id"] == "b0012"}
    assert python_rows["current"]["context_complete"] is False
    assert python_rows["bounded"]["context_complete"] is True
    # Real citation code must reject a reference that the source does not contain.
    source, _ = run.derived_view(fixtures["b0012"]["source"])
    nonexistent = max(s.id for s in source.spans) + 1
    try:
        run.excerpts(source, [nonexistent], {nonexistent})
    except TaskValidationError:
        pass
    else:
        raise AssertionError("Unknown derived span accepted")
    production = run.WORKSPACE / "aletheia-phase-one"
    revision = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=production, text=True
    ).strip()
    status = subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=production, text=True
    )
    assert revision == run.REVISION and status == ""
    report = {
        "rows_checked": len(rows),
        "selected_spans_checked": checked_spans,
        "citation_groups_checked": checked_groups,
        "source_and_parent_provenance_verified": True,
        "budgets_verified": True,
        "unknown_span_rejected": True,
        "coverage_sensitive_to_original_bug": True,
        "production_revision": revision,
        "production_worktree_clean": True,
        "historical_databases_unchanged": all(
            run.sha(run.Path(f["database_path"]).read_bytes()) == f["database_sha256"]
            for f in fixtures.values()
            if not f["synthetic"]
        ),
    }
    run.dump("verification.json", report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
