"""Offline source-selection diagnostic. Only writes within this experiment folder."""

import hashlib
import json
import re
import sqlite3
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[2]
sys.path.insert(0, str(ROOT / "baseline/src"))
from aletheia.evidence import excerpts, snapshot
from aletheia.passages import boilerplate, select_passages, terms
from aletheia.research_contracts import Assertion, Snapshot, Span

REVISION = "0246699a9e478b4588a38df252a0a047a4910624"
MAX_CHARS, MAX_SPANS = 12000, 120
CHUNK_CHARS, OVERLAP_CHARS = 1500, 300


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(name, obj):
    (ROOT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


def assertion(text):
    return Assertion(
        text=text, kind="direct_record", consequential=False, recommended_route="quick"
    )


def synthetic(cid, claim, text, required):
    source = snapshot(
        url="https://example.org/" + cid,
        title=cid,
        published_date=None,
        retrieved_at=datetime(2026, 11, 11, tzinfo=UTC),
        text=text,
    )
    source = source.model_copy(
        update={"id": str(uuid5(NAMESPACE_URL, "selection-fixture/" + cid))}
    )
    return {
        "id": cid,
        "synthetic": True,
        "assertion": assertion(claim),
        "source": source,
        "required": required,
        "expected": "evidence_present" if required else "no_decisive_evidence",
    }


def cases():
    pilot = WORKSPACE / "aletheia-phase-one/data/phase-one-pilot-reviewed-20261110"
    specs = {
        "b0012": (
            "ubc.ca",
            [
                "It's the brainchild of Guido van Rossum, who began writing Python",
                "Van Rossum released it publicly in 1991",
            ],
        ),
        "b0002": ("nasa.gov", ["Venus is the second planet from the Sun"]),
        "b0011": (
            "encryptionconsulting",
            [
                "SHA-256 is a cryptographic hash function",
                "produces a fixed 256-bit (64-character hexadecimal) digest",
            ],
        ),
        "b0026": (
            "unfccc",
            [
                "The Conference of the Parties, at its 21st session, adopted the Paris Agreement on 12 December 2015."
            ],
        ),
    }
    fixtures = []
    for cid, (host, required) in specs.items():
        db = pilot / cid / "investigations.sqlite3"
        with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as connection:
            sources = [
                json.loads(row[0])
                for row in connection.execute(
                    "SELECT payload_json FROM research_records WHERE kind='snapshot'"
                )
            ]
        source = Snapshot.model_validate(next(s for s in sources if host in s["url"]))
        saved = json.loads((pilot / cid / (cid + ".json")).read_text())["investigation"]
        fixtures.append(
            {
                "id": cid,
                "synthetic": False,
                "assertion": assertion(saved["claim"]),
                "source": source,
                "required": required,
                "expected": "evidence_present",
                "database_path": str(db),
                "database_sha256": sha(db.read_bytes()),
            }
        )
    padding = (
        "The archive contains historical maintenance notes and visitor information. "
    )
    subject = "The Rhea observatory was built on the northern ridge."
    fact = "It opened to researchers in 1974."
    fixtures.append(
        synthetic(
            "oversized_antecedent",
            "The Rhea observatory opened to researchers in 1974.",
            "| Archive | " + padding * 220 + subject + " " + fact + " " + padding * 180,
            [subject, fact],
        )
    )
    subject = "The Orion receiver is the subject of this equipment note."
    fact = "It operates at 42 megahertz."
    fixtures.append(
        synthetic(
            "adjacent_antecedent",
            "The Orion receiver operates at 42 megahertz.",
            "# Equipment register\n"
            + subject
            + "\n"
            + fact
            + "\nThe enclosure is blue.",
            [subject, fact],
        )
    )
    distractions = "\n".join(
        "Lumen probe information bulletin "
        + str(i)
        + ": "
        + "General operational and visitor material. " * 4
        for i in range(110)
    )
    header = "| Instrument | Calibration year | Capacity |"
    target = "| Lumen probe | 2017 | 400 |"
    table = "\n".join(
        [header, "| --- | --- | --- |"]
        + [f"| Test unit {i} | 2000 | 20 |" for i in range(45)]
        + [target]
    )
    fixtures.append(
        synthetic(
            "table_header",
            "The Lumen probe was calibrated in 2017.",
            distractions + "\n" + table,
            [header, target],
        )
    )
    distractions = "\n".join(
        "Aurora ferry entered service in 2008 is a phrase used in the index, without a dated operating record. "
        + "Index description. " * 5
        + str(i)
        for i in range(110)
    )
    target = "The Aurora ferry began carrying passengers in 2008."
    fixtures.append(
        synthetic(
            "lexical_distractors",
            "The Aurora ferry entered service in 2008.",
            distractions + "\n" + target,
            [target],
        )
    )
    fixtures.append(
        synthetic(
            "absent_evidence",
            "The Rhea observatory opened in 1974.",
            "# Visitor information\nOpening history is not provided in this document.\nContact the archive for records.",
            [],
        )
    )
    for f in fixtures:
        for required in f["required"]:
            assert required in f["source"].normalized_text, (f["id"], required)
        for span in f["source"].spans:
            assert f["source"].normalized_text[span.start : span.end] == span.text
    return fixtures


def split_bounds(text, start, end):
    """Bound by sentences where possible, otherwise whitespace; overlap retains nearby context."""
    cursor = start
    while cursor < end:
        limit = min(cursor + CHUNK_CHARS, end)
        boundary = limit
        if limit < end:
            candidates = [
                m.end() for m in re.finditer(r"[.!?](?=\s)", text[cursor:limit])
            ]
            candidates = [cursor + b for b in candidates if b >= CHUNK_CHARS // 2]
            if candidates:
                boundary = candidates[-1]
            else:
                last_space = text.rfind(" ", cursor + CHUNK_CHARS // 2, limit)
                if last_space > cursor:
                    boundary = last_space
        yield cursor, boundary
        if boundary == end:
            return
        overlap_start = max(cursor + 1, boundary - OVERLAP_CHARS)
        # Move to the next word boundary; exact chars are retained, never rewritten.
        space = text.find(" ", overlap_start, boundary)
        cursor = space + 1 if space >= 0 else boundary


def derived_view(source):
    spans, parents = [], {}
    for original in source.spans:
        bounds = (
            [(original.start, original.end)]
            if len(original.text) <= CHUNK_CHARS
            else list(
                split_bounds(source.normalized_text, original.start, original.end)
            )
        )
        for start, end in bounds:
            span = Span(
                id=len(spans) + 1,
                start=start,
                end=end,
                text=source.normalized_text[start:end],
                kind=original.kind,
            )
            spans.append(span)
            parents[span.id] = {
                "original_snapshot_id": source.id,
                "original_span_id": original.id,
                "start": start,
                "end": end,
            }
    view = source.model_copy(
        update={
            "id": str(uuid5(NAMESPACE_URL, source.id + "/bounded-1500-overlap-300-v1")),
            "spans": spans,
            "splitter_version": "bounded-1500-overlap-300-v1",
        }
    )
    return view, parents


def table_context(source):
    """Map table rows to the header preceding their uninterrupted pipe-row sequence."""
    context, header = {}, None
    previous = None
    for span in source.spans:
        stripped = span.text.strip()
        if (
            stripped.startswith("|")
            and stripped.endswith("|")
            and stripped.count("|") >= 3
        ):
            if (
                previous is None
                or source.normalized_text[previous.end : span.start].strip()
            ):
                header = span.id
            if header is None:
                header = span.id
            context[span.id] = header
            previous = span
        else:
            header, previous = None, None
    return context


def select_with_structure(assertion_, source):
    candidates = [s for s in source.spans if not boilerplate(s.text)]
    query = terms(assertion_.text)
    frequencies = Counter(t for s in candidates for t in terms(s.text))
    ranked = sorted(
        candidates,
        key=lambda s: (-sum(1 / frequencies[t] for t in terms(s.text) & query), s.id),
    )
    by_id = {s.id: s for s in candidates}
    headers = table_context(source)
    selected, size = {}, 0
    for anchor in ranked:
        if anchor.id in selected:
            continue
        mandatory = list(dict.fromkeys([anchor.id, headers.get(anchor.id, anchor.id)]))
        additions = [by_id[i] for i in mandatory if i in by_id and i not in selected]
        if (
            size + sum(len(s.text) for s in additions) > MAX_CHARS
            or len(selected) + len(additions) > MAX_SPANS
        ):
            continue
        for span in additions:
            selected[span.id] = span
            size += len(span.text)
        for i in [anchor.id - 1, anchor.id + 1]:
            s = by_id.get(i)
            if (
                s
                and i not in selected
                and size + len(s.text) <= MAX_CHARS
                and len(selected) < MAX_SPANS
            ):
                selected[i] = s
                size += len(s.text)
    return [selected[i] for i in sorted(selected)]


def coverage(required, source, selected):
    matches = []
    for phrase in required:
        occurrences = [
            m.start() for m in re.finditer(re.escape(phrase), source.normalized_text)
        ]
        found = False
        for start in occurrences:
            cursor, end = start, start + len(phrase)
            for s in sorted(selected, key=lambda s: s.start):
                if s.start <= cursor < s.end:
                    cursor = s.end
                if cursor >= end:
                    found = True
                    break
            if found:
                break
        matches.append({"required": phrase, "covered": found})
    return matches


def main():
    if (ROOT / "results.json").exists():
        raise SystemExit("Results exist; refusing overwrite.")
    fixtures = cases()
    protocol = {
        "revision": REVISION,
        "max_chars": MAX_CHARS,
        "max_spans": MAX_SPANS,
        "chunk_chars": CHUNK_CHARS,
        "overlap_chars": OVERLAP_CHARS,
        "arms": ["current", "bounded", "bounded_with_table_context"],
        "primary": "Every predeclared decisive proposition and required subject/event/table context must occur in selected exact source ranges. No model judgement, final verdict or source sufficiency claim.",
        "ranking": "Same term extraction and document-frequency scoring across arms; repartitioning necessarily changes document-frequency counts. Structural arm adds header dependency only.",
        "budget_accounting": "Count actual characters of every selected span, including overlap; no hidden free context.",
        "citation_policy": "New derived snapshot view and span IDs; parent snapshot/span and exact original-text offsets retained. Original stored snapshots never modified. Production persistence integration not implemented.",
        "fixtures": [
            {k: f[k] for k in ["id", "synthetic", "required", "expected"]}
            | {
                "claim": f["assertion"].text,
                "source_id": f["source"].id,
                "source_hash": f["source"].content_hash,
            }
            for f in fixtures
        ],
    }
    dump("protocol.json", protocol)
    # Protocol saved before applying or measuring either selector candidate.
    rows = []
    for f in fixtures:
        original = f["source"]
        original_serialized = original.model_dump_json()
        view, parents = derived_view(original)
        for arm in protocol["arms"]:
            source = original if arm == "current" else view
            selected = (
                select_with_structure(f["assertion"], source)
                if arm == "bounded_with_table_context"
                else select_passages(
                    f["assertion"], source, max_chars=MAX_CHARS, max_spans=MAX_SPANS
                )
            )
            assert sum(len(s.text) for s in selected) <= MAX_CHARS
            assert len(selected) <= MAX_SPANS
            for s in selected:
                assert original.normalized_text[s.start : s.end] == s.text
                # Citation reconstruction from the actual production function, one derived span at a time.
                quote = excerpts(source, [s.id], {p.id for p in selected})[0]
                assert (
                    quote.text == s.text
                    and quote.start == s.start
                    and quote.end == s.end
                )
            checked = coverage(f["required"], source, selected)
            rows.append(
                {
                    "case_id": f["id"],
                    "synthetic": f["synthetic"],
                    "arm": arm,
                    "expected": f["expected"],
                    "context_complete": all(x["covered"] for x in checked)
                    if checked
                    else None,
                    "coverage": checked,
                    "selected_chars": sum(len(s.text) for s in selected),
                    "selected_count": len(selected),
                    "selected": [s.model_dump() for s in selected],
                    "snapshot_id": source.id,
                    "source_identity_and_offsets_verified": True,
                }
            )
        assert original.model_dump_json() == original_serialized
        if f["id"] == "b0012":
            dump("python-derived-snapshot.json", view.model_dump(mode="json"))
            dump("python-derived-provenance.json", parents)
            dump("python-original-snapshot.json", original.model_dump(mode="json"))
            selected = select_with_structure(f["assertion"], view)
            decisive = [
                s.id
                for s in selected
                if "Van Rossum released it publicly in 1991" in s.text
            ]
            dump(
                "python-admission-fixture.json",
                {
                    "claim": f["assertion"].text,
                    "snapshot_id": view.id,
                    "span_ids": decisive,
                    "supplied_ids": [s.id for s in selected],
                },
            )
    dump("results.json", rows)
    summary = {
        arm: {
            "saved_context_complete": sum(
                r["context_complete"] is True
                for r in rows
                if r["arm"] == arm and not r["synthetic"]
            ),
            "saved_total": 4,
            "synthetic_context_complete": sum(
                r["context_complete"] is True
                for r in rows
                if r["arm"] == arm and r["synthetic"]
            ),
            "synthetic_evidence_present_total": 4,
        }
        for arm in protocol["arms"]
    }
    manifest = {
        "finished_at": datetime.now(UTC).isoformat(),
        "runner_sha256": sha(Path(__file__).read_bytes()),
        "protocol_sha256": sha((ROOT / "protocol.json").read_bytes()),
        "historical_databases_unchanged": all(
            sha(Path(f["database_path"]).read_bytes()) == f["database_sha256"]
            for f in fixtures
            if not f["synthetic"]
        ),
        "summary": summary,
        "all_offset_and_budget_checks_passed": True,
        "production_changed": False,
    }
    dump("manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    for r in rows:
        print(r["case_id"], r["arm"], r["context_complete"], r["selected_chars"])


if __name__ == "__main__":
    main()
