"""Freeze fictional confirmation cases before diagnostic model results exist."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GROUPS = [
    (
        "archive",
        "The fictional Orin Archive opened to visitors on 14 May 2008. Its catalogue was digitized in 2016.",
        [
            (
                "supports",
                "The Orin Archive opened to visitors on 14 May 2008.",
                "Exact opening date is explicit.",
            ),
            (
                "contradicts",
                "The Orin Archive opened to visitors in 2016.",
                "2016 is digitization; opening is explicitly 2008.",
            ),
            (
                "not_established",
                "The Orin Archive opened to visitors in 2008 and contains 400 manuscripts.",
                "Opening year is supported; manuscript count is absent.",
            ),
        ],
    ),
    (
        "sensor",
        "In the fictional Vela trial, sensor P recorded 18 degrees Celsius and sensor Q recorded 23 degrees Celsius at noon on 2 June 2024.",
        [
            (
                "supports",
                "Sensor P recorded a lower temperature than sensor Q at noon on 2 June 2024 in the Vela trial.",
                "18 is lower than23 for the same time and trial.",
            ),
            (
                "contradicts",
                "Sensor P recorded a higher temperature than sensor Q at noon on 2 June 2024 in the Vela trial.",
                "18 is lower, not higher, than23.",
            ),
            (
                "not_established",
                "Sensor P recorded a lower temperature than sensor Q at noon on 3 June 2024 in the Vela trial.",
                "The quotation covers2June, not3June; no fact for the claimed day is established.",
            ),
        ],
    ),
    (
        "permit",
        "For the fictional Leto exhibition, visitors aged 16 or older may enter without a guardian. Visitors younger than 16 must enter with a guardian.",
        [
            (
                "supports",
                "A 16-year-old visitor may enter the Leto exhibition without a guardian.",
                "16 meets the stated16orolder boundary.",
            ),
            (
                "contradicts",
                "A 15-year-old visitor may enter the Leto exhibition without a guardian.",
                "Youngerthan16 requires a guardian.",
            ),
            (
                "not_established",
                "A 16-year-old visitor may enter the Leto exhibition without a guardian and pays no admission fee.",
                "Guardian eligibility is supported but fees are not described.",
            ),
        ],
    ),
    (
        "package",
        "The fictional Noma package has a mass of 8 kilograms and a width of 24 centimetres. The label does not specify its height.",
        [
            (
                "supports",
                "The Noma package has a mass of 8 kilograms and a width of 24 centimetres.",
                "Both properties and units match.",
            ),
            (
                "contradicts",
                "The Noma package has a mass of 24 kilograms.",
                "Mass is8;24 refers to a different property and unit.",
            ),
            (
                "not_established",
                "The Noma package is 24 centimetres wide and 12 centimetres high.",
                "Width is supported; height is explicitly unspecified.",
            ),
        ],
    ),
]


def main():
    dest = ROOT / "confirmation-cases.json"
    if dest.exists():
        raise SystemExit("Confirmation cases already frozen")
    rows = []
    for family, quote, variants in GROUPS:
        for relation, claim, rationale in variants + [
            (
                "withheld",
                variants[0][1],
                "Only a document heading is provided; it establishes none of the tested properties.",
            )
        ]:
            rows.append(
                {
                    "id": family + "_" + relation,
                    "family": family,
                    "condition": relation,
                    "claim": claim,
                    "expected": "not_established"
                    if relation == "withheld"
                    else relation,
                    "rationale": rationale,
                    "source": {
                        "url": "https://example.invalid/" + family,
                        "title": "Fictional diagnostic record " + family,
                    },
                    "evidence": [
                        {
                            "id": "E1",
                            "quote": "Document index"
                            if relation == "withheld"
                            else quote,
                        }
                    ],
                    "synthetic": True,
                }
            )
    dest.write_text(json.dumps(rows, indent=2) + "\n")
    (ROOT / "confirmation-protocol.json").write_text(
        json.dumps(
            {
                "purpose": "Untouched confirmation set for a promising format change, distinct from factual world knowledge. All facts fictional and clearly identified.",
                "cases_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
                "prepared_before_diagnostic_live_results": True,
                "planned_use": "Only if a candidate improves first-attempt grounded decisions by at least3of24 diagnostic trials without increasing unsupported decisive verdicts, and independent semantic review agrees. Compare baseline and selected candidate on all16cases with3repetitions each,96calls total, no repair.",
                "limitations": [
                    "Synthetic conditional evidence reasoning, not source truth or full production acceptance.",
                    "Related variants of four families, not16independent source domains.",
                    "If no candidate qualifies, keep this set unused and report no confirmed intervention.",
                ],
            },
            indent=2,
        )
        + "\n"
    )
    print("Frozen16fictional confirmation cases")


if __name__ == "__main__":
    main()
