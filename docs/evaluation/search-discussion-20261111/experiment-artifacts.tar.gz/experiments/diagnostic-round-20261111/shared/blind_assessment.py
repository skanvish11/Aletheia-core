"""Create anonymized semantic-review items only after all diagnostic calls finish."""

import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    read = lambda p: json.loads(p.read_text())
    rows = read(ROOT / "assessment/results.json")
    raw = read(ROOT / "assessment/provider-records.json")
    manifest = read(ROOT / "assessment/manifest.json")
    assert manifest.get("finished_at") and len(rows) == len(raw) == 96
    cases = {c["id"]: c for c in read(ROOT / "shared/cases.json")}
    raw_map = {r["trial"]: r for r in raw}
    random.Random(42771).shuffle(rows)
    items, mapping = [], {}
    for i, row in enumerate(rows, 1):
        item_id = f"P{i:03}"
        c = cases[row["case_id"]]
        output = raw_map[row["trial"]].get("output")
        canonical = (
            {k: output.get(k) for k in ["relation", "explanation", "evidence_ids"]}
            if isinstance(output, dict)
            else output
        )
        items.append(
            {
                "id": item_id,
                "claim": c["claim"],
                "source": c["source"],
                "evidence": c["evidence"],
                "expected": c["expected"],
                "output": canonical,
            }
        )
        mapping[item_id] = row["trial"]
    (ROOT / "assessment/blinded-items.json").write_text(
        json.dumps(items, indent=2, ensure_ascii=False) + "\n"
    )
    (ROOT / "assessment/blind-key.json").write_text(
        json.dumps(mapping, indent=2) + "\n"
    )
    print("Prepared 96 anonymized review items")


if __name__ == "__main__":
    main()
