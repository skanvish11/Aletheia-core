"""Record cross-workstream findings without changing production or frozen results."""

import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    assessment = read("assessment/review.json")
    selection = read("selection/results.json")
    validation = read("validation/results.json")
    normalization = read("validation/normalization-results.json")
    graded = {r["trial"]: r for r in assessment["trials"]}
    after = Counter()
    for row in normalization["results"]:
        grade = graded[row["trial"]]
        normal = row["normalized"]
        assert row["label_unchanged"]
        correct = (
            row["normalized_contract_result"] == "accepted" and row["correct_label"]
        )
        if normal["relation"] == "not_established":
            grounded = normal["explanation"] is None and normal["evidence_ids"] == []
        else:
            grounded = grade["raw_semantically_correct"]
        if correct and grounded:
            after[row["arm"]] += 1
    selection_counts = {}
    for arm in {r["arm"] for r in selection}:
        selection_counts[arm] = {}
        for synthetic in [False, True]:
            rr = [
                r
                for r in selection
                if r["arm"] == arm
                and r["synthetic"] == synthetic
                and r["expected"] == "evidence_present"
            ]
            selection_counts[arm]["synthetic" if synthetic else "saved_pilot"] = {
                "covered_with_context": sum(r["context_complete"] is True for r in rr),
                "total": len(rr),
            }
    production_hashes = read("shared/production-source-hashes.json")
    assert all(
        hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
        for path, digest in production_hashes.items()
    )
    repo = ROOT.parents[1] / "aletheia-phase-one"
    assert (
        subprocess.check_output(
            ["git", "-C", str(repo), "status", "--porcelain"], text=True
        )
        == read("shared/manifest.json")["production_status"]
        == ""
    )
    assert len(validation["results"]) == 30
    assert all(r["matches_predeclared_behavior"] for r in validation["results"])
    assert not assessment["eligible_schema_arms_for_confirmation"]
    result = {
        "status": "Initial parallel diagnostic batch complete; production unchanged. No unmodified schema arm passed the predefined grounded-answer gate; reserved synthetic confirmation set was not run.",
        "selection": {
            "coverage": selection_counts,
            "established": "The current selector drops an oversized span containing Python's release date. Bounded derived spans restore the decisive proposition and subject context under the same12000-character budget.",
            "integration": "Derived Python snapshot/citations passed actual production admission and reconstruction; stale original snapshot ID was rejected. Source sufficiency remains a separate gate.",
            "limitations": "Known example and synthetic coverage tests, not end-to-end model acceptance. Ranking still fails dense distractors at the120-span limit. Table benefit was isolated only in an additional offline controlled test; original structural arm had a bundle-admission confound.",
        },
        "assessment": {
            "summary": assessment["summary"],
            "interpretation": "Response order materially changed labels in this diagnostic screen. Removing the cap alone did not improve label accuracy. Explanation-first produced more correct labels but exposed abstention-shape rejection and retained explanation-grounding errors. Neither format change alone meets the original complete-answer success criterion.",
            "confirmation_run": False,
            "confirmation_reason": "No unmodified schema arm passes the predeclared grounded-and-accepted improvement gate. Post-hoc normalization is a new candidate, not a retroactive gate success.",
        },
        "validation": {
            "boundary_probes": 30,
            "all_matched_declared_behavior": True,
            "budget_schedules": len(validation["budgets"]),
            "scripted_repair_paths": len(validation["repairs"]),
            "interpretation": "Tested structural/citation/combination checks behave as documented. A fabricated semantic assessment can still pass structural gates and produce a provisional true finding; final semantic checking was not exercised. This does not justify weakening structural checks.",
        },
        "post_hoc_normalization": {
            "published_grounded_correct_after": dict(after),
            "denominator_per_arm": 24,
            "label_and_shape_counts": normalization["summary"],
            "limitations": "Offline replay of observed outputs; no independent live confirmation. Only abstention explanations/citations are cleared; relations and decisive outputs are unchanged. Raw bad explanations remain in audit. Clearing them is a publication filter, not a repair of model reasoning, and removes the user's missing-evidence explanation.",
        },
        "next_decision": "Retain bounded splitting as a candidate for the demonstrated selector defect. Treat explanation-before-decision plus safe abstention handling as a follow-up hypothesis, requiring a newly frozen protocol and confirmation. Do not deploy the output-order change alone or claim a complete pipeline fix.",
        "limitations": [
            "Assessment uses eight reused cases, three repetitions, one hosted model configuration, and no statistical superiority claim.",
            "Blind semantic review counts one source-versus-claim wording issue conservatively; relaxing it does not make an original schema arm pass the gate.",
            "Selection expectations were independently reviewed after execution but before that reviewer saw the results.",
            "Current production full interpretation, source assessment, synthesis and explanation validation were not all executed end-to-end in this batch.",
        ],
        "integrity": {
            "production_source_files_unchanged": len(production_hashes),
            "production_git_clean": True,
            "model_requests": 96,
            "model_retries": 0,
            "assessment_frozen_artifacts_verified": True,
            "diagnostic_and_confirmation_labels_independently_reviewed": True,
        },
    }
    confirmation_path = ROOT / "confirmation/review.json"
    if confirmation_path.exists():
        confirmation = read("confirmation/review.json")
        result["status"] = (
            "Initial parallel diagnostic batch and separately registered confirmation completed; production unchanged. Original schema-only gate failure is preserved; combined intervention assessed prospectively on untouched fictional cases."
        )
        result["confirmation"] = confirmation
        result["assessment"]["confirmation_reason"] = (
            "No original schema-only arm qualified. A new compound hypothesis was separately registered after offline normalization review; its protocol prospectively superseded the earlier conditional-use restriction without changing the old protocol, labels or results."
        )
        result["assessment"]["confirmation_run"] = (
            "separate combined-intervention follow-up, not original schema-gate confirmation"
        )
        result["integrity"]["model_requests"] = 192
        result["next_decision"] = (
            "Use the confirmation gate and per-category results to decide whether the combined assessor/formatter warrants a full production-component replay. Retain bounded splitting for the demonstrated selector defect. Neither diagnostic nor synthetic confirmation establishes production readiness or source-authority adequacy."
        )
    (ROOT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "selection": selection_counts,
                "post_hoc_grounded": dict(after),
                "production_clean": True,
                "confirmation_run": confirmation_path.exists(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
