"""Offline mock-provider checks; never loads credentials or opens a connection."""

import asyncio
import json
import time

import run_assessment as run


class MockResponse(run.base.httpx.AsyncBaseTransport):
    def __init__(self, content):
        self.content = content
        self.calls = 0

    async def handle_async_request(self, request):
        self.calls += 1
        return run.base.httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "finish_reason": "stop",
                        "message": {"role": "assistant", "content": self.content},
                    }
                ],
                "usage": {
                    "prompt_tokens": 1,
                    "completion_tokens": 1,
                    "total_tokens": 2,
                },
            },
            request=request,
        )


async def main():
    data = {
        "claim": "Fictional unit Q has value 7.",
        "source": {"url": "https://example.test", "title": "Synthetic fixture"},
        "evidence": [{"id": "E1", "quote": "Fictional unit Q has value 7."}],
    }
    settings = run.runtime.ProviderSettings.model_validate(
        {
            **run.read(run.PREVIOUS / "manifest.json")["settings"],
            "nebius_api_key": "offline-wire-test-secret",
            "tavily_api_key": None,
        }
    )
    checks = []
    for arm in run.ARMS:
        ordered = {
            key: {
                "relation": "supports",
                "explanation": "The evidence matches the claim.",
                "evidence_ids": ["E1"],
            }[key]
            for key in run.SCHEMAS[arm].model_fields
        }
        transport = run.AuditedTransport()
        await transport.inner.aclose()
        mock = MockResponse(json.dumps(ordered))
        transport.inner = mock
        transport.trial = "offline/" + arm
        transport.expected_payload = run.payload(arm, data)
        async with run.runtime.NebiusProvider(
            settings, transport=transport
        ) as provider:
            result = await provider.generate(
                instructions=run.INSTRUCTIONS,
                input_text=json.dumps(data, ensure_ascii=False),
                response_type=run.SCHEMAS[arm],
                budget=run.runtime.CallBudget(1, 0, 0, time.monotonic() + 5),
            )
        assert result.value.model_dump() == ordered
        assert mock.calls == len(transport.records) == 1
        assert transport.records[0]["response_field_order"] == list(ordered)
        assert "offline-wire-test-secret" not in json.dumps(transport.records)
        assert transport.records[0]["request_payload"] == run.payload(arm, data)
        checks.append(
            {
                "arm": arm,
                "actual_adapter_payload_matches_frozen": True,
                "response_order_preserved": True,
                "one_attempt": True,
                "credential_not_recorded": True,
            }
        )
    for arm, accepted in [
        ("relation_first_300", False),
        ("relation_first_uncapped", True),
    ]:
        transport = run.AuditedTransport()
        await transport.inner.aclose()
        mock = MockResponse(
            json.dumps(
                {
                    "relation": "supports",
                    "explanation": "x" * 301,
                    "evidence_ids": ["E1"],
                }
            )
        )
        transport.inner = mock
        transport.trial = "offline/cap-sensitivity/" + arm
        transport.expected_payload = run.payload(arm, data)
        async with run.runtime.NebiusProvider(
            settings, transport=transport
        ) as provider:
            try:
                await provider.generate(
                    instructions=run.INSTRUCTIONS,
                    input_text=json.dumps(data, ensure_ascii=False),
                    response_type=run.SCHEMAS[arm],
                    budget=run.runtime.CallBudget(1, 0, 0, time.monotonic() + 5),
                )
            except run.runtime.ProviderError as exc:
                assert not accepted
                assert exc.validation_code == "response_schema"
            else:
                assert accepted
        assert mock.calls == len(transport.records) == 1
        checks.append(
            {
                "arm": arm,
                "301_character_provider_response_accepted": accepted,
                "one_attempt": True,
            }
        )
    run.freeze(
        run.ROOT / "wire-checks.json",
        {"offline": True, "network_calls": 0, "checks": checks},
    )
    print(
        json.dumps(
            {
                "offline_mock_wire_checks": len(checks),
                "passed": True,
                "network_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    asyncio.run(main())
