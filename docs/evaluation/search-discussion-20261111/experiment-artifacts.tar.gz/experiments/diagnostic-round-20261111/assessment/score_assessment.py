"""Join blinded semantic review to frozen first-attempt output-contract trials."""

import json
import statistics
from collections import Counter
from pathlib import Path

import run_assessment as run

ROOT = Path(__file__).resolve().parent


def main():
    read = lambda name: run.read(ROOT / name)
    rows, records = read("results.json"), read("provider-records.json")
    manifest = read("manifest.json")
    cases = {c["id"]: c for c in run.read(run.SHARED / "cases.json")}
    review, key = read("blind-semantic-review.json"), read("blind-key.json")
    assert review["reviewed_count"] == len(rows) == len(records) == 96
    grades = {key[item["id"]]: item for item in review["items"]}
    assert len(grades) == len({r["trial"] for r in rows}) == 96
    for name, digest in manifest["hashes"].items():
        assert run.sha((ROOT / name).read_bytes()) == digest
    for name, digest in manifest["shared_hashes"].items():
        assert run.sha((run.SHARED / name).read_bytes()) == digest
    for name, digest in manifest["imported_hashes"].items():
        assert run.sha(Path(name).read_bytes()) == digest
    assert (
        manifest["production_before"]
        == run.production_state()
        == manifest["production_after"]
    )
    assert all(r["http_status"] == 200 and r["request_matches_frozen"] for r in records)
    assert all(r["network_calls"] == 1 for r in rows)
    requests = read("requests.json")
    raw = {r["trial"]: r for r in records}
    scored = []
    for row in rows:
        record, grade = raw[row["trial"]], grades[row["trial"]]
        assert (
            record["request_payload"]
            == requests["payloads"][row["case_id"]][row["arm"]]
        )
        assert run.sha(record["request_body"].encode()) == record["request_body_sha256"]
        body = json.loads(record["request_payload"]["messages"][1]["content"])
        assert set(body) == {"claim", "source", "evidence"}
        expected = cases[row["case_id"]]["expected"]
        observed = record["output"]["relation"]
        assert grade["relation_correct"] == (expected == observed)
        if row.get("output"):
            assert row["output"] == record["output"]
        grounded = (
            grade["explanation_grounded"]
            and grade["explanation_matches_relation"]
            and not grade["unsupported_addition"]
        )
        accepted = row["status"] == "accepted"
        scored.append(
            {
                "trial": row["trial"],
                "case_id": row["case_id"],
                "condition": cases[row["case_id"]]["condition"],
                "arm": row["arm"],
                "correct_label": expected == observed,
                "accepted": accepted,
                "raw_semantically_correct": expected == observed and grounded,
                "grounded_accepted_correct": accepted
                and expected == observed
                and grounded,
                "unsupported_decisive_verdict": expected == "not_established"
                and observed != "not_established",
                "accepted_unsupported_decisive_verdict": accepted
                and expected == "not_established"
                and observed != "not_established",
                "unsupported_addition": grade["unsupported_addition"],
                "presentation_complete": grade["presentation_complete"],
                "explanation_chars": len(record["output"].get("explanation") or ""),
                "ordered_as_requested": record["response_field_order"]
                == record["request_schema_field_order"],
                "blind_review_id": grade["id"],
                "notes": grade["notes"],
            }
        )
    summary = {}
    for arm in run.ARMS:
        ss, rr = (
            [s for s in scored if s["arm"] == arm],
            [r for r in rows if r["arm"] == arm],
        )
        summary[arm] = {
            "trials": len(ss),
            "correct_labels": sum(s["correct_label"] for s in ss),
            "accepted_correct_labels": sum(
                s["accepted"] and s["correct_label"] for s in ss
            ),
            "raw_semantically_correct": sum(s["raw_semantically_correct"] for s in ss),
            "grounded_accepted_correct": sum(
                s["grounded_accepted_correct"] for s in ss
            ),
            "structurally_rejected": sum(not s["accepted"] for s in ss),
            "unsupported_decisive_verdicts": sum(
                s["unsupported_decisive_verdict"] for s in ss
            ),
            "accepted_unsupported_decisive_verdicts": sum(
                s["accepted_unsupported_decisive_verdict"] for s in ss
            ),
            "unsupported_additions_all_proposals": sum(
                s["unsupported_addition"] for s in ss
            ),
            "accepted_unsupported_additions": sum(
                s["unsupported_addition"] and s["accepted"] for s in ss
            ),
            "incomplete_presentations": sum(not s["presentation_complete"] for s in ss),
            "exactly_300_chars": sum(s["explanation_chars"] == 300 for s in ss),
            "correct_labels_by_condition": dict(
                Counter(s["condition"] for s in ss if s["correct_label"])
            ),
            "response_order_matches_request": sum(
                s["ordered_as_requested"] for s in ss
            ),
            "total_tokens": sum(r["usage"]["total_tokens"] for r in rr),
            "mean_trial_seconds": statistics.mean(r["elapsed_seconds"] for r in rr),
        }
    baseline = summary["relation_first_300"]
    eligible = [
        arm
        for arm, s in summary.items()
        if arm != "relation_first_300"
        and s["grounded_accepted_correct"] >= baseline["grounded_accepted_correct"] + 3
        and s["unsupported_decisive_verdicts"]
        <= baseline["unsupported_decisive_verdicts"]
    ]
    report = {
        "summary": summary,
        "eligible_schema_arms_for_confirmation": eligible,
        "gate": "Predeclared: at least3additional grounded accepted correct answers per24trials without increasing unsupported decisive verdicts. Raw labels alone do not pass the gate.",
        "review_method": "Agent reviewed all96 shuffled outputs with case/evidence/expected labels but without arm IDs, original output field order, structural status or trial IDs; root joined grades afterward. Source-attribution borderline P022 is explicitly noted by reviewer.",
        "integrity": {
            "http_200_calls": 96,
            "calls_per_trial": 1,
            "actual_request_matches_frozen": True,
            "only_planned_schema_factors_varied": True,
            "no_expected_label_input_leak": True,
            "provider_output_equals_saved_output": True,
            "frozen_hashes_match": True,
            "production_unchanged": True,
        },
        "limitations": read("protocol.json")["limitations"],
        "trials": scored,
    }
    run.checkpoint(ROOT / "review.json", report)
    print(json.dumps({"summary": summary, "eligible": eligible}, indent=2))


if __name__ == "__main__":
    main()
