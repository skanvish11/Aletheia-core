"""First-attempt-only 2x2 output-contract diagnostic using a frozen adapter."""

import argparse
import asyncio
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated, Literal

ROOT = Path(__file__).resolve().parent
ROUND = ROOT.parent
SHARED = ROUND / "shared"
EXPERIMENTS = ROUND.parent
WORKSPACE = EXPERIMENTS.parent
PREVIOUS = EXPERIMENTS / "fixed-evidence-decision-20261110"
spec = importlib.util.spec_from_file_location(
    "frozen_decision", PREVIOUS / "experiment.py"
)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
base, runtime = prior.base, prior.prior
from aletheia.tasks import BOUNDARY, TaskValidationError
from pydantic import ConfigDict, Field, ValidationError, create_model

MODEL = "nvidia/Nemotron-3_5-Lightning"
CAP = 96
ARMS = {
    "relation_first_300": (False, True),
    "explanation_first_300": (True, True),
    "relation_first_uncapped": (False, False),
    "explanation_first_uncapped": (True, False),
}
CASE_IDS = [
    "mars_contradicts",
    "web_contradicts",
    "aes_supports",
    "http_supports",
    "mars_not_established",
    "aes_not_established",
    "mars_withheld",
    "web_withheld",
]
INSTRUCTIONS = BOUNDARY + "\n" + prior.COMPARISON_PROMPT


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def serialized(value):
    return json.dumps(value, indent=2, ensure_ascii=False) + "\n"


def freeze(path, value):
    text = serialized(value)
    if path.exists():
        if path.read_text() != text:
            raise SystemExit(f"Frozen artifact differs: {path.name}")
    else:
        with path.open("x") as handle:
            handle.write(text)


def checkpoint(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(serialized(value))
    temporary.replace(path)


def response_model(explanation_first, bounded):
    fields = {
        "relation": (Literal["supports", "contradicts", "not_established"], ...),
        "explanation": (
            Annotated[str | None, Field(max_length=300)] if bounded else str | None,
            ...,
        ),
        "evidence_ids": (Annotated[list[str], Field(max_length=4)], ...),
    }
    if explanation_first:
        fields = {k: fields[k] for k in ["explanation", "relation", "evidence_ids"]}
    return create_model(
        "Explanation",
        __config__=ConfigDict(extra="forbid", strict=True, title="Explanation"),
        **fields,
    )


SCHEMAS = {arm: response_model(*options) for arm, options in ARMS.items()}


def payload(arm, data):
    schema = SCHEMAS[arm].model_json_schema()
    return {
        "model": MODEL,
        "messages": [
            {
                "role": "system",
                "content": INSTRUCTIONS
                + "\nReturn only JSON matching this schema:\n"
                + json.dumps(schema),
            },
            {"role": "user", "content": json.dumps(data, ensure_ascii=False)},
        ],
        "response_format": {
            "type": "json_schema",
            "json_schema": {
                "name": "aletheia_response",
                "schema": schema,
                "strict": True,
            },
        },
        "max_tokens": 4096,
        "stream": False,
        "store": False,
        "chat_template_kwargs": {"enable_thinking": False},
    }


def production_state():
    repo = WORKSPACE / "aletheia-phase-one"
    revision = subprocess.check_output(
        ["git", "-C", str(repo), "rev-parse", "HEAD"], text=True
    ).strip()
    status = subprocess.check_output(
        ["git", "-C", str(repo), "status", "--short"], text=True
    )
    paths = (
        subprocess.check_output(["git", "-C", str(repo), "ls-files", "-z", "src"])
        .decode()
        .split("\0")
    )
    hashes = {p: sha((repo / p).read_bytes()) for p in paths if p}
    return {"revision": revision, "status": status, "source_hashes": hashes}


def offline_checks(cases):
    baseline = runtime.Explanation.model_json_schema()
    assert SCHEMAS["relation_first_300"].model_json_schema() == baseline
    normalized = []
    for arm, model in SCHEMAS.items():
        schema = model.model_json_schema()
        explanation_first, bounded = ARMS[arm]
        expected_order = (
            ["explanation", "relation", "evidence_ids"]
            if explanation_first
            else ["relation", "explanation", "evidence_ids"]
        )
        assert list(schema["properties"]) == schema["required"] == expected_order
        clean = json.loads(json.dumps(schema))
        for entry in clean["properties"]["explanation"]["anyOf"]:
            if entry.get("type") == "string":
                assert entry.get("maxLength") == (300 if bounded else None)
                entry.pop("maxLength", None)
        clean["required"].sort()
        normalized.append(clean)
        valid = model(
            relation="supports",
            explanation="The quoted fact matches the assertion.",
            evidence_ids=["E1"],
        )
        runtime.validate_explanation(valid, [{"id": "E1"}])
        try:
            model(relation="supports", explanation="x" * 301, evidence_ids=["E1"])
        except ValidationError:
            assert bounded
        else:
            assert not bounded
        for wrong in [
            {"relation": "supports", "explanation": "Text.", "evidence_ids": []},
            {"relation": "contradicts", "explanation": "Text.", "evidence_ids": ["E9"]},
            {"relation": "not_established", "explanation": "Text.", "evidence_ids": []},
        ]:
            try:
                runtime.validate_explanation(model(**wrong), [{"id": "E1"}])
            except TaskValidationError:
                pass
            else:
                raise AssertionError("Invalid output reference accepted")
    assert all(s == normalized[0] for s in normalized)
    for case in cases:
        data = {key: case[key] for key in ["claim", "source", "evidence"]}
        bodies = [payload(arm, data) for arm in ARMS]
        assert len({body["messages"][1]["content"] for body in bodies}) == 1
        assert set(json.loads(bodies[0]["messages"][1]["content"])) == {
            "claim",
            "source",
            "evidence",
        }
    return {
        "baseline_schema_exact_match": True,
        "only_schema_order_and_character_cap_vary": True,
        "301_character_sensitivity_pass": True,
        "invalid_reference_and_abstention_checks_pass": True,
        "identical_evidence_inputs": True,
    }


def prepare():
    cases = read(SHARED / "cases.json")
    assert [c["id"] for c in cases] == CASE_IDS
    shared_manifest = read(SHARED / "manifest.json")
    assert sha((SHARED / "cases.json").read_bytes()) == shared_manifest["cases_sha256"]
    old_cases = {
        c["id"]: c
        for c in read(EXPERIMENTS / "fresh-model-comparison-20261110/cases.json")
    }
    assert all(c == old_cases[c["id"]] for c in cases)
    old_requests = read(PREVIOUS / "requests.json")
    assert prior.COMPARISON_PROMPT == old_requests["prompts"]["explicit_comparison"]
    checks = offline_checks(cases)
    inputs = {
        c["id"]: {key: c[key] for key in ["claim", "source", "evidence"]} for c in cases
    }
    schedule = []
    for repetition in range(1, 4):
        for i, case in enumerate(cases):
            arms = list(ARMS)
            shift = (i + repetition - 1) % 4
            arms = arms[shift:] + arms[:shift]
            schedule.extend(
                {
                    "trial": f"{case['id']}/{repetition}/{arm}",
                    "case_id": case["id"],
                    "repetition": repetition,
                    "arm": arm,
                }
                for arm in arms
            )
    protocol = {
        "purpose": "Isolate schema field order and explanation character cap in quotation-only assessment.",
        "source_revision": shared_manifest["production_revision"],
        "model": MODEL,
        "arms": {
            arm: {
                "first_field": "explanation" if order else "relation",
                "explanation_max_characters": 300 if bounded else None,
            }
            for arm, (order, bounded) in ARMS.items()
        },
        "case_ids": CASE_IDS,
        "trials": 96,
        "repetitions": 3,
        "call_cap": CAP,
        "first_attempt_only": True,
        "repair_attempts": 0,
        "transport_retries": 0,
        "matching": "Same explicit comparison prompt plus frozen task BOUNDARY, input, schema title, other field constraints, model/settings, adapter, output-token limit. Only property/required-list order and explanation maxLength differ.",
        "sampling": "Provider defaults, no temperature or seed override.",
        "schedule": "Each arm appears in each within-case position exactly six times across the whole schedule; sequential independent requests.",
        "primary_metrics": [
            "Correct first-attempt relation",
            "Correct structurally valid decision",
            "Grounded correct answer",
            "Unsupported factual additions and unjustified decisive verdicts separately",
            "Presentation completeness and at-cap endings separately",
        ],
        "integrity_metrics": [
            "Exact planned versus actual request payload",
            "Actual response field order",
            "Token use and finish reason",
            "No label/rationale input leakage",
            "No production source changes",
        ],
        "decision_rule": "A promising arm must improve targeted grounded decisions without increasing unsupported decisive verdicts on these cases; changes limited to presentation are not decision improvements. Diagnostic results alone do not authorize production adoption.",
        "limitations": [
            "Eight reused diagnostic cases, not held-out generalization evidence.",
            "Three repetitions per condition are dependent samples from related claims; no statistical superiority claim.",
            "Changing field order may not change provider generation order; actual wire response order must be checked.",
            "No generation-time character cap retains the common 4096-token output ceiling and existing concise-sentence instruction.",
            "Abstention still requires null explanation and empty citations in all arms; that is not varied here.",
            "This is an isolated assessor test, not a production source-sufficiency or final-verdict evaluation.",
        ],
        "cases_sha256": sha((SHARED / "cases.json").read_bytes()),
        "prompt_sha256": sha(INSTRUCTIONS.encode()),
    }
    requests = {
        "instructions_before_adapter_schema_suffix": INSTRUCTIONS,
        "schema_by_arm": {
            arm: model.model_json_schema() for arm, model in SCHEMAS.items()
        },
        "inputs": inputs,
        "payloads": {
            case_id: {arm: payload(arm, data) for arm in ARMS}
            for case_id, data in inputs.items()
        },
        "schedule": schedule,
    }
    for name, value in [
        ("protocol.json", protocol),
        ("requests.json", requests),
        ("offline-checks.json", checks),
    ]:
        freeze(ROOT / name, value)
    return cases, requests


def check_label_gate():
    gate = read(SHARED / "label-review.json")
    assert gate["approved"] is True
    assert gate["cases_sha256"] == sha((SHARED / "cases.json").read_bytes())
    reviews = gate["reviews"]
    assert len(reviews) == len(CASE_IDS)
    assert {r["case_id"] for r in reviews} == set(CASE_IDS)
    assert all(r["agrees"] is True for r in reviews)
    return gate


class AuditedTransport(base.httpx.AsyncBaseTransport):
    def __init__(self):
        self.inner = base.httpx.AsyncHTTPTransport()
        self.records = []
        self.trial = None
        self.expected_payload = None

    async def handle_async_request(self, request):
        if len(self.records) >= CAP:
            raise RuntimeError("Fixed 96-call cap reached")
        body = request.content.decode()
        actual = json.loads(body)
        assert actual == self.expected_payload, (
            "Actual public request differs from frozen payload"
        )
        schema = actual["response_format"]["json_schema"]["schema"]
        assert list(schema["properties"]) == schema["required"]
        record = {
            "trial": self.trial,
            "http_status": None,
            "request_payload": actual,
            "request_body": body,
            "request_body_sha256": sha(body.encode()),
            "request_matches_frozen": True,
            "request_schema_field_order": list(schema["properties"]),
        }
        self.records.append(record)
        started = time.monotonic()
        try:
            response = await self.inner.handle_async_request(request)
            await response.aread()
            record["http_status"] = response.status_code
            if response.status_code == 200:
                try:
                    envelope = response.json()
                    record["usage"] = envelope.get("usage")
                    choice = envelope["choices"][0]
                    record["finish_reason"] = choice.get("finish_reason")
                    content = choice["message"].get("content") or ""
                    record["raw_output_text"] = content
                    record["output_chars"] = len(content)
                    try:
                        decoded = json.loads(content)
                        record["output"] = decoded
                        record["response_field_order"] = (
                            list(decoded) if isinstance(decoded, dict) else None
                        )
                    except (ValueError, TypeError):
                        record["non_json_output"] = True
                except (ValueError, KeyError, IndexError, TypeError):
                    record["response_envelope_invalid"] = True
            return response
        finally:
            record["elapsed_seconds"] = time.monotonic() - started

    async def aclose(self):
        await self.inner.aclose()


async def execute(args):
    if (ROOT / "results.json").exists() or (ROOT / "manifest.json").exists():
        raise SystemExit("Run exists; automatic rerun or overwrite prohibited.")
    cases, requests = prepare()
    if not args.live:
        print(
            json.dumps(
                {
                    "prepared": True,
                    "offline_checks_passed": True,
                    "planned_trials": CAP,
                    "model_calls_made": 0,
                }
            )
        )
        return
    check_label_gate()
    frozen_production = production_state()
    shared_manifest = read(SHARED / "manifest.json")
    assert frozen_production["revision"] == shared_manifest["production_revision"]
    assert frozen_production["status"] == shared_manifest["production_status"]
    loaded = runtime.ProviderSettings.from_environment(dotenv_path=args.dotenv)
    old_settings = read(PREVIOUS / "manifest.json")["settings"]
    settings = runtime.ProviderSettings.model_validate(
        {
            **loaded.model_dump(),
            **old_settings,
            "nebius_model": MODEL,
            "nebius_thinking": "disabled",
            "max_retries": 0,
            "max_output_tokens": 4096,
            "timeout_seconds": 45.0,
            "nebius_response_format": "json_schema",
        }
    )
    if not settings.nebius_api_key:
        raise SystemExit("Credential unavailable; no call made.")
    settings.validate_model_controls()
    imports = [
        PREVIOUS / "experiment.py",
        runtime.ROOT / "evidence_first.py",
        base.ROOT / "experiment.py",
    ]
    baseline = base.ROOT / "baseline/src/aletheia"
    imports.extend(sorted(baseline.rglob("*.py")))
    manifest = {
        "started_at": datetime.now(UTC).isoformat(),
        "settings": settings.model_dump(exclude={"nebius_api_key", "tavily_api_key"}),
        "temperature": "provider default",
        "seed": "not set",
        "python": sys.version,
        "production_before": frozen_production,
        "hashes": {
            name: sha((ROOT / name).read_bytes())
            for name in [
                "run_assessment.py",
                "protocol.json",
                "requests.json",
                "offline-checks.json",
            ]
        },
        "shared_hashes": {
            name: sha((SHARED / name).read_bytes())
            for name in ["cases.json", "manifest.json", "label-review.json"]
        },
        "imported_hashes": {str(p): sha(p.read_bytes()) for p in imports},
    }
    freeze(ROOT / "manifest.json", manifest)
    case_map = {c["id"]: c for c in cases}
    transport, rows = AuditedTransport(), []
    try:
        async with runtime.NebiusProvider(settings, transport=transport) as model:
            for item in requests["schedule"]:
                row = dict(item)
                row["model"] = MODEL
                row["events"] = []
                case = case_map[item["case_id"]]
                budget = runtime.CallBudget(1, 0, 0, time.monotonic() + 50)

                async def emit(event, data, row=row):
                    row["events"].append({"type": event, "payload": data})

                budget.observer = emit
                transport.trial = item["trial"]
                transport.expected_payload = requests["payloads"][item["case_id"]][
                    item["arm"]
                ]
                started, before = time.monotonic(), len(transport.records)
                usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
                try:
                    result = await model.generate(
                        instructions=INSTRUCTIONS,
                        input_text=json.dumps(
                            requests["inputs"][item["case_id"]], ensure_ascii=False
                        ),
                        response_type=SCHEMAS[item["arm"]],
                        budget=budget,
                    )
                    row["output"] = result.value.model_dump()
                    if result.usage:
                        usage = result.usage.model_dump()
                    runtime.validate_explanation(result.value, case["evidence"])
                    row["status"] = "accepted"
                except TaskValidationError as exc:
                    row.update(status="invalid_task_output", validation_code=exc.code)
                except runtime.ProviderError as exc:
                    row.update(
                        status=exc.code.value, validation_code=exc.validation_code
                    )
                    if exc.token_usage:
                        usage = exc.token_usage
                row.update(
                    usage=usage,
                    elapsed_seconds=time.monotonic() - started,
                    network_calls=len(transport.records) - before,
                    budget_attempts=[asdict(a) for a in budget.attempts],
                )
                assert row["network_calls"] <= 1
                rows.append(row)
                checkpoint(ROOT / "results.json", rows)
                checkpoint(ROOT / "provider-records.json", transport.records)
                print(
                    json.dumps(
                        {k: row[k] for k in ["trial", "status", "network_calls"]}
                    ),
                    flush=True,
                )
                if row["status"] in {
                    "authentication",
                    "quota_exceeded",
                    "configuration",
                    "invalid_request",
                    "network",
                    "unavailable",
                    "rate_limited",
                }:
                    manifest["stopped_early"] = row["status"]
                    break
    finally:
        manifest.update(
            finished_at=datetime.now(UTC).isoformat(),
            trials_recorded=len(rows),
            network_attempts=len(transport.records),
            production_after=production_state(),
        )
        manifest["production_unchanged"] = (
            manifest["production_before"] == manifest["production_after"]
        )
        manifest["all_recorded_requests_match_frozen"] = all(
            r["request_matches_frozen"] for r in transport.records
        )
        checkpoint(ROOT / "manifest.json", manifest)
        checkpoint(ROOT / "results.json", rows)
        checkpoint(ROOT / "provider-records.json", transport.records)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--prepare", action="store_true")
    group.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv", type=Path)
    asyncio.run(execute(parser.parse_args()))
