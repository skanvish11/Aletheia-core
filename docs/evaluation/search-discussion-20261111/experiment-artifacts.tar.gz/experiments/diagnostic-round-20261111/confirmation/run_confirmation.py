"""Separately registered confirmation of a post-diagnostic combined candidate."""

import argparse
import asyncio
import importlib.util
import json
import sys
import time
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROUND = ROOT.parent
SHARED = ROUND / "shared"
spec = importlib.util.spec_from_file_location(
    "assessment_runner", ROUND / "assessment/run_assessment.py"
)
assessment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(assessment)
runtime = assessment.runtime
ARMS = {"baseline": "relation_first_300", "candidate": "explanation_first_uncapped"}
CAP = 96


def normalized_proposal(proposal):
    """Clear only nonfactual abstention payload fields, never change the relation."""
    data = proposal.model_dump()
    if proposal.relation == "not_established":
        data.update(explanation=None, evidence_ids=[])
    return type(proposal).model_validate(data)


def validate(proposal, evidence):
    try:
        runtime.validate_explanation(proposal, evidence)
    except assessment.TaskValidationError as exc:
        return {"status": "invalid_task_output", "validation_code": exc.code}
    return {"status": "accepted"}


def prepare():
    cases = assessment.read(SHARED / "confirmation-cases.json")
    gate = assessment.read(SHARED / "confirmation-label-review.json")
    assert len(cases) == len({c["id"] for c in cases}) == 16
    assert gate["approved"] is True
    assert gate["cases_sha256"] == assessment.sha(
        (SHARED / "confirmation-cases.json").read_bytes()
    )
    assert len(gate["reviews"]) == len(cases)
    assert {r["case_id"] for r in gate["reviews"]} == {c["id"] for c in cases}
    assert all(r["agrees"] is True for r in gate["reviews"])
    assert all(c["synthetic"] is True for c in cases)
    inputs = {
        c["id"]: {k: c[k] for k in ["claim", "source", "evidence"]} for c in cases
    }
    original_ids = {c["id"] for c in assessment.read(SHARED / "cases.json")}
    assert not original_ids & set(inputs)
    checks = assessment.offline_checks(cases)
    for schema_arm in ARMS.values():
        schema = assessment.SCHEMAS[schema_arm]
        raw = schema(
            relation="not_established",
            explanation="The quoted evidence leaves a material fact unresolved.",
            evidence_ids=["E1"],
        )
        before = raw.model_dump()
        assert validate(raw, [{"id": "E1"}])["status"] == "invalid_task_output"
        clean = normalized_proposal(raw)
        assert raw.model_dump() == before
        assert clean.relation == raw.relation
        assert clean.explanation is None and clean.evidence_ids == []
        assert validate(clean, [{"id": "E1"}])["status"] == "accepted"
        decisive = schema(
            relation="supports", explanation="A factual assertion.", evidence_ids=["E9"]
        )
        assert normalized_proposal(decisive).model_dump() == decisive.model_dump()
        assert (
            validate(normalized_proposal(decisive), [{"id": "E1"}])["status"]
            == "invalid_task_output"
        )
    checks.update(
        abstention_only_normalization=True,
        original_proposal_preserved=True,
        decisive_invalid_citation_still_rejected=True,
    )
    schedule = []
    for rep in range(1, 4):
        for i, case in enumerate(cases):
            arms = list(ARMS)
            if (i + rep - 1) % 2:
                arms.reverse()
            schedule.extend(
                {
                    "trial": f"{case['id']}/{rep}/{arm}",
                    "case_id": case["id"],
                    "repetition": rep,
                    "arm": arm,
                }
                for arm in arms
            )
    protocol = {
        "purpose": "Confirm a newly selected combined assessor/formatter candidate on previously unused fictional fixtures.",
        "registration_status": "NEW post-diagnostic hypothesis registered before confirmation live calls. The original 2x2 gate failed and is not reclassified. Selection was motivated by exploratory normalization of the diagnostic outputs.",
        "prospective_supersession": "This new registration prospectively supersedes shared/confirmation-protocol.json's restriction that confirmation stays unused when no original schema arm qualifies. The original restriction and failed gate are preserved unchanged; the separately registered combined-intervention hypothesis is authorized by the user's plan to combine promising changes and check fresh cases. No confirmation outputs existed when this revision was registered.",
        "original_confirmation_protocol_sha256": assessment.sha(
            (SHARED / "confirmation-protocol.json").read_bytes()
        ),
        "followup_rationale_sha256": assessment.sha(
            (SHARED / "followup-rationale.json").read_bytes()
        ),
        "hypothesis": "Explanation-first uncapped generation plus deterministic formatting of typed abstentions can improve published grounded decisions without increasing unsupported decisive verdicts.",
        "arms": {
            "baseline": {
                "schema": "relation_first_300",
                "normalization": "none",
                "validation": "unchanged",
            },
            "candidate": {
                "schema": "explanation_first_uncapped",
                "normalization": "After successful typed parsing only, clear explanation and evidence_ids exactly when relation=not_established. Never change relation or decisive answers.",
                "validation": "unchanged, applied after normalization",
            },
        },
        "primary_metrics": [
            "Published grounded correct decisions across all planned trials",
            "Published unsupported decisive verdicts",
            "Invalid final outputs",
        ],
        "secondary_metrics": [
            "Raw relation correctness and explanation grounding",
            "Structural validity before normalization",
            "Presentation completeness",
            "Symmetric abstention normalization applied offline to BOTH arms",
            "Calls, tokens, latency",
        ],
        "controls": "Same unchanged explicit comparison prompt and task BOUNDARY, common schema title, original provider adapter/model/settings, per-case input, first attempt only and no repairs. All differences are explicitly the combined schema/formatter intervention.",
        "scope": "16 held-aside synthetic claim/evidence variants from four fictional source families. Three repetitions per arm,96 calls total. Previously reviewed labels are never sent to the model. These fixtures test semantic structure, not real-world retrieval or source authority.",
        "decision_rule": "Recommend further full-pipeline testing only if candidate has more published grounded correct decisions, no increase in published unsupported decisive verdicts, and no reduction in correct supported or contradicted control counts. Count all 48 trials per arm; no exclusions or retries. Report paired outcomes and secondary symmetric normalization; do not attribute any gain specifically to field order/cap if it can be explained by formatting alone.",
        "limitations": [
            "Candidate was selected after inspecting prior diagnostic outputs; confirmation is a new experiment, not evidence of original hypothesis success.",
            "Small, related fictional fixtures with three repeated samples do not establish production reliability or general model superiority.",
            "Normalization may hide an ungrounded raw explanation behind a correct abstention label; raw semantic defects must remain visible and separately scored.",
            "No production pipeline modification or full source-sufficiency/aggregation/synthesis evaluation.",
        ],
        "model": assessment.MODEL,
        "first_attempt_only": True,
        "repair_attempts": 0,
        "transport_retries": 0,
        "trials": CAP,
        "call_cap": CAP,
        "repetitions": 3,
        "sampling": "Provider defaults; no seed or temperature override.",
        "cases_sha256": assessment.sha(
            (SHARED / "confirmation-cases.json").read_bytes()
        ),
        "label_review_sha256": assessment.sha(
            (SHARED / "confirmation-label-review.json").read_bytes()
        ),
        "prompt_sha256": assessment.sha(assessment.INSTRUCTIONS.encode()),
    }
    requests = {
        "instructions_before_adapter_schema_suffix": assessment.INSTRUCTIONS,
        "schema_by_arm": {
            arm: assessment.SCHEMAS[schema].model_json_schema()
            for arm, schema in ARMS.items()
        },
        "inputs": inputs,
        "payloads": {
            cid: {arm: assessment.payload(schema, data) for arm, schema in ARMS.items()}
            for cid, data in inputs.items()
        },
        "schedule": schedule,
    }
    for cid in inputs:
        assert (
            requests["payloads"][cid]["baseline"]["messages"][1]
            == requests["payloads"][cid]["candidate"]["messages"][1]
        )
        assert set(
            json.loads(requests["payloads"][cid]["baseline"]["messages"][1]["content"])
        ) == {"claim", "source", "evidence"}
    for name, obj in [
        ("protocol.json", protocol),
        ("requests.json", requests),
        ("offline-checks.json", checks),
    ]:
        assessment.freeze(ROOT / name, obj)
    return cases, requests


async def execute(args):
    if (ROOT / "results.json").exists() or (ROOT / "manifest.json").exists():
        raise SystemExit("Confirmation run exists; no overwrite or automatic rerun.")
    cases, requests = prepare()
    if not args.live:
        print(
            json.dumps(
                {
                    "prepared": True,
                    "gate_approved": True,
                    "offline_checks_passed": True,
                    "planned_trials": CAP,
                    "model_calls_made": 0,
                }
            )
        )
        return
    production = assessment.production_state()
    shared_manifest = assessment.read(SHARED / "manifest.json")
    assert production["revision"] == shared_manifest["production_revision"]
    assert production["status"] == shared_manifest["production_status"]
    loaded = runtime.ProviderSettings.from_environment(dotenv_path=args.dotenv)
    old_settings = assessment.read(assessment.PREVIOUS / "manifest.json")["settings"]
    settings = runtime.ProviderSettings.model_validate(
        {
            **loaded.model_dump(),
            **old_settings,
            "nebius_model": assessment.MODEL,
            "nebius_thinking": "disabled",
            "max_retries": 0,
            "max_output_tokens": 4096,
            "timeout_seconds": 45.0,
            "nebius_response_format": "json_schema",
        }
    )
    if not settings.nebius_api_key:
        raise SystemExit("Credential unavailable; no call made.")
    settings.validate_model_controls()
    imported = [
        ROUND / "assessment/run_assessment.py",
        assessment.PREVIOUS / "experiment.py",
        runtime.ROOT / "evidence_first.py",
        assessment.base.ROOT / "experiment.py",
    ]
    imported.extend(
        sorted((assessment.base.ROOT / "baseline/src/aletheia").rglob("*.py"))
    )
    manifest = {
        "started_at": datetime.now(UTC).isoformat(),
        "settings": settings.model_dump(exclude={"nebius_api_key", "tavily_api_key"}),
        "temperature": "provider default",
        "seed": "not set",
        "python": sys.version,
        "production_before": production,
        "hashes": {
            name: assessment.sha((ROOT / name).read_bytes())
            for name in [
                "run_confirmation.py",
                "protocol.json",
                "requests.json",
                "offline-checks.json",
            ]
        },
        "shared_hashes": {
            name: assessment.sha((SHARED / name).read_bytes())
            for name in [
                "confirmation-cases.json",
                "confirmation-label-review.json",
                "confirmation-protocol.json",
                "followup-rationale.json",
                "manifest.json",
            ]
        },
        "imported_hashes": {str(p): assessment.sha(p.read_bytes()) for p in imported},
    }
    assessment.freeze(ROOT / "manifest.json", manifest)
    case_map = {c["id"]: c for c in cases}
    transport, rows = assessment.AuditedTransport(), []
    try:
        async with runtime.NebiusProvider(settings, transport=transport) as model:
            for item in requests["schedule"]:
                row = dict(item)
                row.update(model=assessment.MODEL, events=[])
                case = case_map[item["case_id"]]
                budget = runtime.CallBudget(1, 0, 0, time.monotonic() + 50)

                async def emit(event, data, row=row):
                    row["events"].append({"type": event, "payload": data})

                budget.observer = emit
                transport.trial = item["trial"]
                transport.expected_payload = requests["payloads"][item["case_id"]][
                    item["arm"]
                ]
                started, before = time.monotonic(), len(transport.records)
                usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
                try:
                    result = await model.generate(
                        instructions=assessment.INSTRUCTIONS,
                        input_text=json.dumps(
                            requests["inputs"][item["case_id"]], ensure_ascii=False
                        ),
                        response_type=assessment.SCHEMAS[ARMS[item["arm"]]],
                        budget=budget,
                    )
                    proposal = result.value
                    row["raw_proposal"] = proposal.model_dump()
                    row["raw_structural_validation"] = validate(
                        proposal, case["evidence"]
                    )
                    normalized = normalized_proposal(proposal)
                    row["symmetric_normalization_secondary"] = {
                        **validate(normalized, case["evidence"]),
                        "output": normalized.model_dump(),
                        "changed": normalized.model_dump() != proposal.model_dump(),
                    }
                    published = normalized if item["arm"] == "candidate" else proposal
                    row["normalization_applied"] = (
                        published.model_dump() != proposal.model_dump()
                    )
                    row.update(validate(published, case["evidence"]))
                    row["output"] = published.model_dump()
                    if result.usage:
                        usage = result.usage.model_dump()
                except runtime.ProviderError as exc:
                    row.update(
                        status=exc.code.value, validation_code=exc.validation_code
                    )
                    if exc.token_usage:
                        usage = exc.token_usage
                row.update(
                    usage=usage,
                    elapsed_seconds=time.monotonic() - started,
                    network_calls=len(transport.records) - before,
                    budget_attempts=[asdict(a) for a in budget.attempts],
                )
                assert row["network_calls"] <= 1
                rows.append(row)
                assessment.checkpoint(ROOT / "results.json", rows)
                assessment.checkpoint(ROOT / "provider-records.json", transport.records)
                print(
                    json.dumps(
                        {k: row[k] for k in ["trial", "status", "network_calls"]}
                    ),
                    flush=True,
                )
                if row["status"] in {
                    "authentication",
                    "quota_exceeded",
                    "configuration",
                    "invalid_request",
                    "network",
                    "unavailable",
                    "rate_limited",
                }:
                    manifest["stopped_early"] = row["status"]
                    break
    finally:
        manifest.update(
            finished_at=datetime.now(UTC).isoformat(),
            trials_recorded=len(rows),
            network_attempts=len(transport.records),
            production_after=assessment.production_state(),
        )
        manifest["production_unchanged"] = (
            manifest["production_before"] == manifest["production_after"]
        )
        manifest["all_recorded_requests_match_frozen"] = all(
            r["request_matches_frozen"] for r in transport.records
        )
        assessment.checkpoint(ROOT / "manifest.json", manifest)
        assessment.checkpoint(ROOT / "results.json", rows)
        assessment.checkpoint(ROOT / "provider-records.json", transport.records)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--prepare", action="store_true")
    group.add_argument("--live", action="store_true")
    parser.add_argument("--dotenv", type=Path)
    asyncio.run(execute(parser.parse_args()))
