"""Join blinded raw-output review to separately registered confirmation outcomes."""

import json
import statistics
from collections import Counter
from pathlib import Path

import run_confirmation as run

ROOT = Path(__file__).resolve().parent
DECISIVE = {"supports", "contradicts"}


def canonical_abstention(output):
    return (
        isinstance(output, dict)
        and output.get("relation") == "not_established"
        and output.get("explanation") is None
        and output.get("evidence_ids") == []
    )


def semantic_grounding(grade):
    return (
        grade["explanation_grounded"]
        and grade["explanation_matches_relation"]
        and not grade["unsupported_addition"]
    )


def published_score(status, output, expected, grade):
    accepted = status == "accepted"
    observed = output.get("relation") if isinstance(output, dict) else None
    formatted_abstention = canonical_abstention(output)
    grounding = formatted_abstention or semantic_grounding(grade)
    return {
        "accepted": accepted,
        "correct_label": observed == expected,
        "grounded_correct": accepted and observed == expected and grounding,
        "unsupported_decisive": accepted
        and expected == "not_established"
        and observed in DECISIVE,
        "incorrect_decisive": accepted
        and observed in DECISIVE
        and observed != expected,
        "unsupported_addition": accepted
        and not formatted_abstention
        and grade["unsupported_addition"],
        "presentation_complete": accepted
        and (formatted_abstention or grade["presentation_complete"]),
        "canonical_abstention": accepted and formatted_abstention,
    }


def main():
    read = lambda name: run.assessment.read(ROOT / name)
    rows, records = read("results.json"), read("provider-records.json")
    manifest, requests, protocol = (
        read("manifest.json"),
        read("requests.json"),
        read("protocol.json"),
    )
    review, key = read("blind-semantic-review.json"), read("blind-key.json")
    cases = {
        c["id"]: c for c in run.assessment.read(run.SHARED / "confirmation-cases.json")
    }
    assert manifest.get("finished_at")
    assert review["reviewed_count"] == len(rows) == len(records) == 96
    assert len(review["items"]) == len(key) == 96
    grades = {key[g["id"]]: g for g in review["items"]}
    assert len(grades) == len({r["trial"] for r in rows}) == 96
    for name, digest in manifest["hashes"].items():
        assert run.assessment.sha((ROOT / name).read_bytes()) == digest
    for name, digest in manifest["shared_hashes"].items():
        assert run.assessment.sha((run.SHARED / name).read_bytes()) == digest
    for name, digest in manifest["imported_hashes"].items():
        assert run.assessment.sha(Path(name).read_bytes()) == digest
    assert (
        manifest["production_before"]
        == run.assessment.production_state()
        == manifest["production_after"]
    )
    assert manifest["production_unchanged"]
    assert all(r["http_status"] == 200 and r["request_matches_frozen"] for r in records)
    assert all(r["network_calls"] == 1 for r in rows)
    raw_map = {r["trial"]: r for r in records}
    assert len(raw_map) == 96
    scored = []
    for row in rows:
        record, grade = raw_map[row["trial"]], grades[row["trial"]]
        case = cases[row["case_id"]]
        expected = case["expected"]
        frozen_payload = requests["payloads"][row["case_id"]][row["arm"]]
        assert record["request_payload"] == frozen_payload
        assert json.loads(record["request_body"]) == record["request_payload"]
        assert (
            run.assessment.sha(record["request_body"].encode())
            == record["request_body_sha256"]
        )
        actual_schema = record["request_payload"]["response_format"]["json_schema"][
            "schema"
        ]
        frozen_schema = frozen_payload["response_format"]["json_schema"]["schema"]
        assert (
            list(actual_schema["properties"])
            == list(frozen_schema["properties"])
            == record["request_schema_field_order"]
        )
        input_data = json.loads(record["request_payload"]["messages"][1]["content"])
        assert set(input_data) == {"claim", "source", "evidence"}
        assert input_data == requests["inputs"][row["case_id"]]
        raw = record.get("output")
        observed = raw.get("relation") if isinstance(raw, dict) else None
        assert grade["relation_correct"] == (observed == expected)
        if isinstance(raw, dict):
            assert record["response_field_order"] == list(raw)
        typed = row.get("raw_proposal")
        typed_available = isinstance(typed, dict)
        raw_structural_valid = False
        secondary = {"status": "unavailable", "output": None, "changed": False}
        if typed_available:
            assert typed == raw
            schema = run.assessment.SCHEMAS[run.ARMS[row["arm"]]]
            proposal = schema.model_validate(typed)
            raw_validation = run.validate(proposal, case["evidence"])
            assert raw_validation == row["raw_structural_validation"]
            raw_structural_valid = raw_validation["status"] == "accepted"
            normalized = run.normalized_proposal(proposal)
            secondary = {
                **run.validate(normalized, case["evidence"]),
                "output": normalized.model_dump(),
                "changed": normalized.model_dump() != typed,
            }
            assert secondary == row["symmetric_normalization_secondary"]
            published = normalized if row["arm"] == "candidate" else proposal
            expected_status = run.validate(published, case["evidence"])
            assert row["output"] == published.model_dump()
            assert row["status"] == expected_status["status"]
            assert row["normalization_applied"] == (published.model_dump() != typed)
            assert published.relation == observed
            if observed in DECISIVE:
                assert published.model_dump() == typed
        else:
            assert row["status"] != "accepted"
            assert not row.get("normalization_applied", False)
        primary = published_score(row["status"], row.get("output"), expected, grade)
        symmetric = published_score(
            secondary["status"], secondary["output"], expected, grade
        )
        raw_grounded = semantic_grounding(grade)
        normalized_away = bool(
            row.get("normalization_applied")
        ) and canonical_abstention(row.get("output"))
        raw_presentation_complete = grade["presentation_complete"]
        scored.append(
            {
                "trial": row["trial"],
                "case_id": row["case_id"],
                "family": case["family"],
                "condition": case["condition"],
                "repetition": row["repetition"],
                "arm": row["arm"],
                "expected": expected,
                "raw_relation": observed,
                "raw_label_correct": observed == expected,
                "raw_semantically_correct": observed == expected and raw_grounded,
                "typed_proposal_available": typed_available,
                "raw_structurally_valid": raw_structural_valid,
                "raw_structurally_valid_correct_label": raw_structural_valid
                and observed == expected,
                "raw_structurally_valid_grounded_correct": raw_structural_valid
                and observed == expected
                and raw_grounded,
                "raw_unsupported_addition": grade["unsupported_addition"],
                "raw_explanation_grounded": grade["explanation_grounded"],
                "raw_explanation_matches_relation": grade[
                    "explanation_matches_relation"
                ],
                "raw_unsupported_decisive": expected == "not_established"
                and observed in DECISIVE,
                "raw_incorrect_decisive": observed in DECISIVE and observed != expected,
                "raw_presentation_complete": raw_presentation_complete,
                "published": primary,
                "symmetric_normalization": symmetric,
                "normalization_applied": row.get("normalization_applied", False),
                "unsupported_raw_rationale_removed": normalized_away
                and grade["unsupported_addition"],
                "ungrounded_or_inconsistent_raw_rationale_removed": normalized_away
                and not raw_grounded,
                "faithful_raw_gap_explanation_cleared": normalized_away
                and raw_grounded
                and bool(raw.get("explanation")),
                "raw_explanation_characters": len(raw.get("explanation") or "")
                if isinstance(raw, dict)
                else None,
                "response_order_matches_request": record.get("response_field_order")
                == record["request_schema_field_order"],
                "blind_review_id": grade["id"],
                "notes": grade["notes"],
            }
        )
    summary = {}
    for arm in run.ARMS:
        ss = [s for s in scored if s["arm"] == arm]
        rr = [r for r in rows if r["arm"] == arm]
        assert len(ss) == 48
        by_condition = {}
        for condition in ["supports", "contradicts", "not_established", "withheld"]:
            group = [s for s in ss if s["condition"] == condition]
            by_condition[condition] = {
                "trials": len(group),
                "raw_correct_labels": sum(s["raw_label_correct"] for s in group),
                "raw_semantically_correct": sum(
                    s["raw_semantically_correct"] for s in group
                ),
                "published_grounded_correct": sum(
                    s["published"]["grounded_correct"] for s in group
                ),
                "published_unsupported_decisive": sum(
                    s["published"]["unsupported_decisive"] for s in group
                ),
                "symmetric_normalization_grounded_correct": sum(
                    s["symmetric_normalization"]["grounded_correct"] for s in group
                ),
            }
        summary[arm] = {
            "trials": len(ss),
            "raw_correct_labels": sum(s["raw_label_correct"] for s in ss),
            "raw_semantically_correct": sum(s["raw_semantically_correct"] for s in ss),
            "raw_typed_proposals": sum(s["typed_proposal_available"] for s in ss),
            "raw_structurally_valid": sum(s["raw_structurally_valid"] for s in ss),
            "raw_structurally_valid_correct_labels": sum(
                s["raw_structurally_valid_correct_label"] for s in ss
            ),
            "raw_structurally_valid_grounded_correct": sum(
                s["raw_structurally_valid_grounded_correct"] for s in ss
            ),
            "raw_unsupported_additions": sum(s["raw_unsupported_addition"] for s in ss),
            "raw_unsupported_decisive_verdicts": sum(
                s["raw_unsupported_decisive"] for s in ss
            ),
            "raw_incorrect_decisive_verdicts": sum(
                s["raw_incorrect_decisive"] for s in ss
            ),
            "raw_explanation_relation_mismatches": sum(
                not s["raw_explanation_matches_relation"] for s in ss
            ),
            "published_accepted": sum(s["published"]["accepted"] for s in ss),
            "published_accepted_correct_labels": sum(
                s["published"]["accepted"] and s["published"]["correct_label"]
                for s in ss
            ),
            "published_grounded_correct": sum(
                s["published"]["grounded_correct"] for s in ss
            ),
            "published_unsupported_decisive_verdicts": sum(
                s["published"]["unsupported_decisive"] for s in ss
            ),
            "published_incorrect_decisive_verdicts": sum(
                s["published"]["incorrect_decisive"] for s in ss
            ),
            "published_unsupported_additions": sum(
                s["published"]["unsupported_addition"] for s in ss
            ),
            "invalid_final_outputs": sum(not s["published"]["accepted"] for s in ss),
            "normalizations_applied": sum(s["normalization_applied"] for s in ss),
            "unsupported_raw_rationales_removed": sum(
                s["unsupported_raw_rationale_removed"] for s in ss
            ),
            "ungrounded_or_inconsistent_raw_rationales_removed": sum(
                s["ungrounded_or_inconsistent_raw_rationale_removed"] for s in ss
            ),
            "faithful_raw_gap_explanations_cleared": sum(
                s["faithful_raw_gap_explanation_cleared"] for s in ss
            ),
            "raw_incomplete_presentations": sum(
                not s["raw_presentation_complete"] for s in ss
            ),
            "published_incomplete_presentations": sum(
                s["published"]["accepted"]
                and not s["published"]["presentation_complete"]
                for s in ss
            ),
            "raw_exactly_300_characters": sum(
                s["raw_explanation_characters"] == 300 for s in ss
            ),
            "symmetric_normalization_accepted": sum(
                s["symmetric_normalization"]["accepted"] for s in ss
            ),
            "symmetric_normalization_grounded_correct": sum(
                s["symmetric_normalization"]["grounded_correct"] for s in ss
            ),
            "symmetric_normalization_unsupported_decisive_verdicts": sum(
                s["symmetric_normalization"]["unsupported_decisive"] for s in ss
            ),
            "response_order_matches_request": sum(
                s["response_order_matches_request"] for s in ss
            ),
            "by_condition": by_condition,
            "published_grounded_correct_by_case": {
                case: sum(
                    s["published"]["grounded_correct"]
                    for s in ss
                    if s["case_id"] == case
                )
                for case in cases
            },
            "network_calls": sum(r["network_calls"] for r in rr),
            "total_tokens": sum(r["usage"]["total_tokens"] for r in rr),
            "mean_trial_seconds": statistics.mean(r["elapsed_seconds"] for r in rr),
            "median_trial_seconds": statistics.median(r["elapsed_seconds"] for r in rr),
        }
    baseline, candidate = summary["baseline"], summary["candidate"]
    criteria = {
        "more_published_grounded_correct": candidate["published_grounded_correct"]
        > baseline["published_grounded_correct"],
        "no_increase_published_unsupported_decisive": candidate[
            "published_unsupported_decisive_verdicts"
        ]
        <= baseline["published_unsupported_decisive_verdicts"],
        "supported_controls_not_worse": candidate["by_condition"]["supports"][
            "published_grounded_correct"
        ]
        >= baseline["by_condition"]["supports"]["published_grounded_correct"],
        "contradicted_controls_not_worse": candidate["by_condition"]["contradicts"][
            "published_grounded_correct"
        ]
        >= baseline["by_condition"]["contradicts"]["published_grounded_correct"],
    }
    pairs = {}
    for s in scored:
        pairs.setdefault((s["case_id"], s["repetition"]), {})[s["arm"]] = s[
            "published"
        ]["grounded_correct"]
    pair_outcomes = []
    for (case, rep), pair in pairs.items():
        assert set(pair) == {"baseline", "candidate"}
        result = (
            "both_correct"
            if all(pair.values())
            else "baseline_only"
            if pair["baseline"]
            else "candidate_only"
            if pair["candidate"]
            else "neither_correct"
        )
        pair_outcomes.append({"case_id": case, "repetition": rep, "outcome": result})
    report = {
        "experiment_status": protocol["registration_status"],
        "summary": summary,
        "gate": {
            "criteria": criteria,
            "passed": all(criteria.values()),
            "meaning": "A pass supports additional full-pipeline testing of this combined candidate, not production deployment or proof that field order caused improvement.",
        },
        "paired_outcomes": dict(Counter(p["outcome"] for p in pair_outcomes)),
        "paired_outcomes_by_fixture": {
            case: dict(
                Counter(p["outcome"] for p in pair_outcomes if p["case_id"] == case)
            )
            for case in cases
        },
        "secondary_interpretation": {
            "published_candidate_minus_baseline": candidate[
                "published_grounded_correct"
            ]
            - baseline["published_grounded_correct"],
            "both_normalized_candidate_minus_baseline": candidate[
                "symmetric_normalization_grounded_correct"
            ]
            - baseline["symmetric_normalization_grounded_correct"],
            "note": "Symmetric normalization compares both raw-generation arms under the same formatter. A smaller or absent gap indicates that the published primary gain is partly or wholly explained by formatting, not a demonstrated improvement in reasoning.",
        },
        "metric_definitions": {
            "published_grounded_correct": "Accepted output with expected relation; canonical correct abstention counts even if discarded raw explanation was bad. Decisive output must also have grounded explanation, no unsupported addition, and explanation matching the relation.",
            "unsupported_decisive": "A supports/contradicts verdict when the frozen expected relation is not_established; other incorrect decisive labels are separately counted.",
            "raw_semantically_correct": "Expected raw relation with grounded, relation-consistent explanation; faithful gap explanation may be structurally invalid but semantically correct.",
            "presentation": "Reported independently from grounding; incomplete trailing text can preserve the main factual conclusion but is still a presentation defect.",
        },
        "review_method": "Independent agent grades shuffled raw outputs with claims/evidence/expected labels but no arm identifiers, output field order, structural status or trial IDs. The scorer joins the key after review and separately applies deterministic publication rules.",
        "review_artifact_hashes": {
            name: run.assessment.sha((ROOT / name).read_bytes())
            for name in [
                "blind-semantic-review.json",
                "blind-key.json",
                "score_confirmation.py",
            ]
        },
        "integrity": {
            "trials": 96,
            "http_200_calls": 96,
            "one_call_per_trial": True,
            "no_repairs_or_transport_retries": True,
            "actual_payloads_match_frozen": True,
            "labels_not_sent": True,
            "typed_raw_proposals_preserved": True,
            "only_typed_abstentions_normalized": True,
            "decisive_outputs_unchanged_by_formatter": True,
            "symmetric_secondary_recomputed": True,
            "frozen_hashes_match": True,
            "production_unchanged": True,
        },
        "limitations": protocol["limitations"],
        "trials": scored,
    }
    run.assessment.checkpoint(ROOT / "review.json", report)
    print(
        json.dumps(
            {
                "summary": summary,
                "gate": report["gate"],
                "paired_outcomes": report["paired_outcomes"],
                "secondary_interpretation": report["secondary_interpretation"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
