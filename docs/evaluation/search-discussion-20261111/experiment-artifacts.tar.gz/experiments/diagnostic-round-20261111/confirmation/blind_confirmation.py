"""Prepare canonicalized raw proposals for semantic review without arm labels."""

import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    def read(path):
        return json.loads(path.read_text())

    rows = read(ROOT / "results.json")
    records = read(ROOT / "provider-records.json")
    assert read(ROOT / "manifest.json").get("finished_at")
    assert len(rows) == len(records) == 96
    cases = {c["id"]: c for c in read(ROOT.parent / "shared/confirmation-cases.json")}
    raw = {r["trial"]: r for r in records}
    random.Random(57217).shuffle(rows)
    items, mapping = [], {}
    for i, row in enumerate(rows, 1):
        item_id = f"Q{i:03}"
        c = cases[row["case_id"]]
        output = raw[row["trial"]].get("output")
        canonical = (
            {k: output.get(k) for k in ["relation", "explanation", "evidence_ids"]}
            if isinstance(output, dict)
            else output
        )
        items.append(
            {
                "id": item_id,
                "claim": c["claim"],
                "source": c["source"],
                "evidence": c["evidence"],
                "expected": c["expected"],
                "output": canonical,
            }
        )
        mapping[item_id] = row["trial"]
    for name, data in [("blinded-items.json", items), ("blind-key.json", mapping)]:
        (ROOT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    print("Prepared 96 blinded confirmation proposals")


if __name__ == "__main__":
    main()
