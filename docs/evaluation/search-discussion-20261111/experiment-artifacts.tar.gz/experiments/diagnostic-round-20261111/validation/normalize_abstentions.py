"""Post-hoc offline test of presentation-only abstention normalization."""

import copy
import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSESSMENT = ROOT.parent / "assessment"
sys.path.insert(0, str(ASSESSMENT))
import run_assessment as run


def normalize(raw, schema):
    """Only schema-valid abstention payloads are canonicalized; never revise a label."""
    value = schema.model_validate(raw, strict=True)
    normalized = copy.deepcopy(raw)
    if value.relation == "not_established":
        normalized["explanation"] = None
        normalized["evidence_ids"] = []
    return normalized


def validate(raw, schema, evidence):
    try:
        value = schema.model_validate(raw, strict=True)
        run.runtime.validate_explanation(value, evidence)
    except run.ValidationError:
        return "schema_rejected"
    except run.TaskValidationError as exc:
        return exc.code
    return "accepted"


def main():
    protocol = {
        "purpose": "Post-hoc offline follow-up after observing abstention-shape failures; not a winner of the original four-arm test.",
        "change": "After schema validation, if and only if relation=not_established, set explanation=null and evidence_ids=[]. Keep an immutable audit copy. Never alter relation or any decisive output.",
        "scope": "Apply equally to all four arms, not selectively to the apparently promising arm.",
        "no_semantic_claim": "This validates a representation transform. It cannot make a wrong abstention correct or establish that a discarded explanation was grounded.",
        "sensitivity": [
            "supports with unknown citation remains unchanged and rejected",
            "contradicts with missing citation remains unchanged and rejected",
            "valid decisive explanation is unchanged",
            "unknown relation remains schema-rejected",
            "incorrect field types remain schema-rejected",
            "wrong abstention remains the same wrong relation",
            "empty valid abstention is unchanged",
        ],
        "presentation_tradeoff": "Users lose why-evidence-is-insufficient explanations under the current null requirement. Such reasons must remain audit-only or pass a separately designed grounding check before display. Null is safer than publishing an unchecked rationale but is less informative.",
        "model_calls": 0,
    }
    run.freeze(ROOT / "normalization-protocol.json", protocol)
    files = [ASSESSMENT / "results.json", ASSESSMENT / "provider-records.json"]
    hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    rows = run.read(files[0])
    cases = {c["id"]: c for c in run.read(ROOT.parent / "shared/cases.json")}
    results = []
    for row in rows:
        raw = copy.deepcopy(row.get("output"))
        schema = run.SCHEMAS[row["arm"]]
        c = cases[row["case_id"]]
        if raw is None:
            raise AssertionError(
                "Missing output requires a separately specified error path"
            )
        original_serialization = json.dumps(raw)
        try:
            normalized = normalize(raw, schema)
            after = validate(normalized, schema, c["evidence"])
        except run.ValidationError:
            normalized, after = copy.deepcopy(raw), "schema_rejected"
        assert json.dumps(raw) == original_serialization
        assert normalized["relation"] == raw["relation"]
        if raw["relation"] != "not_established":
            assert normalized == raw
        results.append(
            {
                "trial": row["trial"],
                "arm": row["arm"],
                "original_status": row["status"],
                "original_contract_result": validate(raw, schema, c["evidence"]),
                "raw_audit": raw,
                "raw_audit_sha256": hashlib.sha256(
                    original_serialization.encode()
                ).hexdigest(),
                "normalized": normalized,
                "changed": normalized != raw,
                "normalized_contract_result": after,
                "label_unchanged": True,
                "expected": c["expected"],
                "correct_label": normalized["relation"] == c["expected"],
                "warning": "Correct label does not grade raw rationale grounding.",
            }
        )

    schema = run.SCHEMAS["explanation_first_uncapped"]
    sensitivity = []
    probes = [
        (
            "supports_wrong_id",
            {
                "relation": "supports",
                "explanation": "A factual claim.",
                "evidence_ids": ["E999"],
            },
            "explanation_reference",
            False,
        ),
        (
            "contradicts_missing_id",
            {
                "relation": "contradicts",
                "explanation": "A factual contradiction.",
                "evidence_ids": [],
            },
            "explanation_reference",
            False,
        ),
        (
            "valid_factual_explanation",
            {
                "relation": "supports",
                "explanation": "A grounded comparison.",
                "evidence_ids": ["E1"],
            },
            "accepted",
            False,
        ),
        (
            "unknown_relation",
            {"relation": "true", "explanation": "A claim.", "evidence_ids": ["E1"]},
            "schema_rejected",
            False,
        ),
        (
            "invalid_explanation_type",
            {"relation": "not_established", "explanation": 123, "evidence_ids": []},
            "schema_rejected",
            False,
        ),
        (
            "already_valid_abstention",
            {"relation": "not_established", "explanation": None, "evidence_ids": []},
            "accepted",
            False,
        ),
        (
            "wrong_abstention_not_fixed",
            {
                "relation": "not_established",
                "explanation": "The quotation actually supports the claim, but the label is wrong.",
                "evidence_ids": ["E1"],
            },
            "accepted",
            True,
        ),
        (
            "unsupported_abstention_rationale_removed_not_proven",
            {
                "relation": "not_established",
                "explanation": "An unsupported invented fact appears here.",
                "evidence_ids": ["E999"],
            },
            "accepted",
            True,
        ),
    ]
    for name, raw, expected_result, expected_change in probes:
        audit = copy.deepcopy(raw)
        try:
            normalized = normalize(raw, schema)
            result = validate(normalized, schema, [{"id": "E1"}])
        except run.ValidationError:
            normalized, result = copy.deepcopy(raw), "schema_rejected"
        assert raw == audit and raw["relation"] == normalized["relation"]
        assert result == expected_result and (normalized != raw) == expected_change
        sensitivity.append(
            {
                "name": name,
                "expected": expected_result,
                "observed": result,
                "raw_unchanged": True,
                "relation_unchanged": True,
                "normalization_changed_payload": normalized != raw,
            }
        )
    summary = {}
    for arm in run.ARMS:
        rr = [r for r in results if r["arm"] == arm]
        summary[arm] = {
            "trials": len(rr),
            "original_accepted": sum(
                r["original_contract_result"] == "accepted" for r in rr
            ),
            "original_accepted_correct_labels": sum(
                r["original_contract_result"] == "accepted" and r["correct_label"]
                for r in rr
            ),
            "normalizations": sum(r["changed"] for r in rr),
            "after_accepted": sum(
                r["normalized_contract_result"] == "accepted" for r in rr
            ),
            "after_accepted_correct_labels": sum(
                r["normalized_contract_result"] == "accepted" and r["correct_label"]
                for r in rr
            ),
            "decisive_outputs_altered": 0,
            "labels_altered": 0,
        }
    assert all(
        hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in hashes.items()
    )
    report = {
        "post_hoc": True,
        "summary": summary,
        "sensitivity": sensitivity,
        "original_artifact_hashes_unchanged": hashes,
        "raw_explanation_caveats": [
            "web_withheld/1/explanation_first_uncapped adds a date/availability statement absent from the supplied heading.",
            "aes_not_established/2/explanation_first_uncapped invents key-round/performance claims and conflicts with its own abstention label.",
            "Normalization suppresses such rationales from the final response but does not cure model grounding. Independent blind review remains authoritative for semantic scoring.",
        ],
        "presentation_implication": protocol["presentation_tradeoff"],
        "results": results,
        "completed_at": datetime.now(UTC).isoformat(),
    }
    run.freeze(ROOT / "normalization-results.json", report)
    print(
        json.dumps(
            {
                "post_hoc": True,
                "summary": summary,
                "sensitivity_probes": len(sensitivity),
                "raw_artifacts_unchanged": True,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
