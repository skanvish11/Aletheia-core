"""Offline boundary checks against the unchanged current Phase 1 implementation."""

import asyncio
import hashlib
import json
import socket
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[2]
PRODUCTION = WORKSPACE / "aletheia-phase-one"
sys.path.insert(0, str(PRODUCTION / "src"))

from aletheia.budgets import RunBudget
from aletheia.direct import validate_component_assessment
from aletheia.evidence import admit, snapshot
from aletheia.phase_one_contracts import ClaimAnalysis, ComparisonSpec, RecordedValue
from aletheia.providers.errors import ProviderError
from aletheia.providers.nebius import ModelResult
from aletheia.research_contracts import Assertion, Assessment
from aletheia.task_contracts import RecordAssessment
from aletheia.tasks import InvalidTask, Tasks, TaskValidationError
from aletheia.verdicts import finding
from pydantic import ValidationError


def forbid_network(*args, **kwargs):
    raise AssertionError("Network use forbidden in this offline diagnostic")


socket.create_connection = forbid_network
socket.socket.connect = forbid_network


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def component(
    cid="c1", text="Mars is fourth from the Sun", role="essential", comparison=None
):
    return {
        "id": cid,
        "text": text,
        "role": role,
        "subject": "Mars",
        "predicate": "recorded property",
        "timeframe": None,
        "location_or_population": None,
        "comparison": comparison,
    }


def claim(components=None, comparison=None):
    components = components or [component(comparison=comparison)]
    return Assertion(
        text="Mars is fourth from the Sun and has two moons.",
        kind="direct_record",
        consequential=False,
        recommended_route="quick",
        analysis=ClaimAnalysis(
            primary_type="direct_comparison" if comparison else "direct_fact",
            required_method="record_comparison" if comparison else "record_lookup",
            supported=True,
            reason="Manually specified offline diagnostic; not a model judgment.",
            scope="complete",
            missing_scope=[],
            components=components,
        ),
    )


def source(text="Mars is fourth from the Sun.\nMars has two moons."):
    return snapshot(
        url="https://example.test/record",
        title="Synthetic record",
        published_date=None,
        retrieved_at=datetime(2026, 11, 11, tzinfo=UTC),
        text=text,
    )


def assessment(src, **changes):
    values = {
        "component_id": "c1",
        "values": [],
        "citation": {"snapshot_id": src.id, "span_ids": [1]},
        "relation": "supports",
        "scope_match": True,
        "authoritative_record": True,
        "credible_synthesis": False,
        "synthesis_coverage": None,
        "publisher": "Synthetic original-record publisher",
        "origin": None,
        "independence": "unknown",
        "provenance_span_ids": [],
        "provenance_note": None,
        "rationale": "The supplied quotation establishes the assessed proposition.",
        "limitations": [],
        "flags": [],
    }
    values.update(changes)
    return Assessment.model_validate(values)


def validate(a, c, s, supplied=None):
    ids = supplied if supplied is not None else {span.id for span in s.spans}
    e = admit(a, s, ids)
    validate_component_assessment(a, c, s, ids)
    return e


def status(fn):
    try:
        result = fn()
        if hasattr(result, "admissible"):
            return "admitted" if result.admissible else "retained_nonadmissible"
        return result
    except TaskValidationError as exc:
        return "rejected:" + exc.code
    except ValidationError:
        return "rejected:schema"


def verdict(c, items, sources, route="quick"):
    f = finding(c, route, items, sources)[0]
    return {
        "verdict": f.verdict,
        "reason": f.unable_to_decide_reason,
        "components": [v.outcome for v in f.components],
    }


def comparison_fixture():
    spec = ComparisonSpec(
        left="A",
        right="B",
        metric="distance",
        operator="lt",
        units="km",
        period="2020",
        population="named objects",
        definition="distance from marker",
        exhaustive=False,
    )
    s = source("A is 108 km from the marker; B is 58 km from the marker.")
    values = [
        RecordedValue(
            side=side,
            entity=entity,
            value=number,
            kind="number",
            exact=True,
            source_text=number,
            **spec.model_dump(exclude={"left", "right", "operator", "exhaustive"}),
        )
        for side, entity, number in [("left", "A", "108"), ("right", "B", "58")]
    ]
    c = claim(
        components=[
            {
                **component(text="A is closer to the marker than B.", comparison=spec),
                "subject": "A",
                "predicate": "is closer to the marker than B",
            }
        ],
        comparison=spec,
    ).model_copy(update={"text": "A is closer to the marker than B."})
    return s, c, values


def scenarios():
    s, c = source(), claim()
    good = assessment(s)
    comp_source, comp_claim, vals = comparison_fixture()
    cases = []

    def add(name, expected, fn, category="validation", purpose=""):
        cases.append(
            {
                "name": name,
                "expected": expected,
                "fn": fn,
                "category": category,
                "purpose": purpose,
            }
        )

    add(
        "valid_record_citation",
        "admitted",
        lambda: status(lambda: validate(good, c, s)),
    )
    add(
        "wrong_snapshot_identity",
        "rejected:citation_snapshot",
        lambda: status(
            lambda: validate(
                assessment(
                    s, citation={"snapshot_id": "another-snapshot", "span_ids": [1]}
                ),
                c,
                s,
            )
        ),
    )
    add(
        "unknown_passage_id",
        "rejected:citation_spans",
        lambda: status(
            lambda: validate(
                assessment(s, citation={"snapshot_id": s.id, "span_ids": [999]}), c, s
            )
        ),
    )
    add(
        "existing_but_unsupplied_passage",
        "rejected:citation_spans",
        lambda: status(
            lambda: validate(
                assessment(s, citation={"snapshot_id": s.id, "span_ids": [2]}),
                c,
                s,
                {1},
            )
        ),
    )
    add(
        "duplicate_passage_id",
        "rejected:citation_spans",
        lambda: status(
            lambda: validate(
                assessment(s, citation={"snapshot_id": s.id, "span_ids": [1, 1]}), c, s
            )
        ),
    )
    add(
        "out_of_order_passage_ids",
        "rejected:citation_spans",
        lambda: status(
            lambda: validate(
                assessment(s, citation={"snapshot_id": s.id, "span_ids": [2, 1]}), c, s
            )
        ),
    )
    add(
        "unknown_component",
        "rejected:component_reference",
        lambda: status(lambda: validate(assessment(s, component_id="c8"), c, s)),
    )
    add(
        "missing_provenance_for_independence",
        "rejected:provenance",
        lambda: status(
            lambda: validate(assessment(s, independence="established"), c, s)
        ),
    )
    add(
        "synthesis_without_coverage",
        "rejected:synthesis_coverage",
        lambda: status(lambda: validate(assessment(s, credible_synthesis=True), c, s)),
    )
    add(
        "narrow_scope_flag_with_direct_support",
        "rejected:scope_flag",
        lambda: status(
            lambda: validate(
                assessment(
                    s,
                    flags=[
                        {
                            "type": "narrow_scope",
                            "dimension": "timeframe",
                            "explanation": "A narrower timeframe.",
                        }
                    ],
                ),
                c,
                s,
            )
        ),
    )
    add(
        "scope_mismatch_support_retained_but_not_counted",
        "retained_nonadmissible",
        lambda: status(lambda: validate(assessment(s, scope_match=False), c, s)),
    )
    add(
        "scope_mismatch_context_preserved",
        "admitted",
        lambda: status(
            lambda: validate(assessment(s, scope_match=False, relation="context"), c, s)
        ),
    )
    add(
        "ordinary_record_operands_schema_forbidden",
        "rejected:schema",
        lambda: status(
            lambda: RecordAssessment.model_validate(
                assessment(comp_source, values=vals).model_dump()
            )
        ),
    )
    add(
        "ordinary_record_operands_semantically_forbidden",
        "rejected:comparison_unexpected_values",
        lambda: status(
            lambda: validate(assessment(comp_source, values=vals), c, comp_source)
        ),
    )
    add(
        "correct_grounded_comparison",
        "admitted",
        lambda: status(
            lambda: validate(
                assessment(comp_source, relation="contradicts", values=vals),
                comp_claim,
                comp_source,
            )
        ),
    )
    add(
        "reversed_comparison_label",
        "rejected:comparison_relation",
        lambda: status(
            lambda: validate(
                assessment(comp_source, values=vals), comp_claim, comp_source
            )
        ),
    )
    add(
        "missing_operand_decisive_label",
        "rejected:comparison_relation",
        lambda: status(
            lambda: validate(
                assessment(comp_source, relation="contradicts", values=vals[:1]),
                comp_claim,
                comp_source,
            )
        ),
    )
    add(
        "missing_operand_as_context",
        "admitted",
        lambda: status(
            lambda: validate(
                assessment(comp_source, relation="context", values=vals[:1]),
                comp_claim,
                comp_source,
            )
        ),
    )
    bad_units = [vals[0], vals[1].model_copy(update={"units": "m"})]
    add(
        "incompatible_operand_units",
        "rejected:comparison_relation",
        lambda: status(
            lambda: validate(
                assessment(comp_source, relation="contradicts", values=bad_units),
                comp_claim,
                comp_source,
            )
        ),
    )
    invented = [vals[0].model_copy(update={"source_text": "Invented 108"}), vals[1]]
    add(
        "invented_quote_anchor",
        "rejected:comparison_source_anchor",
        lambda: status(
            lambda: validate(
                assessment(comp_source, relation="contradicts", values=invented),
                comp_claim,
                comp_source,
            )
        ),
    )
    invented_number = [vals[0].model_copy(update={"value": "10"}), vals[1]]
    add(
        "cropped_number_not_full_token",
        "rejected:comparison_numeric_anchor",
        lambda: status(
            lambda: validate(
                assessment(comp_source, relation="context", values=invented_number),
                comp_claim,
                comp_source,
            )
        ),
    )

    two = claim([component(), component("c2", "has two moons", "modifier")])
    e1 = validate(good, two, s)
    e2 = validate(
        assessment(
            s, component_id="c2", citation={"snapshot_id": s.id, "span_ids": [2]}
        ),
        two,
        s,
    )
    ec1 = validate(assessment(s, relation="contradicts"), two, s)
    ec2 = validate(
        assessment(
            s,
            component_id="c2",
            relation="contradicts",
            citation={"snapshot_id": s.id, "span_ids": [2]},
        ),
        two,
        s,
    )
    add(
        "all_components_supported",
        {"verdict": "true", "reason": None, "components": ["supported", "supported"]},
        lambda: verdict(two, [e1, e2], [s]),
        "combination",
    )
    add(
        "missing_modifier_prevents_true",
        {
            "verdict": None,
            "reason": "insufficient_evidence",
            "components": ["supported", "not_established"],
        },
        lambda: verdict(two, [e1], [s]),
        "combination",
    )
    add(
        "essential_contradiction_yields_false",
        {
            "verdict": "false",
            "reason": None,
            "components": ["contradicted", "supported"],
        },
        lambda: verdict(two, [ec1, e2], [s]),
        "combination",
    )
    add(
        "modifier_contradiction_requires_correction_not_false",
        {
            "verdict": None,
            "reason": "insufficient_evidence",
            "components": ["supported", "contradicted"],
        },
        lambda: verdict(two, [e1, ec2], [s]),
        "combination",
        "Intentional Phase 1 Almost policy: contradicted modifier cannot be swallowed by support or automatically become False.",
    )
    add(
        "within_component_conflict_prevents_verdict",
        {
            "verdict": None,
            "reason": "conflicting_evidence",
            "components": ["conflicting", "supported"],
        },
        lambda: verdict(two, [e1, ec1, e2], [s]),
        "combination",
    )
    weak = validate(assessment(s, authoritative_record=False), c, s)
    add(
        "accurate_fact_without_sufficient_source_abstains",
        {
            "verdict": None,
            "reason": "insufficient_evidence",
            "components": ["not_established"],
        },
        lambda: verdict(c, [weak], [s]),
        "source_policy",
    )
    truncated = s.model_copy(update={"limitations": ["source_truncated"]})
    add(
        "truncated_page_can_establish_narrow_authoritative_record",
        {"verdict": "true", "reason": None, "components": ["supported"]},
        lambda: verdict(c, [validate(good, c, truncated)], [truncated]),
        "source_policy",
    )
    synthesis = validate(
        assessment(
            truncated,
            authoritative_record=False,
            credible_synthesis=True,
            synthesis_coverage="Comprehensive coverage asserted.",
        ),
        c,
        truncated,
    )
    add(
        "truncation_blocks_comprehensive_synthesis_sufficiency",
        {
            "verdict": None,
            "reason": "insufficient_evidence",
            "components": ["not_established"],
        },
        lambda: verdict(c, [synthesis], [truncated]),
        "source_policy",
    )
    unrelated = source("The publication was printed on recycled paper.")
    ungrounded = validate(assessment(unrelated), c, unrelated)
    add(
        "false_semantic_assessment_can_pass_structural_guards",
        {"verdict": "true", "reason": None, "components": ["supported"]},
        lambda: verdict(c, [ungrounded], [unrelated]),
        "documented_semantic_gap",
        "Deliberately false oracle semantic/authority flags: demonstrates structural admission and deterministic finding do not prove entailment. Not a successful research answer; final semantic checker is not exercised.",
    )
    return cases


def budget_probe(total, already_used):
    b = RunBudget()
    b.model_attempts = total
    for _ in range(already_used):
        b.reserve("nebius", "model", 1)
    research = 0
    try:
        while True:
            b.reserve("nebius", "model", 1)
            research += 1
    except ProviderError as exc:
        reason = exc.limit_reason
    b.finalizing = True
    final = 0
    try:
        while True:
            b.reserve("nebius", "model", 1)
            final += 1
    except ProviderError as exc:
        final_reason = exc.limit_reason
    return {
        "total": total,
        "pre_research_used": already_used,
        "remaining_research_calls": research,
        "research_stop": reason,
        "remaining_finalization_calls": final,
        "finalization_stop": final_reason,
        "all_used": b.used["model"],
    }


class ScriptedModel:
    def __init__(self, outputs):
        self.outputs = outputs
        self.requests = []

    async def generate(
        self, *, instructions, input_text, response_type, budget, **kwargs
    ):
        budget.reserve("nebius", "model", 1)
        self.requests.append({"instructions": instructions, "input_text": input_text})
        return ModelResult(self.outputs[len(self.requests) - 1], None)


async def repair_probe(valid_second):
    s, c = source(), claim()
    good = assessment(s)
    bad = assessment(
        s, citation={"snapshot_id": "WRONG_SNAPSHOT_MARKER", "span_ids": [1]}
    )
    model = ScriptedModel([bad, good if valid_second else bad])
    budget = RunBudget()
    events = []

    async def emit(event, payload):
        events.append({"type": event, "payload": payload})

    task = Tasks(model, budget, emit)
    try:
        await task.call(
            "assess",
            "Synthetic offline validation-repair test.",
            {"claim": c.text, "source_id": s.id},
            Assessment,
            lambda a: validate(a, c, s),
        )
        outcome = "accepted"
    except InvalidTask:
        outcome = "invalid_task_output"
    return {
        "outcome": outcome,
        "attempts": len(model.requests),
        "same_input_on_retry": model.requests[0]["input_text"]
        == model.requests[1]["input_text"],
        "previous_bad_output_in_repair": "WRONG_SNAPSHOT_MARKER"
        in model.requests[1]["instructions"],
        "repair_mentions_snapshot": "snapshot"
        in model.requests[1]["instructions"].lower(),
        "events": events,
    }


async def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    cases = scenarios()
    protocol = {
        "purpose": "Offline checks of current Phase 1 validation, deterministic component verdicts and call recovery rules.",
        "source_revision": "0246699a9e478b4588a38df252a0a047a4910624",
        "network_calls": 0,
        "fixtures": "Synthetic known-valid/invalid responses and snapshots; labels independently reviewed separately using saved actual evidence. Authority/semantic flags are controlled fixture inputs, not measured model judgments.",
        "limitations": [
            "Does not replay historical rejected raw model responses, which were not retained.",
            "Does not evaluate model-generated semantics, authority judgments, synthesis or final semantic-check accuracy.",
            "Protected negative cases remain required even if a looser contract would accept more responses.",
        ],
        "cases": [{k: v for k, v in case.items() if k != "fn"} for case in cases],
        "budget_expectations": {
            "historical_8_after_2": 2,
            "current_10_after_2": 4,
            "historical_8_after_3": 1,
            "current_10_after_3": 3,
            "finalization_calls_each": 4,
        },
        "repair_expectations": {
            "valid_second": "accepted",
            "invalid_second": "invalid_task_output",
            "maximum_calls": 2,
            "same_input_on_retry": True,
            "previous_output_supplied": False,
        },
    }
    dump("protocol.json", protocol)
    paths = [
        PRODUCTION / "src/aletheia" / name
        for name in [
            "evidence.py",
            "direct.py",
            "verdicts.py",
            "budgets.py",
            "tasks.py",
            "task_contracts.py",
            "research_contracts.py",
        ]
    ]
    hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    results = []
    for case in cases:
        actual = case["fn"]()
        results.append(
            {k: v for k, v in case.items() if k != "fn"}
            | {
                "observed": actual,
                "matches_predeclared_behavior": actual == case["expected"],
            }
        )
    budgets = [budget_probe(total, used) for total in [8, 10] for used in [2, 3]]
    for b in budgets:
        assert b["remaining_research_calls"] == b["total"] - 4 - b["pre_research_used"]
        assert b["remaining_finalization_calls"] == 4
        assert b["research_stop"] == "model_finalization_reserve"
    repairs = {
        "valid_second": await repair_probe(True),
        "invalid_second": await repair_probe(False),
    }
    assert repairs["valid_second"]["outcome"] == "accepted"
    assert repairs["invalid_second"]["outcome"] == "invalid_task_output"
    assert all(
        r["attempts"] == 2
        and r["same_input_on_retry"]
        and not r["previous_bad_output_in_repair"]
        for r in repairs.values()
    )
    unchanged = all(
        hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in hashes.items()
    )
    report = {
        "results": results,
        "budgets": budgets,
        "repairs": repairs,
        "summary": {
            "boundary_cases": len(results),
            "matching_predeclared_behavior": sum(
                r["matches_predeclared_behavior"] for r in results
            ),
            "documented_semantic_gap_probes": sum(
                r["category"] == "documented_semantic_gap" for r in results
            ),
            "budget_schedules_checked": len(budgets),
            "scripted_repair_paths_checked": len(repairs),
            "production_modules_unchanged": unchanged,
            "network_calls": 0,
        },
        "source_hashes": hashes,
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "completed_at": datetime.now(UTC).isoformat(),
    }
    dump("results.json", report)
    print(json.dumps(report["summary"], indent=2))
    failures = [r for r in results if not r["matches_predeclared_behavior"]]
    if failures:
        print(json.dumps(failures, indent=2))
    assert not failures and unchanged


if __name__ == "__main__":
    asyncio.run(main())
