"""Check isolated bounded-span proposal against unchanged production citation guards."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import run_offline as check
from aletheia.research_contracts import Snapshot

ROOT = Path(__file__).resolve().parent
SELECTION = ROOT.parent / "selection"


def read(name):
    return json.loads((SELECTION / name).read_text())


def main():
    # Protocol/fixture source was reviewed before selection/results.json was read.
    protocol = read("protocol.json")
    review = {
        "reviewer": "Independent validation sub-agent",
        "timing": "Reviewed protocol and fixture-generation code after selector execution but before inspecting selection results. Not a pre-execution independent adjudication.",
        "reviewed_at": datetime.now(UTC).isoformat(),
        "protocol_sha256": hashlib.sha256(
            (SELECTION / "protocol.json").read_bytes()
        ).hexdigest(),
        "approved_for_stated_scope": True,
        "notes": [
            "Python requires the named Python subject/antecedent as well as the public-release year.",
            "SHA requires the named algorithm and digest fact together.",
            "Synthetic pronoun cases appropriately require antecedent plus fact; table case requires column header plus target row.",
            "Paris criterion establishes adoption event/date and Conference of Parties wording, not independently every institutional detail of the original claim.",
            "The absent-evidence case checks preservation/no invented text, not a selector's ability to decide semantic absence.",
            "Coverage of prescribed strings is a useful regression target, not complete model comprehensibility, source sufficiency or final-verdict evaluation.",
        ],
        "fixture_count": len(protocol["fixtures"]),
    }
    check.dump("selection-expectation-review.json", review)
    original = Snapshot.model_validate(read("python-original-snapshot.json"))
    derived = Snapshot.model_validate(read("python-derived-snapshot.json"))
    fixture = read("python-admission-fixture.json")
    parents = read("python-derived-provenance.json")
    assert derived.id != original.id
    assert derived.normalized_text == original.normalized_text
    assert derived.original_text == original.original_text
    assert derived.content_hash == original.content_hash
    parent_spans = {s.id: s for s in original.spans}
    for span in derived.spans:
        parent = parents[str(span.id)]
        assert parent["original_snapshot_id"] == original.id
        assert parent["start"] == span.start and parent["end"] == span.end
        p = parent_spans[parent["original_span_id"]]
        assert p.start <= span.start < span.end <= p.end
        assert derived.normalized_text[span.start : span.end] == span.text
    c = check.claim([check.component(text=fixture["claim"])])
    c = c.model_copy(update={"text": fixture["claim"]})
    a = check.assessment(
        derived,
        relation="contradicts",
        authoritative_record=False,
        citation={"snapshot_id": derived.id, "span_ids": fixture["span_ids"]},
        rationale="The source describes Python's public release in 1991, not the asserted2001.",
    )
    admitted = check.validate(a, c, derived, set(fixture["supplied_ids"]))
    assert admitted.admissible
    quotations = "\n".join(e.text for e in admitted.excerpts)
    assert "Van Rossum released it publicly in 1991" in quotations
    assert "began writing Python" in quotations
    for e in admitted.excerpts:
        assert original.normalized_text[e.start : e.end] == e.text
        assert hashlib.sha256(e.text.encode()).hexdigest() == e.quote_hash
    stale = a.model_copy(
        update={"citation": a.citation.model_copy(update={"snapshot_id": original.id})}
    )
    stale_result = check.status(
        lambda: check.validate(stale, c, derived, set(fixture["supplied_ids"]))
    )
    assert stale_result == "rejected:citation_snapshot"
    result = {
        "original_snapshot_id": original.id,
        "derived_snapshot_id": derived.id,
        "derived_span_count": len(derived.spans),
        "cited_span_ids": fixture["span_ids"],
        "admitted": admitted.admissible,
        "source_text_and_content_hash_unchanged": True,
        "parent_offsets_verified": True,
        "reconstructed_quote_hashes_verified": True,
        "subject_and_release_date_retained": True,
        "stale_original_snapshot_reference": stale_result,
        "verdict_with_unproven_authority": check.verdict(c, [admitted], [derived]),
        "authority_note": "Authority explicitly left false; this admission compatibility test does not upgrade the UBC source into an original authoritative record.",
        "limitations": [
            "Tests reconstruction/admission/component reference compatibility, not production persistence migration or model assessment quality.",
            "New snapshot identity is necessary when repartitioning spans; existing IDs must not silently acquire new meanings.",
            "A citation-compatible derived view does not itself guarantee a final verdict.",
        ],
        "source_files_sha256": {
            name: hashlib.sha256((SELECTION / name).read_bytes()).hexdigest()
            for name in [
                "python-original-snapshot.json",
                "python-derived-snapshot.json",
                "python-derived-provenance.json",
                "python-admission-fixture.json",
            ]
        },
    }
    check.dump("selection-integration.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
